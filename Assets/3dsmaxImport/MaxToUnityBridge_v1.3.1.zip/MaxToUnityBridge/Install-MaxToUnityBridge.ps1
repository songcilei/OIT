﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $true, HelpMessage = "Unity 工程根目录，该目录下应包含 Assets 和 ProjectSettings。")]
    [string]$UnityProject,

    [string]$MaxVersion,

    [string]$Language = "ENU"
)

$ErrorActionPreference = "Stop"

function Write-Step([string]$Message) {
    Write-Host "[MaxToUnityBridge] $Message" -ForegroundColor Cyan
}

$packageRoot = $PSScriptRoot
if (-not (Test-Path -LiteralPath $packageRoot)) {
    throw "找不到安装包目录: $packageRoot"
}

$projectPath = (Resolve-Path -LiteralPath $UnityProject).Path
$assetsPath = Join-Path $projectPath "Assets"
$projectVersionPath = Join-Path $projectPath "ProjectSettings\ProjectVersion.txt"

if (-not (Test-Path -LiteralPath $assetsPath -PathType Container)) {
    throw "Unity 工程无效，未找到 Assets: $assetsPath"
}
if (-not (Test-Path -LiteralPath $projectVersionPath -PathType Leaf)) {
    throw "Unity 工程无效，未找到 ProjectSettings\ProjectVersion.txt: $projectPath"
}

if ([string]::IsNullOrWhiteSpace($MaxVersion)) {
    $installedVersions = Get-ChildItem -LiteralPath "C:\Program Files\Autodesk" -Directory -ErrorAction SilentlyContinue |
        ForEach-Object {
            if ($_.Name -match '^3ds Max (\d{4})$') {
                [pscustomobject]@{ Name = $_.Name; Version = [int]$Matches[1] }
            }
        } |
        Sort-Object Version -Descending

    if (-not $installedVersions) {
        throw "未检测到已安装的 3ds Max，请使用 -MaxVersion 2026 指定版本。"
    }

    $MaxVersion = [string]$installedVersions[0].Version
}

if ($MaxVersion -notmatch '^\d{4}$') {
    throw "-MaxVersion 应为四位年份，例如 2026。"
}

$maxUserRoot = Join-Path $env:LOCALAPPDATA "Autodesk\3ds Max\$MaxVersion - 64bit"
$languageRoot = Join-Path $maxUserRoot $Language

if (-not (Test-Path -LiteralPath $languageRoot -PathType Container)) {
    $existingLanguages = Get-ChildItem -LiteralPath $maxUserRoot -Directory -ErrorAction SilentlyContinue
    if ($existingLanguages -and $existingLanguages.Count -eq 1) {
        $languageRoot = $existingLanguages[0].FullName
    }
}

$startupPath = Join-Path $languageRoot "scripts\Startup"
$maxScriptSource = Join-Path $packageRoot "MaxScript\MaxToUnityBridge.ms"
$maxScriptTarget = Join-Path $startupPath "MaxToUnityBridge.ms"

if (-not (Test-Path -LiteralPath $maxScriptSource -PathType Leaf)) {
    throw "安装包缺少 MaxScript: $maxScriptSource"
}

New-Item -ItemType Directory -Path $startupPath -Force | Out-Null
Copy-Item -LiteralPath $maxScriptSource -Destination $maxScriptTarget -Force
Write-Step "3ds Max 脚本已安装: $maxScriptTarget"

$unityEditorSource = Join-Path $packageRoot "Unity\Assets\MaxToUnityBridge\Editor"
$unityEditorTarget = Join-Path $assetsPath "MaxToUnityBridge\Editor"

if (-not (Test-Path -LiteralPath $unityEditorSource -PathType Container)) {
    throw "安装包缺少 Unity Editor 脚本: $unityEditorSource"
}

New-Item -ItemType Directory -Path $unityEditorTarget -Force | Out-Null
Copy-Item -Path (Join-Path $unityEditorSource "*") -Destination $unityEditorTarget -Recurse -Force
Write-Step "Unity Editor 脚本已安装: $unityEditorTarget"

$shaderMatches = Get-ChildItem -LiteralPath $assetsPath -Recurse -Filter "*.shader" -File -ErrorAction SilentlyContinue |
    Select-String -SimpleMatch 'Shader "PaiPai/BigLand/Lit_BigLand_OptimizePBR"'

if ($shaderMatches) {
    Write-Step "已检测到目标 Shader。"
}
else {
    Write-Warning "尚未在 Assets 中检测到 Shader 'PaiPai/BigLand/Lit_BigLand_OptimizePBR'。请把 Lit_BigLand_OptimizePBR.shader 放回原 PaiPai Shader 目录，确保其相对 include 和包依赖有效。"
}

Write-Host ""
Write-Host "安装完成。" -ForegroundColor Green
Write-Host "1. 重启 3ds Max $MaxVersion。"
Write-Host "2. 在 Customize User Interface > Toolbars 中，分类选择 'PaiPai Tools'，把 'Max → Unity' 拖到工具栏。"
Write-Host "3. 首次打开时选择 Unity 工程 Assets 内的输出目录；后续设置会自动保存。"
Write-Host "4. Unity 中生成结果位于所选输出目录下。"