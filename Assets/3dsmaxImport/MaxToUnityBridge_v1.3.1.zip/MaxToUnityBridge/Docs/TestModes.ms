﻿-- Batch-only smoke test: run in an empty 3dsmaxbatch process, never in a working scene.
-- Writes FBX/JSON into a new scratch folder, not into the user's Unity project.
(
    local io = dotNetClass "System.IO.Path"
    local folder = io.Combine (io.GetTempPath()) ("MTU_Test_" + ((dotNetClass "System.Guid").NewGuid()).ToString())
    makeDir (folder + "\\ProjectSettings") all:true
    (dotNetClass "System.IO.File").WriteAllText (folder + "\\ProjectSettings\\ProjectVersion.txt") "m_EditorVersion: 2022.3.62f3"
    local dest = folder + "\\Assets\\Test"
    makeDir dest all:true
    fileIn ((getFilenamePath (getSourceFileName())) + "..\\MaxScript\\MaxToUnityBridge.ms")
    -- Recreate the same modeless rollout and exercise each mode after a GC/redraw.
    for pass = 1 to 2 do (
        createDialog ::MaxToUnityBridgeDialog width:588 height:577
        local ui = ::MaxToUnityBridgeDialog
        for mode = 1 to 3 do (
            ui.radMode.state = mode
            ui.updateMode()
            gc light:true
            windows.processPostedMessages()
            if ui.btnExport.text == "" or ui.txtExportName.enabled != (mode != 2) do throw "UI mode regression"
        )
        destroyDialog ui
    )
    format "MTU_NATIVE_UI_OK\n"
    local a = box name:"MTU_TestA" pos:[5,15,0]
    local b = sphere name:"MTU_TestB" pos:[45,15,0]
    a.material = StandardMaterial name:"A"; b.material = StandardMaterial name:"B"
    select #(a,b)
    for k = 1 to 3 do (
        ::mtuExportSelectedToUnity dest ("Mode" + (k as string)) ::MaxToUnityBridgeUnityShaderName 1.0 mode:k
        if selection.count != 2 or not a.isSelected or not b.isSelected do throw "Selection not restored"
    )
    for n in #("Mode1", "MTU_TestA", "MTU_TestB", "Mode3") do (
        if not doesFileExist (dest + "\\Incoming\\" + n + ".mtu.json") do throw ("Missing manifest: " + n)
        if not doesFileExist (dest + "\\Incoming\\" + n + ".fbx") do throw ("Missing model: " + n)
    )
    format "MTU_MODES_OK: %\n" dest
)