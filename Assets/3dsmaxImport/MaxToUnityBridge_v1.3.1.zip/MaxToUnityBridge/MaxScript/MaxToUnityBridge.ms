﻿/*
    MaxToUnityBridge
    -----------------
    3ds Max 端：
      1. 将当前选中的几何体临时合并为一个多材质对象
      2. 导出 FBX 到 Unity 工程的 Assets/MaxToUnityBridge/Incoming
      3. 复制贴图并写入 JSON 清单
    Unity Editor 端会自动接收 JSON 清单并生成 Material + Prefab。

    注意：导出过程不会修改原场景对象。临时对象在导出后自动删除。
*/

global MaxToUnityBridgeVersion = "1.3.1"
global MaxToUnityBridgeUnityShaderName = "PaiPai/BigLand/Lit_BigLand_OptimizePBR"
-- Asset-relative paths are resolved per export.
global MaxToUnityBridgeConfigPath = (getDir #userScripts) + "\\MaxToUnityBridge\\settings.ini"
global MaxToUnityBridgeDialog

struct MtuTextureRecord (
    role,
    sourcePath,
    packed,
    invert
)

struct MtuMaterialRecord (
    slotIndex,
    tempName,
    sourceName,
    baseColor,
    metallic,
    roughness,
    normalStrength,
    textures,
    emissionColor,
    enableEmission,
    coverage,
    coverageNormalStrength,
    tempMaterial
)

struct MtuCopiedTexture (
    sourcePath,
    assetPath
)

global MtuSupportedTextureExtensions = #(
    ".png", ".jpg", ".jpeg", ".tga", ".tif", ".tiff",
    ".bmp", ".psd", ".exr", ".hdr", ".dds"
)

fn mtuJoinPath baseDir childPath = (
    local a = baseDir as string
    local b = childPath as string
    while a.count > 0 and ((substring a a.count 1) == "\\" or (substring a a.count 1) == "/") do
        a = substring a 1 (a.count - 1)
    while b.count > 0 and ((substring b 1 1) == "\\" or (substring b 1 1) == "/") do
        b = substring b 2 (b.count - 1)
    if a.count == 0 then b else (a + "\\" + b)
)

fn mtuEnsureDir dirPath = (
    if dirPath != undefined and (dirPath as string).count > 0 do
        makeDir (dirPath as string) all:true
)

fn mtuToAssetPath localPath = (
    substituteString (localPath as string) "\\" "/"
)

fn mtuSanitizeName value = (
    local s = if value == undefined then "" else (value as string)
    for ch in #("\\", "/", ":", "*", "?", "\"", "<", ">", "|", " ") do
        s = substituteString s ch "_"
    s = substituteString s "." "_"
    s = substituteString s "\t" "_"
    s = substituteString s "\r" "_"
    s = substituteString s "\n" "_"
    if s.count == 0 then s = "Export"
    if s.count > 80 then s = substring s 1 80
    s
)

fn mtuJsonEscape value = (
    local s = if value == undefined then "" else (value as string)
    s = substituteString s "\\" "\\\\"
    s = substituteString s "\"" "\\\""
    s = substituteString s "\r" "\\r"
    s = substituteString s "\n" "\\n"
    s = substituteString s "\t" "\\t"
    s
)

fn mtuJsonString value = (
    "\"" + (mtuJsonEscape value) + "\""
)

fn mtuJsonNumber value = (
    local result = if value == undefined then "0.0" else (formattedPrint (value as float) format:".6f")
    substituteString result "," "."
)

fn mtuJsonBool value = (
    if value then "true" else "false"
)

fn mtuJsonColor c = (
    local v = if c == undefined then #(1.0, 1.0, 1.0, 1.0) else #(c.r, c.g, c.b, c.a)
    "[" + (mtuJsonNumber v[1]) + "," + (mtuJsonNumber v[2]) + "," + (mtuJsonNumber v[3]) + "," + (mtuJsonNumber v[4]) + "]"
)

fn mtuContainsText haystack needle = (
    if haystack == undefined or needle == undefined then false
    else (findString (toLower (haystack as string)) (toLower (needle as string)) != undefined)
)

fn mtuTryReadProperty target propName = (
    local ok = false
    local value = undefined
    try (
        value = getProperty target propName
        ok = true
    ) catch ()
    #(ok, value)
)

fn mtuReadFirstColor target names defaultColor = (
    for n in names do (
        local result = mtuTryReadProperty target n
        if result[1] and result[2] != undefined and isKindOf result[2] Color do
            return result[2]
    )
    defaultColor
)

fn mtuReadFirstNumber target names defaultValue = (
    for n in names do (
        local result = mtuTryReadProperty target n
        if result[1] and result[2] != undefined then (
            local c = classOf result[2]
            if c == Integer or c == Float or c == Double do
                return (result[2] as float)
        )
    )
    defaultValue
)

fn mtuClamp01 value = (
    if value < 0.0 then 0.0 else if value > 1.0 then 1.0 else value
)

fn mtuMaterialKey mat = (
    if mat == undefined then "DEFAULT"
    else (
        local h = 0
        try (h = getHandleByAnim mat) catch ()
        if h == 0 then ((classOf mat as string) + "|" + (mat.name as string))
        else ("H:" + (h as string))
    )
)

fn mtuNormalizeTexturePath filePath = (
    if filePath == undefined then return ""
    local s = filePath as string
    if s.count == 0 then return ""
    if doesFileExist s then return s

    local resolved = ""
    try (resolved = mapPaths.getFullFilePath s) catch ()
    if resolved != undefined and resolved.count > 0 and doesFileExist resolved then return resolved

    if maxFilePath != undefined and maxFilePath.count > 0 then (
        local candidate = mtuJoinPath maxFilePath s
        if doesFileExist candidate then return candidate
    )

    s
)

fn mtuGetTextureExtension filePath = (
    toLower (getFilenameType (filePath as string))
)

fn mtuIsSupportedTexture filePath = (
    local ext = mtuGetTextureExtension filePath
    findItem MtuSupportedTextureExtensions ext > 0
)

fn mtuGetFilenameFromMap map = (
    if not (isKindOf map TextureMap) do return ""

    local directNames = #("filename", "fileName", "file", "HDRIMapName", "hdriMapName", "bitmapName", "mapName")
    for n in directNames do (
        local result = mtuTryReadProperty map n
        if result[1] and result[2] != undefined do (
            local candidate = result[2] as string
            if candidate.count > 0 and mtuIsSupportedTexture candidate do
                return (mtuNormalizeTexturePath candidate)
        )
    )

    local propNames = #()
    try (propNames = getPropNames map) catch (); if propNames == undefined do propNames = #()
    for p in propNames do (
        local result = mtuTryReadProperty map p
        if result[1] and result[2] != undefined do (
            local candidate = ""
            try (candidate = result[2] as string) catch ()
            if candidate.count > 0 and mtuIsSupportedTexture candidate do
                return (mtuNormalizeTexturePath candidate)
        )
    )

    local subCount = 0
    try (subCount = getNumSubTexmaps map) catch ()
    for i = 1 to subCount do (
        local subMap = undefined
        try (subMap = getSubTexmap map i) catch ()
        local found = mtuGetFilenameFromMap subMap
        if found.count > 0 do return found
    )

    ""
)

fn mtuIsTextureLike candidate = (
    if not (isKindOf candidate TextureMap) then false
    else (
        local filename = mtuGetFilenameFromMap candidate
        if filename.count > 0 then true
        else (
            local subCount = 0
            try (subCount = getNumSubTexmaps candidate) catch ()
            subCount > 0
        )
    )
)

fn mtuInferTextureRole propertyName fileName = (
    local s = toLower ((propertyName as string) + " " + (fileName as string))

    if mtuContainsText s "coverage" or mtuContainsText s "cover" do (
        if mtuContainsText s "noise" or mtuContainsText s "blend" do return #("CoverageNoise", false)
        if mtuContainsText s "normal" do return #("CoverageNormal", false)
        return #("CoverageAlbedo", false)
    )

    if mtuContainsText s "normal" or mtuContainsText s "bump" do
        return #("NormalMap", false)

    if mtuContainsText s "gloss" do
        return #("RoughnessMap", true)

    if mtuContainsText s "rough" do
        return #("RoughnessMap", false)

    if mtuContainsText s "metal" do
        return #("MetallicMap", false)

    if mtuContainsText s "ao" or mtuContainsText s "occlusion" do
        return #("OcclusionMap", false)

    if mtuContainsText s "emiss" or mtuContainsText s "selfillum" or mtuContainsText s "illum" do
        return #("EmissionMap", false)

    if mtuContainsText s "diffuse" or mtuContainsText s "basecolor" or mtuContainsText s "albedo" or mtuContainsText s "color" do
        return #("BaseMap", false)

    #("", false)
)

fn mtuTextureAlreadyExists list role sourcePath = (
    for item in list where item.role == role and item.sourcePath == sourcePath do
        return true
    false
)

fn mtuAddTextureRecord list role sourcePath invert:false = (
    if role == undefined or role == "" then return list
    if sourcePath == undefined or sourcePath == "" then return list
    if mtuTextureAlreadyExists list role sourcePath then return list

    local packed = false
    if role == "NormalMap" do (
        local n = toLower ((getFilenameFile sourcePath) + (getFilenameType sourcePath))
        if mtuContainsText n "orm" or mtuContainsText n "rma" or mtuContainsText n "mra" or mtuContainsText n "packed" do
            packed = true
    )

    append list (MtuTextureRecord role sourcePath packed invert)
    list
)

fn mtuCollectMaterialTextures mat = (
    local textures = #()
    if mat == undefined do return textures

    local knownSlots = #(
        #("BaseMap", #("base_color_map", "diffuseMap", "texmap_diffuse", "texmap_basecolor", "baseColorMap", "baseColorTexture", "diffuseTex", "diffuseTexture", "base_color_tex")),
        #("NormalMap", #("bump_map", "bumpMap", "texmap_bump", "normalMap", "normal_map", "normalTex", "normalTexture", "bumpTexture")),
        #("RoughnessMap", #("roughness_map", "roughnessMap", "texmap_roughness", "roughnessTex", "roughnessTexture")),
        #("RoughnessMap", #("texmap_reflectionGlossiness", "reflectionGlossinessMap", "glossinessMap", "glossinessTex"), true),
        #("MetallicMap", #("metalness_map", "metallic_map", "metalnessMap", "metallicMap", "texmap_metalness", "metalnessTexture", "metallicTexture")),
        #("EmissionMap", #("emission_color_map", "emissionMap", "selfIllumMap", "texmap_emissive", "emissiveMap", "emissionColorMap", "emissionTexture")),
        #("CoverageAlbedo", #("coverage_albedo_map", "coverageAlbedoMap", "coverageAlbedo", "coverageMap")),
        #("CoverageNormal", #("coverage_normal_map", "coverageNormalMap", "coverageNormal")),
        #("CoverageNoise", #("coverage_noise_map", "coverageNoiseMap", "coverageNoise", "coverageBlendMap"))
    )

    for spec in knownSlots do (
        local role = spec[1]
        local invert = spec.count > 2 and spec[3]

        for propName in spec[2] do (
            local result = mtuTryReadProperty mat propName
            if result[1] and result[2] != undefined do (
                local filename = mtuGetFilenameFromMap result[2]
                if filename.count > 0 do (
                    textures = mtuAddTextureRecord textures role filename invert:invert
                    exit
                )
            )
        )
    )

    local propNames = #()
    try (propNames = getPropNames mat) catch (); if propNames == undefined do propNames = #()
    for p in propNames do (
        local result = mtuTryReadProperty mat p
        if result[1] and (mtuIsTextureLike result[2]) do (
            local filename = mtuGetFilenameFromMap result[2]
            if filename.count > 0 do (
                local inferred = mtuInferTextureRole (p as string) filename
                if inferred[1] != "" do
                    textures = mtuAddTextureRecord textures inferred[1] filename invert:inferred[2]
            )
        )
    )

    textures
)

fn mtuReadMetallic mat = (
    mtuClamp01 (mtuReadFirstNumber mat #("metalness", "metallic", "metalnessAmount", "metalnessMapAmount") 0.0)
)

fn mtuReadRoughness mat = (
    local rough = mtuReadFirstNumber mat #("roughness", "roughnessAmount", "diffuseRoughness") -1.0
    if rough >= 0.0 do return (mtuClamp01 rough)

    local gloss = mtuReadFirstNumber mat #("glossiness", "reflectionGlossiness", "specularGlossiness") -1.0
    if gloss >= 0.0 do (
        if gloss > 1.0 do gloss = gloss / 100.0
        return (mtuClamp01 (1.0 - gloss))
    )

    0.5
)

fn mtuReadNormalStrength mat = (
    local value = mtuReadFirstNumber mat #("bump_map_amt", "bumpAmount", "normalStrength", "normalMapAmount", "bumpAmount") 1.0
    if value < 0.0 then value = 0.0
    if value > 2.0 then value = 2.0
    value
)

fn mtuHasVisibleEmission mat emissionColor emissionMap = (
    if emissionMap != undefined and emissionMap.count > 0 then true
    else (
        local maxChannel = amax #(emissionColor.r, emissionColor.g, emissionColor.b)
        maxChannel > 0.001
    )
)

fn mtuRegisterMaterial mat materialKeys materialRecords tempMaterials = (
    local key = mtuMaterialKey mat
    local existing = 0
    for i = 1 to materialKeys.count where materialKeys[i] == key do
        existing = i

    if existing > 0 do return existing

    local slotIndex = materialRecords.count
    local tempName = "__MTU_M" + (formattedPrint slotIndex format:"04d")
    local baseColor = if mat == undefined then (color 0.8 0.8 0.8) else (mtuReadFirstColor mat #("base_color", "diffuse", "baseColor", "diffuseColor", "color") (color 0.8 0.8 0.8))
    local metallic = if mat == undefined then 0.0 else (mtuReadMetallic mat)
    local roughness = if mat == undefined then 0.5 else (mtuReadRoughness mat)
    local normalStrength = if mat == undefined then 1.0 else (mtuReadNormalStrength mat)
    local textures = if mat == undefined then #() else (mtuCollectMaterialTextures mat)
    local emissionColor = if mat == undefined then (color 0.0 0.0 0.0) else (mtuReadFirstColor mat #("emission_color", "emissionColor", "selfIllumColor", "selfIllumination", "emissiveColor") (color 0.0 0.0 0.0))
    local emissionMap = ""
    for tex in textures where tex.role == "EmissionMap" do emissionMap = tex.sourcePath
    local enableEmission = mtuHasVisibleEmission mat emissionColor emissionMap

    local sourceName = if mat == undefined then "Default" else (mat.name as string)
    local tempMat = StandardMaterial name:tempName diffuse:baseColor
    local record = MtuMaterialRecord slotIndex tempName sourceName baseColor metallic roughness normalStrength textures emissionColor enableEmission 0.0 1.0 tempMat

    append materialKeys key
    append materialRecords record
    append tempMaterials tempMat
    materialRecords.count
)

fn mtuGetMaterialSlots mat = (
    if mat == undefined then #(undefined)
    else if isKindOf mat Multimaterial then (
        local result = #()
        for i = 1 to mat.materialList.count do
            append result mat.materialList[i]
        if result.count == 0 then result = #(undefined)
        result
    ) else #(mat)
)

fn mtuCollectGeometryNode node result seen = (
    if node == undefined or not (isValidNode node) do return false
    if findItem seen node > 0 do return false
    append seen node

    if isGroupHead node then (
        for child in node.children do mtuCollectGeometryNode child result seen
    ) else if superClassOf node == GeometryClass then (
        append result node
    )
    true
)

fn mtuCollectSelectedGeometry = (
    local result = #()
    local seen = #()
    for node in selection do mtuCollectGeometryNode node result seen
    result
)

fn mtuCopyTextureToUnity sourcePath materialIndex role bridgeRoot assetRoot exportName copiedTextures = (
    local normalized = mtuNormalizeTexturePath sourcePath
    if normalized.count == 0 or not (doesFileExist normalized) do return ""
    if not (mtuIsSupportedTexture normalized) do return ""

    for copied in copiedTextures where copied.sourcePath == normalized do
        return copied.assetPath

    local textureDir = mtuJoinPath (mtuJoinPath bridgeRoot "Textures") exportName
    mtuEnsureDir textureDir

    local ext = mtuGetTextureExtension normalized
    local baseName = mtuSanitizeName (getFilenameFile normalized)
    local destName = (formattedPrint materialIndex format:"04d") + "_" + (mtuSanitizeName role) + "_" + baseName + ext
    local destPath = mtuJoinPath textureDir destName
    local assetPath = assetRoot + "/Textures/" + exportName + "/" + destName

    if (toLower normalized) != (toLower destPath) do (
        if doesFileExist destPath do deleteFile destPath
        (dotNetClass "System.IO.File").Copy normalized destPath true
    )
    if not (doesFileExist destPath) do return ""

    append copiedTextures (MtuCopiedTexture normalized assetPath)
    assetPath
)

fn mtuWriteManifest bridgeRoot assetRoot manifestPath exportName fbxAssetPath shaderName importScale materialRecords copiedTextures childNames = (
    mtuEnsureDir (getFilenamePath manifestPath)
    local tempManifestPath = manifestPath + ".tmp"
    if doesFileExist tempManifestPath do deleteFile tempManifestPath
    local stream = StringStream ""

    local timestamp = ""
    try (timestamp = ((dotNetClass "System.DateTime").UtcNow.ToString("o")) as string) catch ()

    format "{\n" to:stream
    format "  \"version\": 1,\n" to:stream
    format "  \"prefabName\": %,\n" (mtuJsonString exportName) to:stream
    format "  \"fbxAssetPath\": %,\n" (mtuJsonString fbxAssetPath) to:stream
    format "  \"shaderName\": %,\n" (mtuJsonString shaderName) to:stream
    format "  \"importScale\": %,\n" (mtuJsonNumber importScale) to:stream
    format "  \"exportTimeUtc\": %,\n" (mtuJsonString timestamp) to:stream
    format "  \"childNames\": [" to:stream
    for k = 1 to childNames.count do (
        if k > 1 do format "," to:stream
        format "%" (mtuJsonString childNames[k]) to:stream
    )
    format "],\n" to:stream
    format "  \"materials\": [\n" to:stream

    for i = 1 to materialRecords.count do (
        local rec = materialRecords[i]
        format "    {\n" to:stream
        format "      \"slot\": %,\n" rec.slotIndex to:stream
        format "      \"name\": %,\n" (mtuJsonString rec.sourceName) to:stream
        format "      \"tempMaterialName\": %,\n" (mtuJsonString rec.tempName) to:stream
        format "      \"baseColor\": %,\n" (mtuJsonColor rec.baseColor) to:stream
        format "      \"metallic\": %,\n" (mtuJsonNumber rec.metallic) to:stream
        format "      \"roughness\": %,\n" (mtuJsonNumber rec.roughness) to:stream
        format "      \"normalStrength\": %,\n" (mtuJsonNumber rec.normalStrength) to:stream
        format "      \"emissionColor\": %,\n" (mtuJsonColor rec.emissionColor) to:stream
        format "      \"enableEmission\": %,\n" (mtuJsonBool rec.enableEmission) to:stream
        format "      \"coverage\": %,\n" (mtuJsonNumber rec.coverage) to:stream
        format "      \"coverageNormalStrength\": %,\n" (mtuJsonNumber rec.coverageNormalStrength) to:stream
        format "      \"textures\": [\n" to:stream

        local written = 0
        for tex in rec.textures do (
            local assetPath = mtuCopyTextureToUnity tex.sourcePath rec.slotIndex tex.role bridgeRoot assetRoot exportName copiedTextures
            if assetPath.count > 0 do (
                if written > 0 do format ",\n" to:stream
                format "        {\"role\": %, \"assetPath\": %, \"sourcePath\": %, \"packed\": %, \"invert\": %}" (mtuJsonString tex.role) (mtuJsonString assetPath) (mtuJsonString tex.sourcePath) (mtuJsonBool tex.packed) (mtuJsonBool tex.invert) to:stream
                written += 1
            )
        )

        format "\n      ]\n" to:stream
        format "    }" to:stream
        if i < materialRecords.count do format "," to:stream
        format "\n" to:stream
    )

    format "  ]\n" to:stream
    format "}\n" to:stream
    local jsonText = stream as string
    local utf8NoBom = dotNetObject "System.Text.UTF8Encoding" false
    (dotNetClass "System.IO.File").WriteAllText tempManifestPath jsonText utf8NoBom

    if doesFileExist manifestPath do deleteFile manifestPath
    (dotNetClass "System.IO.File").Move tempManifestPath manifestPath
)
-- Resolve against a real Unity project's Assets directory, not a substring of the path.
fn mtuResolveDestination folder = (
    if folder == undefined or folder == "" do throw "请选择工程 Assets 下的导出目录。"
    local dir = dotNetObject "System.IO.DirectoryInfo" folder
    if not dir.Exists do throw ("目录不存在：" + folder)
    local full = trimRight dir.FullName "\\/"
    local current = dir
    while current != undefined do (
        local parentDir = current.Parent
        if (toLower current.Name) == "assets" and parentDir != undefined do (
            local versionFile = mtuJoinPath parentDir.FullName "ProjectSettings\\ProjectVersion.txt"
            if doesFileExist versionFile do (
                local base = trimRight current.FullName "\\/"
                local relative = if full.count == base.count then "" else (substring full (base.count + 1) -1)
                return #(full, "Assets" + (mtuToAssetPath relative))
            )
        )
        current = parentDir
    )
    throw "所选目录不在 Unity 工程的 Assets 内。请选择 Assets 或其子文件夹。"
)

fn mtuExportUnit folder exportName shaderName importScale sourceObjects keepChildren = (
    local destination = mtuResolveDestination folder
    local bridgeRoot = destination[1]
    local assetRoot = destination[2]
    local safeName = mtuSanitizeName exportName
    local incomingDir = mtuJoinPath bridgeRoot "Incoming"
    mtuEnsureDir incomingDir

    local fbxPath = mtuJoinPath incomingDir (safeName + ".fbx")
    local suffix = if (toLower assetRoot) == "assets/maxtounitybridge" then ".json" else ".mtu.json"
    local manifestPath = mtuJoinPath incomingDir (safeName + suffix)
    local fbxAssetPath = assetRoot + "/Incoming/" + safeName + ".fbx"

    local childNames = #()
    if sourceObjects.count == 0 do throw "请至少选中一个可导出的几何体。"

    local oldSelection = selection as array
    local materialKeys = #()
    local materialRecords = #()
    local tempMaterials = #()
    local objectSlotMaps = #()
    local clones = #()
    local copiedTextures = #()
    local mergedNode = undefined
    local caughtError = undefined
    local resultMessage = ""

    try (
        with redraw off (
            for sourceObj in sourceObjects do (
                local sourceSlots = mtuGetMaterialSlots sourceObj.material
                local slotMap = #()
                for sourceMat in sourceSlots do (
                    local globalSlot = mtuRegisterMaterial sourceMat materialKeys materialRecords tempMaterials
                    append slotMap globalSlot
                )
                append objectSlotMaps slotMap
            )

            local finalMaterial
            if tempMaterials.count == 1 then
                finalMaterial = tempMaterials[1]
            else (
                finalMaterial = Multimaterial numsubs:tempMaterials.count
                for i = 1 to tempMaterials.count do finalMaterial.materialList[i] = tempMaterials[i]
            )

            for objIndex = 1 to sourceObjects.count do (
                local sourceObj = sourceObjects[objIndex]
                local cloneObj = copy sourceObj
                append clones cloneObj

                local worldTransform = cloneObj.transform
                cloneObj.parent = undefined
                cloneObj.transform = worldTransform

                convertToPoly cloneObj
                local faceCount = polyop.getNumFaces cloneObj
                local slotMap = objectSlotMaps[objIndex]
                cloneObj.material = finalMaterial

                for faceIndex = 1 to faceCount do (
                    local oldMatID = polyop.getFaceMatID cloneObj faceIndex
                    if isKindOf sourceObj.material Multimaterial do oldMatID = findItem sourceObj.material.materialIDList oldMatID
                    if oldMatID < 1 or oldMatID > slotMap.count do oldMatID = 1
                    polyop.setFaceMatID cloneObj faceIndex slotMap[oldMatID]
                )
            )

            if keepChildren then (
                -- An explicit transform parent also keeps the single-child case unambiguous.
                local pivot = sourceObjects[1].transform.row4
                local holder = Dummy name:"MTU_GroupRoot" pos:[0,0,0]
                local members = clones as array
                append clones holder -- cleanup also on export failure
                for k = 1 to sourceObjects.count do (
                    local part = members[k]
                    local tm = copy part.transform
                    tm.row4 = tm.row4 - pivot
                    part.parent = holder
                    part.transform = tm
                    part.name = "MTU_Node_" + (k as string)
                    append childNames (sourceObjects[k].name as string)
                )
                select clones
            ) else (
                mergedNode = clones[1]
                for i = 2 to clones.count do (
                    local attachNode = clones[i]
                    if isValidNode attachNode do (
                        try (polyop.attach mergedNode attachNode) catch ()
                        if isValidNode attachNode do throw ("合并几何体失败: " + attachNode.name)
                    )
                )
    
                mergedNode.name = safeName
                mergedNode.material = finalMaterial
                clearSelection()
                select mergedNode
            )

            if doesFileExist fbxPath do deleteFile fbxPath
            if doesFileExist manifestPath do deleteFile manifestPath

            try (FBXExporterSetParam "EmbedTextures" false) catch ()
            try (FBXExporterSetParam "Animation" false) catch ()
            try (FBXExporterSetParam "Cameras" false) catch ()
            try (FBXExporterSetParam "Lights" false) catch ()
            try (FBXExporterSetParam "SmoothingGroups" true) catch ()
            try (FBXExporterSetParam "TangentSpaceExport" true) catch ()
            try (FBXExporterSetParam "Triangulate" true) catch ()

            local exportOk = exportFile fbxPath #noPrompt selectedOnly:true
            if exportOk == false or not (doesFileExist fbxPath) do throw ("FBX 导出失败: " + fbxPath)

            mtuWriteManifest bridgeRoot assetRoot manifestPath safeName fbxAssetPath shaderName importScale materialRecords copiedTextures childNames
            resultMessage = "导出完成：" + safeName + "\nUnity 将自动生成 Material 和 Prefab。"
        )
    ) catch (
        caughtError = getCurrentException(); format "[MaxToUnityBridge] %\n%\n" caughtError (getCurrentExceptionStackTrace())
    )

    clearSelection()
    for node in clones where node != undefined and isValidNode node do (
        try (node.material = undefined) catch ()
        try (delete node) catch ()
    )
    try (select oldSelection) catch ()

    for mat in tempMaterials do (
        try (mat = undefined) catch ()
    )

    if caughtError != undefined do throw caughtError
    resultMessage
)

fn mtuExportSelectedToUnity folder exportName shaderName importScale mode:1 = (
    local nodes = mtuCollectSelectedGeometry()
    if nodes.count == 0 do throw "请至少选中一个可导出的几何体。"
    if mode != 2 then (
        mtuExportUnit folder exportName shaderName importScale nodes (mode == 3)
        "已导出   /   " + (mtuSanitizeName exportName) + "  ·  等待 Unity 导入。"
    ) else (
        -- Preflight all names, including case-only and sanitized collisions, before writing.
        local names = #()
        local keys = #()
        for obj in nodes do (
            local n = trimRight (trimLeft (mtuSanitizeName obj.name) "_") "_"
            if n == "" do n = "Object"
            if (findItem keys (toLower n)) > 0 do throw ("分别导出遇到重名：" + n + "。请改名后重试，尚未写入文件。")
            append keys (toLower n)
            append names n
        )
        for k = 1 to nodes.count do (
            local err = undefined
            try (mtuExportUnit folder names[k] shaderName importScale #(nodes[k]) false)
            catch (err = getCurrentException())
            if err != undefined do throw ("分别导出失败：" + names[k] + "（此前已完成 " + ((k-1) as string) + " 个）\n" + (err as string))
        )
        "已分别导出 " + (nodes.count as string) + " 个模型   /   等待 Unity 创建独立 Prefab。"
    )
)
fn mtuSaveSettings = (
    if MaxToUnityBridgeDialog == undefined do return false
    mtuEnsureDir (getFilenamePath MaxToUnityBridgeConfigPath)
    setINISetting MaxToUnityBridgeConfigPath "General" "ExportMode" (MaxToUnityBridgeDialog.radMode.state as string)
    setINISetting MaxToUnityBridgeConfigPath "General" "ExportFolder" MaxToUnityBridgeDialog.txtExportFolder.text
    setINISetting MaxToUnityBridgeConfigPath "General" "ExportName" MaxToUnityBridgeDialog.txtExportName.text
    setINISetting MaxToUnityBridgeConfigPath "General" "ShaderName" MaxToUnityBridgeDialog.txtShaderName.text
    setINISetting MaxToUnityBridgeConfigPath "General" "ImportScale" (MaxToUnityBridgeDialog.spnImportScale.value as string)
    true
)

fn mtuLoadSettings = (
    local unityProject = getINISetting MaxToUnityBridgeConfigPath "General" "ExportFolder"
    local exportName = getINISetting MaxToUnityBridgeConfigPath "General" "ExportName"
    local shaderName = getINISetting MaxToUnityBridgeConfigPath "General" "ShaderName"
    local importScale = getINISetting MaxToUnityBridgeConfigPath "General" "ImportScale"

    if unityProject == undefined then unityProject = ""
    if exportName == undefined or exportName == "" then exportName = "MaxExport"
    if shaderName == undefined or shaderName == "" then shaderName = MaxToUnityBridgeUnityShaderName

    local importScaleValue = 1.0
    if importScale != undefined and importScale != "" then try (importScaleValue = importScale as float) catch ()
    if importScaleValue <= 0.0 then importScaleValue = 1.0
    local mode = try ((getINISetting MaxToUnityBridgeConfigPath "General" "ExportMode") as integer) catch (1)
    if (findItem #(1,2,3) mode) == 0 do mode = 1
    #(unityProject, exportName, shaderName, importScaleValue, mode)
)

try (destroyDialog MaxToUnityBridgeDialog) catch ()

rollout MaxToUnityBridgeDialog "Max → Unity  |  资源导出" (
    local lastCount = -1
    -- Keep all painted surfaces native: no managed Font lifetime across dialog recreation.
    groupBox grpHeader "MAX → UNITY   /   资源导出" pos:[16,14] width:556 height:65
    label heading "选取模型，设置导出方式后发送到 Unity。" pos:[32,44] width:372 height:20
    label countBadge "未选择物体" pos:[428,44] width:128 height:20

    groupBox grpOutput "01   输出位置" pos:[16,94] width:556 height:114
    label labFolder "Unity 目录" pos:[32,126] width:72 height:21
    edittext txtExportFolder "" pos:[108,121] width:362 height:26
    button btnBrowseUnity "浏览…" pos:[478,120] width:78 height:28
    label labName "资源名称" pos:[32,167] width:72 height:21
    edittext txtExportName "" pos:[108,162] width:448 height:26

    groupBox grpMaterial "02   材质与缩放" pos:[16,220] width:556 height:113
    label labShader "Shader" pos:[32,252] width:72 height:21
    edittext txtShaderName "" pos:[108,247] width:448 height:26
    label labScale "导入缩放" pos:[32,292] width:72 height:21
    spinner spnImportScale "" pos:[108,287] width:108 range:[0.0001,1000.0,1.0] type:#float
    label labScaleNote "默认 1.0，保持原始比例" pos:[232,292] width:300 height:21

    groupBox grpMode "03   导出方式" pos:[16,342] width:556 height:78
    radiobuttons radMode labels:#("合并网格", "分别导出", "保留子物体") columns:3 default:1 pos:[32,361] width:520
    label modeHint "" pos:[32,391] width:523 height:20
    button btnExport "导出到 Unity" pos:[16,433] width:556 height:44
    button btnOpenIncoming "打开导出文件夹" pos:[16,487] width:272 height:28
    button btnSaveSettings "保存设置" pos:[300,487] width:272 height:28
    label feedback "" pos:[16,529] width:556 height:34
    timer watchSelection interval:600 active:false

    fn setFeedback state msg = (feedback.text = msg)
    fn updateCount = (
        local n = selection.count
        if n != lastCount do (
            lastCount = n
            countBadge.Text = if n == 0 then "未选择物体" else ("已选择  /  " + (n as string))
        )
    )
    fn updateMode = (
        txtExportName.enabled = radMode.state != 2
        labName.enabled = radMode.state != 2
        case radMode.state of (
            1: (modeHint.text = "合为一个网格，生成一个 Prefab。"; btnExport.Text = "合并网格并导出   →")
            2: (modeHint.text = "每个物体按 Max 节点名称生成自己的 FBX 和 Prefab。"; btnExport.Text = "分别导出每个物体   →")
            3: (modeHint.text = "一个父 Prefab，模型各自保留为可编辑的直接子物体。"; btnExport.Text = "导出为父子 Prefab   →")
        )
    )
    on radMode changed newMode do updateMode()
    on MaxToUnityBridgeDialog open do (
        local settings = mtuLoadSettings()
        txtExportFolder.text = settings[1]
        txtExportName.text = settings[2]
        txtShaderName.text = settings[3]
        spnImportScale.value = settings[4]
        radMode.state = settings[5]; updateMode()
        setFeedback #idle "就绪   /   选择物体，并指定 Assets 下的输出目录。"
        lastCount = -1; updateCount(); watchSelection.active = true
    )
    on watchSelection tick do updateCount()
    on MaxToUnityBridgeDialog close do (watchSelection.active = false)

    on btnBrowseUnity pressed do (
        local current = txtExportFolder.text
        local chosen = if doesDirectoryExist current then (getSavePath caption:"选择 Assets 下的导出目录" initialDir:current) else (getSavePath caption:"选择 Assets 下的导出目录")
        if chosen != undefined do (
            try (local dest = mtuResolveDestination chosen; txtExportFolder.text = dest[1]) catch (messageBox (getCurrentException() as string) title:"导出目录")
        )
    )

    on btnOpenIncoming pressed do (
        try (
            local dest = mtuResolveDestination txtExportFolder.text
            local target = mtuJoinPath dest[1] "Incoming"
            if (dotNetClass "System.IO.Directory").Exists target then ShellLaunch target "" else messageBox "该目录尚无 Incoming，请先导出一次。"
        ) catch (messageBox (getCurrentException() as string) title:"导出目录")
    )

    on btnSaveSettings pressed do (
        mtuSaveSettings()
        setFeedback #ok "已保存   /   下次打开时将沿用这些设置。"
    )

    on btnExport pressed do (
        try (
            if txtExportFolder.text == "" do throw "请选择 Assets 下的导出目录。"
            if radMode.state != 2 and txtExportName.text == "" do throw "请填写导出名称。"
            if txtShaderName.text == "" do throw "请填写 Unity Shader 名称。"

            mtuSaveSettings()
            setFeedback #busy "导出中   /   正在导出网格、贴图和清单…"
            local report = mtuExportSelectedToUnity txtExportFolder.text txtExportName.text txtShaderName.text spnImportScale.value mode:radMode.state
            setFeedback #ok report
        ) catch (
            local message = getCurrentException()
            setFeedback #error ("导出失败   /   " + (message as string))
            messageBox message title:"Max → Unity 导出失败"
        )
    )
)

macroScript MaxToUnityBridge
category:"PaiPai Tools"
buttonText:"Max → Unity"
tooltip:"合并选中物体并自动同步到 Unity"
(
    on execute do (
        try (destroyDialog MaxToUnityBridgeDialog) catch ()
        createDialog MaxToUnityBridgeDialog width:588 height:577
    )
)

format "[MaxToUnityBridge] 已加载 v%\n" MaxToUnityBridgeVersion