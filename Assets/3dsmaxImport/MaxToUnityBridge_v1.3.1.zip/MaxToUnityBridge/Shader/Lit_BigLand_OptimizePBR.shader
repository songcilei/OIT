Shader "PaiPai/BigLand/Lit_BigLand_OptimizePBR"
{
    Properties
    {
        [HideInInspector] _PaiPaiTerrainLightmap("Terrain Batch Lightmap", 2D) = "black" {}
        [HideInInspector] _PaiPaiTerrainShadowMask("Terrain Batch Shadow Mask", 2D) = "white" {}
        [MainTexture] [NoScaleOffset]_BaseMap("主贴图 A:alpha", 2D) = "white" {} 
        [HDR]_BaseMapColor("主贴图颜色", Color) = (1,1,1,1)

        _Metallic("Metallic", Range(0,1)) = 0
        _Roughness("roughness", Range(0.01,1)) = 0.5
        [NoScaleOffset] _NormalMap("RG:normal.xy--B:roughness--A: metallic", 2D) = "bump" {}
        _NormalStrength("法线强度", Range(0, 2)) = 1.0

        [Foldout(_IBL_SPEC_ON)]_IBLAOEnable("环境光阴影遮蔽",Range(0,1))=0
        [if(_IBLAOEnable)] _IBL_AO_Scale("环境光阴影遮蔽",Range(0,1)) = 0

        [Foldout(_Coverage_On)] _Coverage("覆盖效果", Range (0,1)) = 0
        [if(_Coverage)][Toggle(_Coverage_ON)] _Coverage_On ("Coverage_ON", Float) = 0
        [if(_Coverage)]_TopOffset("Top Offset", Range(0,1)) = 0.5
        [if(_Coverage)]_TopContrast("Top Contrast", Range(0,2)) = 1
        [if(_Coverage)]_TopIntensity("Top Intensity", Range(0,1)) = 1
        [Space(10)]

        [if(_Coverage)] _CoverageAlbedo("覆盖贴图", 2D) = "white" {}
        [if(_Coverage)] [NoScaleOffset]_CoverageNormal("覆盖法线和强度", 2D) = "white" {}
        [if(_Coverage)] [NoScaleOffset]_BlendHeight("混合高度", Float) = 0
        [if(_Coverage)] [NoScaleOffset]_CoverageScale("混合图强度", Float) = 1
        [if(_Coverage)] _CoverageNoise("覆盖混合图", 2D) = "black" {}
        [if(_Coverage)] _CoverageNormalStrength("覆盖法线强度", Range(0, 2)) = 1.0
        [if(_Coverage)] _CoverageLerp("法线的混合和覆盖",Range(0,1)) = 0.0
        // [if(_Coverage)] _CoverageRoughness("覆盖粗糙度",Range (0,1))=1

        [Foldout(_EmissionEnabled)] _Emission("自发光",Range (0,1)) = 0 
        [if(_Emission)] [Toggle(_EMISSION)] _EmissionEnabled ("自发光开关", Float) = 0
        [if(_Emission)] [NoScaleOffset] _EmissionMap("Emission", 2D) = "white" {}
        [if(_Emission)] [HDR] _EmissionColor("EmissionColor", Color) = (0.0, 0.0, 0.0, 0.0)

        [Foldout]_Advance("改变阴影",Range (0,1)) = 0  
        [if(_Advance)][KeywordEnum(On, Clip,Off)] _Shadows ("阴影设置", Float) = 0 
        [if(_Advance)][Enum(Off, 0, On, 1)] _ZWrite ("Z Write", Float) = 1 
        [if(_Advance)][Enum(UnityEngine.Rendering.CompareFunction)] _ZTest ("ZTest", Float) = 4
//        [if(_Advance)]_ShadowInternalOffset("ShadowInternalOffset",Range(0,1))=1
        [HideInInspector] _StencilRef("Stencil Ref for Outline", Int) = 2
        [HideInInspector] _Clipping ("Alpha Clipping", Range(0,1)) = 0
        [HideInInspector] _Surface("__surface", Float) = 0.0
        [HideInInspector] _Blend("__blend", Float) = 0.0 
        [HideInInspector] _SrcBlend("__src", Float) = 1.0
        [HideInInspector] _DstBlend("__dst", Float) = 0.0
        [HideInInspector] _Cull("__cull", Float) = 2.0
        [HideInInspector] _RenderQueue("Render Queue", Float) = 2000
    }

    HLSLINCLUDE
    #include "Packages/com.ifreetalk.render-pipeline/Shaders/ShaderLibrary/Common.hlsl"
    #include "../ShaderLibrary/InstancingCommon.hlsl"
    CBUFFER_START(UnityPerMaterial)
        half4 _BaseMap_ST;
        half4 _CoverageAlbedo_ST;
        half4 _CoverageNoise_ST;
        half4 _BaseMapColor;

        half4 _EmissionColor;
        // half4 _EffCol;

        half _Metallic;
        half _Roughness;
        half _NormalStrength;
        half _CoverageNormalStrength;

        // half _CoverageRoughness;
        half _TopOffset;
        half _TopContrast;
        half _TopIntensity;
        half _BlendHeight;
        half _CoverageScale;

        half _DitherNear;
        half _DitherFar;
        half _FrameState ;
        half _ShadowInternalOffset;
        half _IBL_AO_Scale;
        half _CoverageLerp;
    CBUFFER_END

    half _MatcapIntensity;
    half4 _ElevationAngle;
    // half4 _EffParams;

    // Debug
    half _DBG_Diffuse;
    half _DBG_Specular;
    half _DBG_Sky;
    half _DBG_Matcap;

    TEXTURE2D(_BaseMap);
    SAMPLER(sampler_BaseMap);
    TEXTURE2D(_NormalMap);
    SAMPLER(sampler_NormalMap);
    TEXTURE2D(_MatcapTex);
    SAMPLER(sampler_MatcapTex);
    TEXTURE2D(_CoverageAlbedo);
    SAMPLER(sampler_CoverageAlbedo);
    TEXTURE2D(_CoverageNoise);
    SAMPLER(sampler_CoverageNoise);
    TEXTURE2D(_CoverageNormal);
    SAMPLER(sampler_CoverageNormal);
    TEXTURE2D(_EmissionMap);
    SAMPLER(sampler_EmissionMap);

    ENDHLSL

    SubShader
    {
        Tags
        {
            "RenderType"="Opaque"
            "RenderPipeline" = "PaiPaiRenderPipeline"
        }
        LOD 200
        // Stencil
        // {
        //     Ref [_Stencil]
        //     Comp [_StencilComp]
        //     Pass [_StencilOp]
        // }

        Pass
        {
            Tags
            {
                "LightMode" = "ForwardPass"
            } 
            Blend[_SrcBlend][_DstBlend] 
            ZWrite [_ZWrite]
            Cull[_Cull] 
            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma target 3.5
            #include "../ShaderLibrary/Surface.hlsl"
            // Realtime shadow reception is fixed for this LOD.
            #define _RECEIVE_SHADOWS 1
            #include "../ShaderLibrary/Shadows.hlsl"
            #include "../ShaderLibrary/Light.hlsl"
            #include "../ShaderLibrary/BRDF.hlsl"
            #include "../ShaderLibrary/GI.hlsl"
            #include "../ShaderLibrary/Lighting.hlsl"
            #pragma shader_feature_local _Coverage_ON
            #pragma shader_feature_local _EMISSION 
            #pragma multi_compile _ LIGHTMAP_ON
            #pragma multi_compile _ _PAIPAI_TERRAIN_BATCH_LIGHTMAP

            #pragma multi_compile_instancing
            #include_with_pragmas "Packages/com.ifreetalk.render-pipeline/Shaders/ShaderLibrary/DOTS.hlsl"

            struct Attributes
            {
                float3 positionOS : POSITION;
                half3 normalOS : NORMAL;
                half4 tangentOS : TANGENT;
                half2 uv : TEXCOORD0;
            #if defined(LIGHTMAP_ON)
                half2 uv2 : TEXCOORD1;
            #endif
                UNITY_VERTEX_INPUT_INSTANCE_ID
            }; 
            struct Varyings
            {
                float4 positionCS : SV_Position; 
                float3 positionWS : POSITIONWS;
                half3  normalWS : NORMALWS;
                half3 tangentWS : TANGENTWS;
                half3 bitangentWS : BITANGENTWS;
                half3 uv : UV0;
            #if defined(_Coverage_ON) 
                half2 coverageUV : UV1;
            #endif  
            #if defined(LIGHTMAP_ON)
               half2  lightMapUV : UV2;
            #endif
            }; 
            Varyings vert(Attributes input)
            {
                Varyings output;
                UNITY_SETUP_INSTANCE_ID(input); 
                output.positionWS = TransformObjectToWorld(input.positionOS.xyz);
                output.positionCS = TransformWorldToHClip(output.positionWS); 
                output.normalWS = TransformObjectToWorldNormal(input.normalOS); 
                half sign = real(input.tangentOS.w) * GetOddNegativeScale();
                output.tangentWS = TransformObjectToWorldDir(input.tangentOS.xyz);
                output.bitangentWS = cross(output.normalWS, output.tangentWS) * sign;
                output.uv.xy = input.uv * _BaseMap_ST.xy + _BaseMap_ST.zw;
                output.uv.z = ComputeFixedLinearFogVisibility(output.positionWS);
                half2 worldXZ = output.positionWS.xz;
            #if defined(_Coverage_ON) 
                output.coverageUV = worldXZ * _CoverageAlbedo_ST.xy + _CoverageAlbedo_ST.zw;
            #endif 
            #if defined(LIGHTMAP_ON)
                output.lightMapUV = input.uv2  * half2(PAIPAI_LIGHTMAP_ST.xy) + half2(PAIPAI_LIGHTMAP_ST.zw);
            #endif
                return output;
            } 
            void SampleNormalTSSmoothnessMetallic(half2 uv, out half Roughness, out half metallic, out half3 normalTS)
            {
                half4 nrmSample = SAMPLE_TEXTURE2D(_NormalMap, sampler_NormalMap, uv);
                Roughness = nrmSample.b * _Roughness;
                metallic  = nrmSample.a * _Metallic;
                normalTS = UnpackNormalRG(nrmSample.rg, _NormalStrength);
            } 
            #define kDielectricSpec half4(0.04, 0.04, 0.04, 1.0 - 0.04) // standard dielectric reflectivity coef at incident angle (= 4%) 
            #define kDieletricSpec kDielectricSpec   
            #define MATCAP_LOD_MAX 9 
            half3 GlossyEnvironmentReflection(half3 normalWS, half perceptualRoughness, half occlusion )
            {  
                half4 environment = SAMPLE_TEXTURE2D_LOD(_MatcapTex, sampler_MatcapTex, DirectionToOctahedralUV(normalWS), perceptualRoughness*MATCAP_LOD_MAX); 
                return 2 * environment.rgb * occlusion; 
            }  
            half4 frag(Varyings input) : SV_Target
            {  
                half4 baseSample = SAMPLE_TEXTURE2D(_BaseMap, sampler_BaseMap, input.uv.xy);
                half4 baseColor = baseSample * _BaseMapColor;
                half3 normalWS = normalize(input.normalWS);
                half Roughness, metallic = 0;
                half3 normalTS;
                // 切線空間法線 -> 世界空間
                SampleNormalTSSmoothnessMetallic(input.uv.xy, Roughness, metallic, normalTS); 

            #if defined(_Coverage_ON)  
                half upWithOffset = saturate(normalWS.y + _TopOffset);
                half contrastExp = (1.0h + 19.0h * _TopContrast);
                half slopeMask = pow(abs(upWithOffset), contrastExp);
                half CoverUpVecNormal = saturate(slopeMask) * _TopIntensity;
                half BlendHeight = SAMPLE_TEXTURE2D(_CoverageNoise, sampler_CoverageNoise, input.uv.xy*_CoverageNoise_ST.xy+_CoverageNoise_ST.zw).r;
                CoverUpVecNormal = saturate(CoverUpVecNormal+ BlendHeight*_CoverageScale-_BlendHeight);
        // return float4(CoverUpVecNormal.rrr,1);
                half2 covUV = input.coverageUV;
                half3 CoverageMap = SAMPLE_TEXTURE2D(_CoverageAlbedo, sampler_CoverageAlbedo, covUV).rgb;
                half3 CoverageMapNormal = SAMPLE_TEXTURE2D(_CoverageNormal, sampler_CoverageNormal, covUV).rgb;
                half3 CoverageNormal = UnpackNormalRG(CoverageMapNormal.xy, _CoverageNormalStrength);
        
                baseColor.rgb = lerp(baseColor.rgb, CoverageMap, CoverUpVecNormal);
                half3 blendNormal =  BlendNormal(normalTS, CoverageNormal);
                blendNormal = lerp(blendNormal,CoverageNormal,_CoverageLerp);
                normalTS = (lerp(normalTS, blendNormal, CoverUpVecNormal)); 
                // 使用覆盖粗糙度参数调整粗糙度
                Roughness = lerp(Roughness,CoverageMapNormal.b, CoverUpVecNormal); 
            #endif  
                half3x3 tbnTS = half3x3(input.tangentWS.xyz, input.bitangentWS, input.normalWS); // TS->WS
                normalWS = normalize(TransformTangentToWorld(normalTS, tbnTS));
                half3 viewDirWS = normalize(_WorldSpaceCameraPos - input.positionWS.xyz);
                ShadowData shadowData = GetShadowMapData(half(1.0));  
                half4 shadowMask = 1;
                half bakedShadow = half(1.0);
                half ao = 1;
            #if defined(LIGHTMAP_ON)
                shadowMask = GetShadowMaskAll(input.lightMapUV);
                bakedShadow = shadowMask.r;
                ao = shadowMask.b;
            #endif
                DirectionalShadowData directional = GetDirectionalShadowData(shadowData);
                Light mainLight;
                half outShadow;
                mainLight.color = _DirectionalLightColor.rgb;
                mainLight.direction = _DirectionalLightDirection.xyz;
                mainLight.attenuation = GetDirectionalShadowMaskAttenuationRuntime(
                    bakedShadow, directional, shadowData, input.positionWS, normalWS, outShadow);
                half3 halfDir = normalize(mainLight.direction + viewDirWS + _ElevationAngle.xyz);

                half NoH = saturate(dot(normalWS, halfDir));
                half NdotL = saturate(dot(normalWS, mainLight.direction));
                half NoV = saturate(dot(normalWS, viewDirWS));

                //材质漫反射和镜面反射分布由金属度决定
                half oneMinusReflectivity = OneMinusReflectivityMetallic(metallic); //(1-F₀)*(1-metallic) = 0.96 * (1 - metallic) = 1 - metallic
                half3 brdfDiffuse = baseColor.rgb * oneMinusReflectivity; //金属度漫反射为0    //baseColor * lerp(0.96, 0, metallic) = lerp( baseColor * 0.96 , 0, metallic) = lerp( baseColor , 0, metallic)
                half3 brdfSpec = lerp(kDieletricSpec.rgb, baseColor.rgb, metallic);//F0  //金属度全部是镜面反射  // lerp(0.04, baseColor, metallic) = lerp(0, baseColor, metallic)

                //直接光计算
                half3 directColor = 0;

                half3  directDiffuse = mainLight.attenuation * NdotL; 
                directColor += brdfDiffuse;  
                directColor += brdfSpec * GGX_Mobile(Roughness, NoH);  
            // #if defined(LIGHTMAP_ON)   
                 // directColor *= directDiffuse;
            // #endif 
                directColor *= mainLight.color *  directDiffuse; 
                half3 IBL_F = EnvBRDFApprox(brdfSpec, Roughness, NoV); 
                half3  reflectVec  = reflect(-viewDirWS,normalWS);  
                half3 IBL_DG = GlossyEnvironmentReflection(reflectVec, Roughness, 1);
                half3 indirectColor = 0;
                float3 IBL_SPEC =IBL_DG * IBL_F* _MatcapIntensity;

                indirectColor += lerp(IBL_SPEC,IBL_SPEC*ao,_IBL_AO_Scale);  
            #if defined(LIGHTMAP_ON)
                half3 GI = SampleLightMap(input.lightMapUV) * brdfDiffuse;
                // GI = lerp(GI*_ShadowInternalOffset,GI,outShadow);
                GI = lerp(GI,0,shadowMask.g*(1-outShadow));
                indirectColor += GI;
                half3 color = directColor + indirectColor;
            #else
                half3 indirectDiffuse = NoLightMapSampleLightProbe(normalWS);
                indirectColor += indirectDiffuse * brdfDiffuse;
                half3 color = directColor + indirectColor;
            #endif
                //合成
            // #if !defined(LIGHTMAP_ON) 
            //     uint lightsCount = GetAdditionalLightCount();
            //     for (uint j = 0; j < lightsCount; j++)
            //     {
            //         Light light1 = GetAdditionalLight(j, input.positionWS);
            //         half NdotL1 = saturate(dot(normalWS, light1.direction));
            //         half3 halfDir1 = normalize(light1.direction + viewDirWS);
            //         half NoH1 = max(0.01,dot(normalWS, halfDir1));
            //         half lightFactor1 = light1.attenuation * NdotL1; 
            //         color += brdfDiffuse * (light1.color * lightFactor1);
            //         half specTerm1 = GGX_Mobile(Roughness, NoH1);
            //         color += brdfSpec * specTerm1 * (light1.color * lightFactor1);
            //     } 
            // #endif 
            #if defined(_EMISSION)
                half3 EmissionColor = SAMPLE_TEXTURE2D(_EmissionMap, sampler_EmissionMap, input.uv.xy).rgb * _EmissionColor.rgb;
                color += EmissionColor;
            #endif 
                color = HeightFog(input.positionWS, color);  
                color = MixFixedLinearFog(color, input.uv.z);
                 return half4(color, baseColor.a);
            }
            ENDHLSL
        } 
        Pass
        {
            Tags
            {
                "LightMode" = "ShadowCaster"
            }
            
            ColorMask 0
            Cull Off

            HLSLPROGRAM
            #pragma target 3.5
            #pragma multi_compile_instancing
            #include_with_pragmas "Packages/com.ifreetalk.render-pipeline/Shaders/ShaderLibrary/DOTS.hlsl"
            #pragma vertex ShadowCasterPassVertex
            #pragma fragment ShadowCasterPassFragment
            #include "ShadowCasterPass.hlsl"
            ENDHLSL
        }  
        Pass {
            Name "Meta"
            Tags {
                "LightMode" = "Meta"
            }

            Cull[_Cull]

            HLSLPROGRAM
            #pragma target 3.5
            #pragma shader_feature_local _EMISSION 
            #pragma multi_compile_instancing
            #include_with_pragmas "Packages/com.ifreetalk.render-pipeline/Shaders/ShaderLibrary/DOTS.hlsl"
            #pragma vertex MetaPassVertex
            #pragma fragment MetaPassFragment 
            #include "MetaPass.hlsl"
            ENDHLSL
        }
    }

    SubShader
    {
        Tags
        {
            "RenderType"="Opaque"
            "RenderPipeline" = "PaiPaiRenderPipeline"
        }
        LOD 100
        // Stencil
        // {
        //     Ref [_Stencil]
        //     Comp [_StencilComp]
        //     Pass [_StencilOp]
        // }

         Pass
        {
            Tags
            {
                "LightMode" = "ForwardPass"
            } 
            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma target 3.5
            #include "../ShaderLibrary/Surface.hlsl"
            // Realtime shadow reception is fixed for this LOD.
            #define _RECEIVE_SHADOWS 1
            #include "../ShaderLibrary/Shadows.hlsl"
            #include "../ShaderLibrary/Light.hlsl"
            #include "../ShaderLibrary/BRDF.hlsl"
            #include "../ShaderLibrary/GI.hlsl"
            #include "../ShaderLibrary/Lighting.hlsl"
            #pragma shader_feature_local _Coverage_ON
            #pragma shader_feature_local _EMISSION
            #pragma multi_compile _ LIGHTMAP_ON
            #pragma multi_compile _ _PAIPAI_TERRAIN_BATCH_LIGHTMAP

            #pragma multi_compile_instancing
            #include_with_pragmas "Packages/com.ifreetalk.render-pipeline/Shaders/ShaderLibrary/DOTS.hlsl"

            struct Attributes
            {
                float3 positionOS : POSITION;
                half3 normalOS : NORMAL; 
                half2 uv : TEXCOORD0;
            #if defined(LIGHTMAP_ON)
                half2 uv2 : TEXCOORD1;
            #endif
                UNITY_VERTEX_INPUT_INSTANCE_ID
            }; 
            struct Varyings
            {
                float4 positionCS : SV_Position; 
                float3 positionWS : POSITIONWS;
                half3  normalWS : NORMALWS; 
                half2  uv : UV0;
            #if defined(_Coverage_ON) 
                half2 coverageUV : UV1;
            #endif  
            #if defined(LIGHTMAP_ON)
               half2  lightMapUV : UV2;
            #endif
            }; 
            Varyings vert(Attributes input)
            {
                Varyings output;
                UNITY_SETUP_INSTANCE_ID(input); 
                output.positionWS = TransformObjectToWorld(input.positionOS.xyz);
                output.positionCS = TransformWorldToHClip(output.positionWS); 
                output.normalWS = TransformObjectToWorldNormal(input.normalOS);  
                output.uv.xy = input.uv * _BaseMap_ST.xy + _BaseMap_ST.zw;
                half2 worldXZ = output.positionWS.xz;
            #if defined(_Coverage_ON) 
                output.coverageUV = worldXZ * _CoverageAlbedo_ST.xy + _CoverageAlbedo_ST.zw;
            #endif 
            #if defined(LIGHTMAP_ON)
                output.lightMapUV = input.uv2  * half2(PAIPAI_LIGHTMAP_ST.xy) + half2(PAIPAI_LIGHTMAP_ST.zw);
            #endif
                return output;
            } 
            void SampleNormalTSSmoothnessMetallic(half2 uv, out half Roughness, out half metallic, out half3 normalTS)
            { 
                    half4 nrmSample = SAMPLE_TEXTURE2D(_NormalMap, sampler_NormalMap, uv); 
                    Roughness = nrmSample.b * _Roughness; 
                    metallic  = nrmSample.a * _Metallic;  
                    normalTS =  half3(0, 0, 1); 
            } 
            #define kDielectricSpec half4(0.04, 0.04, 0.04, 1.0 - 0.04) // standard dielectric reflectivity coef at incident angle (= 4%) 
            #define kDieletricSpec kDielectricSpec   
            #define MATCAP_LOD_MAX 9 
            half3 GlossyEnvironmentReflection(half3 normalWS, half perceptualRoughness, half occlusion )
            {  
                half4 environment = SAMPLE_TEXTURE2D_LOD(_MatcapTex, sampler_MatcapTex, DirectionToOctahedralUV(normalWS), perceptualRoughness*MATCAP_LOD_MAX); 
                return 2 * environment.rgb * occlusion; 
            }  
            half4 frag(Varyings input) : SV_Target
            {  
                half4 baseSample = SAMPLE_TEXTURE2D(_BaseMap, sampler_BaseMap, input.uv.xy);
                half4 baseColor = baseSample * _BaseMapColor;
                half3 normalWS = normalize(input.normalWS);
                half Roughness, metallic = 0;
                half3 normalTS; 
                SampleNormalTSSmoothnessMetallic(input.uv.xy, Roughness, metallic, normalTS);  
            #if defined(_Coverage_ON)  
                half upWithOffset = saturate(normalWS.y + _TopOffset);
                half contrastExp = (1.0h + 19.0h * _TopContrast);
                half slopeMask = pow(abs(upWithOffset), contrastExp);
                half CoverUpVecNormal = saturate(slopeMask * _TopIntensity);
                half2 covUV = input.coverageUV;
                half3 CoverageMap = SAMPLE_TEXTURE2D(_CoverageAlbedo, sampler_CoverageAlbedo, covUV).rgb;  
                baseColor.rgb = lerp(baseColor.rgb, CoverageMap, CoverUpVecNormal);  
                Roughness = lerp(Roughness, 1, CoverUpVecNormal); 
            #endif  
                half3 viewDirWS = normalize(_WorldSpaceCameraPos - input.positionWS.xyz); 
                ShadowData shadowData = GetShadowMapData(half(1.0));
                half4 shadowMask = 1;
                half bakedShadow = half(1.0);
            #if defined(LIGHTMAP_ON)
                shadowMask = GetShadowMaskAll(input.lightMapUV);
                bakedShadow = shadowMask.r;
            #endif
                DirectionalShadowData directional = GetDirectionalShadowData(shadowData);
                Light mainLight;
                half outShadow;
                mainLight.color = _DirectionalLightColor.rgb;
                mainLight.direction = _DirectionalLightDirection.xyz;
                mainLight.attenuation = GetDirectionalShadowMaskAttenuationRuntime(
                    bakedShadow, directional, shadowData, input.positionWS, normalWS, outShadow);
                half NdotL = saturate(dot(normalWS, mainLight.direction));
                half oneMinusReflectivity = OneMinusReflectivityMetallic(metallic); 
                half3 brdfDiffuse = baseColor.rgb * oneMinusReflectivity; 

                //直接光计算
                half3 directColor = 0;
                half  directDiffuse = mainLight.attenuation * NdotL; 
                directColor += brdfDiffuse; 
            // #if defined(LIGHTMAP_ON)   
            //     directColor *= directDiffuse;
            // #endif 
                directColor *= mainLight.color *  directDiffuse;  
                half3 indirectColor = 0; 
                             
            #if defined(LIGHTMAP_ON)
                half3 GI = SampleLightMap(input.lightMapUV) * brdfDiffuse;
                GI = lerp(GI*_ShadowInternalOffset,GI,outShadow);
                indirectColor += GI;

                half3 color = directColor + indirectColor;
            #else
                half3 indirectDiffuse = NoLightMapSampleLightProbe(normalWS);
                indirectColor += indirectDiffuse * brdfDiffuse;
                half3 color = directColor + indirectColor;
            #endif
                                
                //鍚堟垚
            // #if !defined(LIGHTMAP_ON) 
            //     half3 brdfSpec = lerp(kDieletricSpec.rgb, baseColor.rgb, metallic); 
            //     uint lightsCount = GetAdditionalLightCount();
            //     for (uint j = 0; j < lightsCount; j++)
            //     {
            //         Light light1 = GetAdditionalLight(j, input.positionWS);
            //         half NdotL1 = saturate(dot(normalWS, light1.direction));
            //         half3 halfDir1 = normalize(light1.direction + viewDirWS);
            //         half NoH1 =  max(0.01,dot(normalWS, halfDir1));
            //         half lightFactor1 = light1.attenuation * NdotL1; 
            //         color += brdfDiffuse * (light1.color * lightFactor1);
            //         half specTerm1 = GGX_Mobile(Roughness, NoH1);
            //         color += brdfSpec * specTerm1 * (light1.color * lightFactor1);
            //     } 
            // #endif 
            #if defined(_EMISSION)
                half3 EmissionColor = SAMPLE_TEXTURE2D(_EmissionMap, sampler_EmissionMap, input.uv.xy).rgb * _EmissionColor.rgb;
                color += EmissionColor;
            #endif 
                color = HeightFog(input.positionWS, color);
                 return half4(color, baseColor.a);
            }
            ENDHLSL
        }
        Pass
        {
            Tags
            {
                "LightMode" = "ShadowCaster"
            }
            
            ColorMask 0
            Cull Off

            HLSLPROGRAM
            #pragma target 3.5
            #pragma multi_compile_instancing
            #include_with_pragmas "Packages/com.ifreetalk.render-pipeline/Shaders/ShaderLibrary/DOTS.hlsl"
            #pragma vertex ShadowCasterPassVertex
            #pragma fragment ShadowCasterPassFragment
            #include "ShadowCasterPass.hlsl"
            ENDHLSL
        }
    }

    SubShader
    {
        Tags
        {
            "RenderType"="Opaque"
            "RenderPipeline" = "PaiPaiRenderPipeline"
        }
        LOD 50
        // Stencil
        // {
        //     Ref [_Stencil]
        //     Comp [_StencilComp]
        //     Pass [_StencilOp]
        // }

         Pass
        {
            Tags
            {
                "LightMode" = "ForwardPass"
            } 
            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma target 3.5
            #include "../ShaderLibrary/Surface.hlsl"
            #include "../ShaderLibrary/Shadows.hlsl"
            #include "../ShaderLibrary/Light.hlsl"
            #include "../ShaderLibrary/BRDF.hlsl"
            #include "../ShaderLibrary/GI.hlsl"
            #include "../ShaderLibrary/Lighting.hlsl"
            #pragma shader_feature_local _Coverage_ON
            #pragma shader_feature_local _EMISSION
            #pragma multi_compile _ LIGHTMAP_ON
            #pragma multi_compile _ _PAIPAI_TERRAIN_BATCH_LIGHTMAP

            #pragma multi_compile_instancing
            #include_with_pragmas "Packages/com.ifreetalk.render-pipeline/Shaders/ShaderLibrary/DOTS.hlsl"

            struct Attributes
            {
                float3 positionOS : POSITION;
                half3 normalOS : NORMAL; 
                half2 uv : TEXCOORD0;
            #if defined(LIGHTMAP_ON)
                half2 uv2 : TEXCOORD1;
            #endif
                UNITY_VERTEX_INPUT_INSTANCE_ID
            }; 
            struct Varyings
            {
                float4 positionCS : SV_Position; 
                float3 positionWS : POSITIONWS;
                half3  normalWS : NORMALWS; 
                half2  uv : UV0;
            #if defined(_Coverage_ON) 
                half2 coverageUV : UV1;
            #endif  
            #if defined(LIGHTMAP_ON)
               half2  lightMapUV : UV2;
            #endif
            }; 
            Varyings vert(Attributes input)
            {
                Varyings output;
                UNITY_SETUP_INSTANCE_ID(input); 
                output.positionWS = TransformObjectToWorld(input.positionOS.xyz);
                output.positionCS = TransformWorldToHClip(output.positionWS); 
                output.normalWS = TransformObjectToWorldNormal(input.normalOS);  
                output.uv.xy = input.uv * _BaseMap_ST.xy + _BaseMap_ST.zw;
                half2 worldXZ = output.positionWS.xz;
            #if defined(_Coverage_ON) 
                output.coverageUV = worldXZ * _CoverageAlbedo_ST.xy + _CoverageAlbedo_ST.zw;
            #endif 
            #if defined(LIGHTMAP_ON)
                output.lightMapUV = input.uv2  * half2(PAIPAI_LIGHTMAP_ST.xy) + half2(PAIPAI_LIGHTMAP_ST.zw);
            #endif
                return output;
            } 
            half4 frag(Varyings input) : SV_Target
            {  
                half4 baseSample = SAMPLE_TEXTURE2D(_BaseMap, sampler_BaseMap, input.uv.xy);
                half4 baseColor = baseSample * _BaseMapColor;
                half3 normalWS = normalize(input.normalWS);
            #if defined(_Coverage_ON)  
                half upWithOffset = saturate(normalWS.y + _TopOffset);
                half contrastExp = (1.0h + 19.0h * _TopContrast);
                half slopeMask = pow(abs(upWithOffset), contrastExp);
                half coverMask = saturate(slopeMask * _TopIntensity);
                half2 covUV = input.coverageUV;
                half3 coverageMap = SAMPLE_TEXTURE2D(_CoverageAlbedo, sampler_CoverageAlbedo, covUV).rgb;  
                baseColor.rgb = lerp(baseColor.rgb, coverageMap, coverMask);  
            #endif  
                // Low LOD keeps baked lighting without receiving shadows.
                Light mainLight = GetDirectionalLightNoShadow();
                half NdotL = saturate(dot(normalWS, mainLight.direction));
                half directDiffuse = mainLight.attenuation * NdotL; 
                half3 color = baseColor.rgb * mainLight.color * directDiffuse;
                             
            #if defined(LIGHTMAP_ON)
                half3 GI = SampleLightMap(input.lightMapUV) * baseColor.rgb;
                color += GI;
            #else
                color += NoLightMapSampleLightProbe(normalWS) * baseColor.rgb;
            #endif
            #if defined(_EMISSION)
                half3 EmissionColor = SAMPLE_TEXTURE2D(_EmissionMap, sampler_EmissionMap, input.uv.xy).rgb * _EmissionColor.rgb;
                color += EmissionColor;
            #endif 
                color = HeightFogSimple(input.positionWS, color);
                 return half4(color, baseColor.a);
            }
            ENDHLSL
        } 
    } 
    CustomEditor "PaiPai.Rendering.Editor.PaiPaiCustomShaderGUI"
}
