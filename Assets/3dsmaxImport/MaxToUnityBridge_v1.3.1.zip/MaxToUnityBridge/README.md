﻿# 3ds Max → Unity 自动合并导出工具

在 3ds Max 中选中物体，点击 `Max → Unity` 按钮后，工具会：

1. 复制并临时合并选中的几何体，不修改原场景对象；
2. 把合并结果导出为 FBX；
3. 收集材质颜色、金属度、粗糙度和贴图；
4. 把贴图复制到 所选输出目录的 `Textures` 子目录；
5. 写入 JSON 清单；
6. Unity Editor 自动生成 Material 和 Prefab，材质固定使用
   `PaiPai/BigLand/Lit_BigLand_OptimizePBR`。

支持范围：3ds Max 2020+、Unity 2020.3+。脚本已使用 3ds Max 2026 / Unity 2022.3 API 做兼容性检查。

### 三种导出方式（v1.3）

| 面板选项 | 选中 N 个几何体时的结果 | 命名 |
|---|---|---|
| 合并网格（默认） | 1 个 FBX、1 个 Prefab，合并为一个网格 | 面板的资源名称 |
| 分别导出 | N 个 FBX、N 个独立 Prefab | 各自的 Max 节点名称；重名时先提示改名 |
| 保留子物体 | 1 个 FBX、1 个父 Prefab，含 N 个独立的直接子物体 | 父级用资源名称；子级用 Max 节点名称 |

第三种保留各部件的相对位置，父级原点取收集到的第一个几何体的轴心。子级为静态网格，不是嵌套 Prefab；不复制骨骼、动画或原来多层的分组结构。三个模式均输出到已选目录，并沿用材质、Shader 和贴图流程。使用相同输出目录和资源名会更新原资源；若要同时保留多个模式的结果，请使用不同资源名或目录。

更新时请同时替换 Max 和 Unity 两端脚本。旧清单缺少 `childNames` 时仍走原有逻辑。

## 一、安装

### 1. Shader

目标 Shader 必须已经存在于 Unity 工程中，并能在 Unity 中正常编译：

```text
PaiPai/BigLand/Lit_BigLand_OptimizePBR
```

`Lit_BigLand_OptimizePBR.shader` 依赖 `com.ifreetalk.render-pipeline` 以及原目录附近的
`../ShaderLibrary/*.hlsl`。因此不要把 Shader 单独复制到一个新目录；应保留在工程原有位置。

### 2. 手动安装 / 更新（无需安装器）

覆盖原 Unity `Editor/MaxToUnityBridge.cs`（不要留两份类），然后在 Max 的 Scripting → Run Script 加载 `MaxScript/MaxToUnityBridge.ms`。如果曾放进 Startup，请同步替换旧副本。两个脚本都需要更新。新目录清单为 `Incoming/*.mtu.json`；原 `Assets/MaxToUnityBridge/Incoming/*.json` 仍兼容。更换输出目录不会移动旧资源。

### 可选：一键安装

在 PowerShell 中运行：

```powershell
cd "C:\Users\Administrator\Documents\ChatGPT\3dsmax\MaxToUnityBridge"
powershell -ExecutionPolicy Bypass -File ".\Install-MaxToUnityBridge.ps1" -UnityProject "D:\YourUnityProject" -MaxVersion 2026
```

安装脚本会：

- 把 3ds Max 脚本安装到当前用户的 3ds Max `scripts\Startup`；
- 把 Unity Editor 脚本复制到 `UnityProject\Assets\MaxToUnityBridge\Editor`；
- 检查 Unity 工程中是否已经存在目标 Shader。

如果 3ds Max 使用其他语言目录，可加 `-Language CHS` 或 `-Language ENU`。

### 3. 在 3ds Max 中创建按钮

重启 3ds Max 后：

1. 打开 `Customize > Customize User Interface`;
2. 切换到 `Toolbars`；
3. 分类选择 `PaiPai Tools`；
4. 将 `Max → Unity` 拖到工具栏。

也可以在 3ds Max 中直接运行：

```text
MaxScript\MaxToUnityBridge.ms
```

然后使用宏 `MaxToUnityBridge`。

## 二、使用

1. 打开目标 Unity 工程，确认 Shader 已编译；
2. 在 3ds Max 中选中一个或多个几何体；
3. 点击 `Max → Unity`；
4. 浏览并选择工程中已存在的 `Assets` 或其下任意子目录，例如 `Assets/Art/Rocks`（不是工程根目录）；
5. 设置导出名称；
6. 点击 `合并选中物体并导出到 Unity`。

`导入缩放` 默认是 `1.0`。如果 3ds Max 场景单位导致 Unity 模型放大了 100 倍，可改为 `0.01`
或调整 3ds Max 的系统单位设置。

Unity 打开时会自动导入并生成：

```text
Assets/Art/Rocks/
├── Incoming/
│   ├── <ExportName>.fbx
│   └── <ExportName>.mtu.json
├── Textures/<ExportName>/
├── Materials/<ExportName>/
├── Generated/<ExportName>/
└── Prefabs/<ExportName>.prefab
```

Unity 未打开时，3ds Max 仍会把文件写入工程；下一次打开 Unity 时会自动生成 Prefab。

## 三、材质与贴图映射

生成材质使用以下 Shader 属性：

| Shader 属性 | 来源 |
|---|---|
| `_BaseMap` | Base Color / Diffuse / Albedo |
| `_BaseMapColor` | 基础材质颜色 |
| `_NormalMap` | 法线；RG=Normal，B=Roughness，A=Metallic |
| `_Metallic` | 金属度标量 |
| `_Roughness` | 粗糙度标量 |
| `_EmissionMap` / `_EmissionColor` | 自发光贴图与颜色 |
| `_CoverageAlbedo` / `_CoverageNormal` / `_CoverageNoise` | 覆盖效果贴图 |

材质属性识别优先读取常见 3ds Max 材质属性，例如：

- `base_color_map` / `diffuseMap`
- `bump_map` / `bumpMap` / `normalMap`
- `roughness_map` / `metalness_map`
- `emission_color_map` / `selfIllumMap`
- V-Ray 常见 `texmap_diffuse` / `texmap_bump` / `texmap_metalness` 等

如果材质插件使用了非标准属性名，工具还会根据属性名和贴图文件名进行兜底识别：

- `diffuse` / `albedo` / `basecolor` → BaseMap
- `normal` / `bump` → NormalMap
- `rough` → RoughnessMap
- `gloss` → RoughnessMap（自动反相）
- `metal` → MetallicMap
- `emiss` / `selfillum` → EmissionMap
- `coverage` / `cover` → Coverage 贴图

若 Roughness/Metallic 是独立贴图，Unity 端会自动生成
`<Material>_PackedNormal.png`，把法线与 B/A 通道打包后绑定到 `_NormalMap`。
如果原法线贴图本身就是打包好的 ORM/RMA/MRA 贴图，请让文件名包含
`orm`、`rma`、`mra` 或 `packed`，工具会直接使用它。

贴图导入规则：

- Base/Emission/Coverage Albedo：sRGB；
- Normal/Roughness/Metallic/Coverage Normal/Noise：线性；
- 法线与通道打包贴图关闭压缩，避免 B/A 数据被破坏。

## 四、注意事项

- “合并网格”模式会真正把选中几何体合并成一个网格，不同材质会保留为多个材质槽。
- 不支持或无法复制的贴图格式（例如部分 V-Ray `.tx`）会被跳过，并在 Unity Console 中体现为缺少贴图。
- 工具不导出动画、相机和灯光；只处理选中的几何体。
- 原 3ds Max 场景不会被合并操作修改；临时对象导出后删除。
- 若 Prefab 没有自动生成：
  1. 检查 Unity Console 是否有 Shader 编译错误或 FBX 导入错误；
  2. 执行菜单 `Tools > PaiPai > Max To Unity > 重新处理 Incoming`；
  3. 确认 JSON 中 `fbxAssetPath` 指向的资源已经导入。
- Prefab 每次使用相同导出名称时会覆盖更新，同名场景引用会保留在同一个 Prefab 资源上。

## 五、文件说明

```text
MaxToUnityBridge/
├── MaxScript/MaxToUnityBridge.ms
├── Unity/Assets/MaxToUnityBridge/Editor/MaxToUnityBridge.cs
├── Shader/Lit_BigLand_OptimizePBR.shader
├── Install-MaxToUnityBridge.ps1
└── README.md
```

`Shader/Lit_BigLand_OptimizePBR.shader` 是随工具保存的参考副本，安装脚本不会覆盖 Unity 工程里的 Shader。