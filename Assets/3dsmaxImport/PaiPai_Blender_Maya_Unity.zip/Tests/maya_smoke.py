"""Run with mayapy in a NEW process. Uses only a temporary project/scene."""
import sys,tempfile,json
from pathlib import Path
import maya.standalone
maya.standalone.initialize(name='python')
from maya import cmds
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'Maya'))
import paipai_maya as addon
try:
    project=Path(tempfile.mkdtemp(prefix='MayaBridgeSmoke_'));d=project/'Assets/Art';d.mkdir(parents=True);(project/'ProjectSettings').mkdir();(project/'ProjectSettings/ProjectVersion.txt').write_text('m_EditorVersion: 2022.3.62f3\n')
    a=cmds.polyCube(name='PartA')[0];b=cmds.polyCube(name='PartB')[0];cmds.setAttr(b+'.translateX',50)
    for o in (a,b):
        sh=cmds.shadingNode('lambert',asShader=True,name='Mat'+o[-1]);sg=cmds.sets(empty=True,renderable=True,noSurfaceShader=True);cmds.connectAttr(sh+'.outColor',sg+'.surfaceShader');cmds.sets(o,e=True,forceElement=sg)
    cmds.select(a,b,r=True);selected=cmds.ls(sl=True,long=True)
    for mode,n in [('MERGE','Merged'),('CHILDREN','Group'),('SEPARATE','Unused')]:
        addon.core.export(str(d),n,mode,addon.core.SHADER,1,addon.selected_meshes(),lambda x:x.split('|')[-1],addon.write_unit)
        assert cmds.ls(sl=True,long=True)==selected
    for n in ('Merged','Group','PartA','PartB'):
        manifest=json.loads((d/'Incoming'/(n+'.mtu.json')).read_text());assert (project/manifest['fbxAssetPath']).stat().st_size
    print('MAYA_SMOKE_OK:',project)
finally: maya.standalone.uninitialize()
