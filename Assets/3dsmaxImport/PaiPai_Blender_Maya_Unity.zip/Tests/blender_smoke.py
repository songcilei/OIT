"""blender --background --factory-startup --python-exit-code 1 --python blender_smoke.py -- <scratch Unity project>"""
import sys,json
from pathlib import Path
import bpy
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'Blender'))
import paipai_unity as addon
addon.register()
project=Path(sys.argv[-1]); dest=project/'Assets/Art/Rocks';dest.mkdir(parents=True,exist_ok=True)
(project/'ProjectSettings').mkdir(exist_ok=True);(project/'ProjectSettings/ProjectVersion.txt').write_text('m_EditorVersion: 2022.3.62f3\n')
a=bpy.context.active_object;a.name='PartA';bpy.ops.mesh.primitive_cube_add(location=(2,0,0));b=bpy.context.object;b.name='PartB'
im=bpy.data.images.new('Shared',3,3);im.filepath_raw=str(project/'test.png');im.file_format='PNG';im.save()
for o,n in [(a,'MatA'),(b,'MatB')]:
    m=bpy.data.materials.new(n);m.use_nodes=True;o.data.materials.clear();o.data.materials.append(m)
    node=m.node_tree.nodes.new('ShaderNodeTexImage');node.image=im;bs=m.node_tree.nodes.get('Principled BSDF');m.node_tree.links.new(node.outputs['Color'],bs.inputs['Base Color'])
    sep=m.node_tree.nodes.new('ShaderNodeSeparateColor');m.node_tree.links.new(node.outputs['Color'],sep.inputs[0]);m.node_tree.links.new(sep.outputs[1],bs.inputs['Roughness'])
a.select_set(True);p=bpy.context.scene.paipai_unity;p.folder=str(dest);p.asset='Group'
for mode,n in [('MERGE','Merged'),('CHILDREN','Group'),('SEPARATE','Unused')]:
    p.mode=mode;p.asset=n;assert bpy.ops.object.paipai_unity_export()=={'FINISHED'};assert set(bpy.context.selected_objects)=={a,b}
for n in ['Merged','Group','PartA','PartB']:
    m=json.loads((dest/'Incoming'/(n+'.mtu.json')).read_text());assert (project/m['fbxAssetPath']).stat().st_size;assert len(m['childNames'])==(2 if n=='Group' else 0)
    for mat in m['materials']:
        assert {t['role'] for t in mat['textures']}=={'BaseMap','RoughnessMap'}
        assert next(t['channel'] for t in mat['textures'] if t['role']=='RoughnessMap')=='g'
        assert all((project/t['assetPath']).is_file() for t in mat['textures'])
addon.unregister();print('BLENDER_SMOKE_OK')
