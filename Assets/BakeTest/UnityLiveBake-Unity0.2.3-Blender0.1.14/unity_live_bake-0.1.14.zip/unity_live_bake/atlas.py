"""Deterministic grid atlas: no island rotation/reunwrap, just instance UV2 scale/offset."""
import math


def layout(count, size, margin):
    if type(count) is not int or count < 1:
        raise ValueError("Atlas requires at least one object")
    if size not in (64, 128, 256, 512, 1024, 2048, 4096):
        raise ValueError("Unsupported atlas size")
    if not 0 <= margin <= 64:
        raise ValueError("Invalid atlas margin")
    columns = math.ceil(math.sqrt(count))
    rows = math.ceil(count / columns)
    gutter = margin + 2
    result = []
    for i in range(count):
        x, y = i % columns, i // columns
        left, right = x * size // columns, (x + 1) * size // columns
        bottom, top = y * size // rows, (y + 1) * size // rows
        width, height = right-left-2*gutter, top-bottom-2*gutter
        if min(width, height) < 16:
            raise ValueError("Atlas too small for %d instances and %d px padding. Increase atlas resolution or reduce synced objects/padding." % (count, margin))
        # Map UV2 endpoints to texel centers, leaving a gutter larger than bake dilation.
        st = [(width-1)/size, (height-1)/size, (left+gutter+.5)/size, (bottom+gutter+.5)/size]
        result.append(dict(scaleOffset=st, cell=[left,bottom,right,top], content=[left+gutter,bottom+gutter,width,height]))
    return result
