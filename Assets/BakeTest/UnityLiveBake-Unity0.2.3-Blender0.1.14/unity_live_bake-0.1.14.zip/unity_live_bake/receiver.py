"""Scene receiver. Only objects tagged with this project's ownership are updated/deleted."""
import json
from pathlib import Path
import bpy
from mathutils import Matrix, Vector
from . import protocol as p

BASIS = Matrix(((1, 0, 0, 0), (0, 0, 1, 0), (0, 1, 0, 0), (0, 0, 0, 1)))


def unity_matrix(values):
    return BASIS @ Matrix([values[i:i+4] for i in range(0, 16, 4)]) @ BASIS


def mapped(v):
    return (v[0], v[2], v[1])


def collection_for(scene, project):
    for c in scene.collection.children:
        if c.get("ulb_project") == project:
            return c
    c = bpy.data.collections.new("UNITY LIVE | " + project[:8])
    c["ulb_project"] = project
    scene.collection.children.link(c)
    return c


def image_from(root, relative, data=False):
    if not relative:
        return None
    path = str(p.contained(root, relative))
    if not Path(path).is_file():
        raise ValueError("Source texture missing: " + relative)
    # Color-space is attached to an image datablock. Separate data and color uses.
    key = path + ("|data" if data else "|color")
    for im in bpy.data.images:
        if im.get("ulb_image") == key:
            return im
    im = bpy.data.images.load(path, check_existing=False)
    im.colorspace_settings.name = "Non-Color" if data else "sRGB"
    im["ulb_image"] = key
    return im


def neutral_base():
    # White is neutral for both direct RGB and the bridge's albedo * tint graph.
    image = next((im for im in bpy.data.images if im.get('ulb_white_base')), None)
    if image is None:
        image = bpy.data.images.new('Unity | No base texture (white)', 1, 1, alpha=True)
        image.generated_color = (1, 1, 1, 1)
        image['ulb_white_base'] = True
    return image


def build_material(root, rec):
    mat = bpy.data.materials.new(rec["name"] + " | Unity")
    mat["ulb_material"] = rec["id"]
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    bsdf = nt.nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.location = (500, 80)
    out.location = (800, 80)
    nt.links.new(bsdf.outputs[0], out.inputs["Surface"])
    uv = nt.nodes.new("ShaderNodeUVMap")
    uv.uv_map = "UV0"
    uv.location = (-1100, 300)
    mapping = nt.nodes.new("ShaderNodeMapping")
    tiling = rec.get("tiling") or [1, 1, 0, 0]
    mapping.inputs["Scale"].default_value = (tiling[0], tiling[1], 1)
    mapping.inputs["Location"].default_value = (tiling[2], tiling[3], 0)
    mapping.location = (-900, 300)
    nt.links.new(uv.outputs["UV"], mapping.inputs["Vector"])

    base_mapping = mapping
    base_tiling = rec.get("baseTextureTiling")
    if rec.get("directBaseTexture") and base_tiling:
        base_mapping = nt.nodes.new("ShaderNodeMapping")
        base_mapping.label = "_MainTex Tiling / Offset"
        base_mapping.inputs["Scale"].default_value = (base_tiling[0], base_tiling[1], 1)
        base_mapping.inputs["Location"].default_value = (base_tiling[2], base_tiling[3], 0)
        nt.links.new(uv.outputs["UV"], base_mapping.inputs["Vector"])

    def texture(field, data=False):
        im = image_from(root, rec.get(field), data)
        if im is None:
            if field != "baseTexture":
                return None
            im = neutral_base()
        node = nt.nodes.new("ShaderNodeTexImage")
        node.image = im
        node.label = field
        if field == "baseTexture":
            node["ulb_base_slot"] = True
        slot = 0 if field == "smoothnessTexture" else ("baseTexture", "normalTexture", "metallicTexture", "occlusionTexture", "emissionTexture").index(field)
        wraps = rec.get("textureWraps") or ["REPEAT"]*5
        filters = rec.get("textureFilters") or ["Linear"]*5
        node.extension = (rec.get("smoothnessWrap") or wraps[slot]) if field == "smoothnessTexture" else wraps[slot]
        node.interpolation = (rec.get("smoothnessFilter") or filters[slot]) if field == "smoothnessTexture" else filters[slot]
        nt.links.new((base_mapping if field == "baseTexture" else mapping).outputs["Vector"], node.inputs["Vector"])
        return node

    color = rec.get("color") or [1, 1, 1, 1]
    bsdf.inputs["Base Color"].default_value = color
    base = texture("baseTexture")
    tint = None
    if base and rec.get("directBaseTexture"):
        nt.links.new(base.outputs["Color"], bsdf.inputs["Base Color"])
    elif base:
        tint = nt.nodes.new("ShaderNodeMixRGB")
        tint.blend_type = "MULTIPLY"
        tint.inputs[0].default_value = 1
        tint.inputs[2].default_value = color
        nt.links.new(base.outputs["Color"], tint.inputs[1])
        nt.links.new(tint.outputs[0], bsdf.inputs["Base Color"])
    bsdf.inputs["Metallic"].default_value = rec.get("metallic", 0)
    bsdf.inputs["Roughness"].default_value = rec.get("roughness", .5)
    metal = texture("metallicTexture", True)
    if metal:
        separate = nt.nodes.new("ShaderNodeSeparateColor")
        nt.links.new(metal.outputs["Color"], separate.inputs[0])
        # Unity metallic-map red replaces scalar _Metallic (not multiplied).
        nt.links.new(separate.outputs["Red"], bsdf.inputs["Metallic"])
    source_albedo = texture("smoothnessTexture") if rec.get("smoothnessTexture") else (base if rec.get("baseTexture") else None)
    smooth_source = source_albedo if rec.get("smoothnessFromAlbedo") and source_albedo else metal
    if smooth_source:
        mul = nt.nodes.new("ShaderNodeMath")
        mul.operation = "MULTIPLY"
        mul.inputs[1].default_value = 1-rec.get("roughness", .5)
        nt.links.new(smooth_source.outputs["Alpha"], mul.inputs[0])
        inv = nt.nodes.new("ShaderNodeMath")
        inv.operation = "SUBTRACT"
        inv.inputs[0].default_value = 1
        nt.links.new(mul.outputs[0], inv.inputs[1])
        nt.links.new(inv.outputs[0], bsdf.inputs["Roughness"])
    normal = texture("normalTexture", True)
    if normal:
        nmap = nt.nodes.new("ShaderNodeNormalMap")
        nmap.uv_map = "UV0"
        nmap.inputs["Strength"].default_value = rec.get("normalScale", 1)
        # Unity->Blender is a reflection and reverses the tangent frame handedness.
        # Blender recomputes tangents from reflected positions plus reversed winding;
        # UV axes are unchanged, so decoded tangent RGB is used without a Y flip.
        nt.links.new(normal.outputs["Color"], nmap.inputs["Color"])
        nt.links.new(nmap.outputs[0], bsdf.inputs["Normal"])
    emission = rec.get("emission") or [0, 0, 0, 1]
    bsdf.inputs["Emission Color"].default_value = emission
    bsdf.inputs["Emission Strength"].default_value = 1
    em = texture("emissionTexture")
    if em:
        mul = nt.nodes.new("ShaderNodeMixRGB")
        mul.blend_type = "MULTIPLY"
        mul.inputs[0].default_value = 1
        mul.inputs[2].default_value = emission
        nt.links.new(em.outputs["Color"], mul.inputs[1])
        nt.links.new(mul.outputs[0], bsdf.inputs["Emission Color"])
    # AO is a raster shading hint in Unity, not albedo. Do not multiply it into
    # diffuse color (would darken twice when Cycles evaluates real occlusion).
    if rec.get("occlusionTexture"):
        mat["ulb_note"] = "Unity AO texture omitted: Cycles computes geometric occlusion. Not shader-identical."
    return mat


def base_node(mat):
    if not mat.use_nodes or not mat.node_tree:
        return None
    nodes = [n for n in mat.node_tree.nodes if n.type == 'TEX_IMAGE']
    tagged = [n for n in nodes if n.get('ulb_base_slot')]
    if len(tagged) == 1:
        return tagged[0]
    candidates = [n for n in (tagged or nodes) if n.label == 'baseTexture']
    return candidates[0] if len(candidates) == 1 else None


def material_plan(root, manifest, owned):
    # Unity material IDs hash *content*. The persistent owner of Blender edits is
    # renderer GlobalObjectId + submesh slot, not the current Unity content hash.
    records = {r['id']: r for r in manifest['materials']}
    pending, groups, slots, bases = [], {}, {}, {}
    candidates = {}
    updates, warnings = [], []
    for rec in manifest['objects']:
        oid = rec['id']; ob = owned.get(oid)
        prior = json.loads(ob.get('ulb_slot_bases', '[]')) if ob else []
        slots[oid] = [None] * len(rec['materials']); bases[oid] = []
        for i, mid in enumerate(rec['materials']):
            r = records[mid]; new = r.get('baseTexture') or ''
            bases[oid].append(new)
            mat = ob.material_slots[i].material if ob and i < len(ob.material_slots) else None
            if mat is None:
                pending.append((oid, i, mid))
                continue
            node = base_node(mat)
            if i < len(prior):
                old = prior[i]
            elif mat.get('ulb_material') == mid:
                old = new  # upgrade: don't replace a Blender-local image edit
            else:
                # Pre-0.1.14 file: the old receiver tagged imported images with their path.
                key = node.image.get('ulb_image', '') if node and node.image else ''
                old = 'textures/' + Path(key[:-6]).name if key.endswith('|color') else ''
            if node and not mat.library and not node.get('ulb_base_slot'):
                node['ulb_base_slot'] = True  # adopt the uniquely labelled legacy node
            change = new if new != old else None
            if change is not None and not node:
                warnings.append(mat.name + ': 主图节点未找到或不唯一；保留 Shader。')
                bases[oid][i] = old  # retry if user later identifies a node
                change = None
            groups.setdefault(mat, {}).setdefault(change, []).append((oid, i, mid))

    # Split only when previously shared instances now need different images.
    # All copies must be made from the unmodified artist graph.
    owned_objects = set(owned.values())
    external = {slot.material for obj in bpy.data.objects if obj not in owned_objects
                for slot in obj.material_slots} if any(any(k is not None for k in g) for g in groups.values()) else set()
    for mat, actions in groups.items():
        first = None if None in actions else next(iter(actions))
        for change, users in actions.items():
            target = mat if change is None or (change == first and mat not in external and not mat.library) else mat.copy()
            if change is not None:
                image = image_from(root, change) if change else neutral_base()
                updates.append((base_node(target), image))
            for oid, i, mid in users:
                slots[oid][i] = target
                if bases[oid][i] == (records[mid].get('baseTexture') or ''):
                    candidates.setdefault(mid, set()).add(target)
    # A new prefab referencing an existing, unambiguous material shares the
    # artist's version. Never arbitrarily pick one of two local art variants.
    fresh = {}
    for oid, i, mid in pending:
        variants = candidates.get(mid, ())
        if len(variants) == 1:
            slots[oid][i] = next(iter(variants))
        else:
            if mid not in fresh:
                fresh[mid] = build_material(root, records[mid])
            slots[oid][i] = fresh[mid]
    return slots, bases, updates, warnings


def build_mesh(root, rec, materials, cache):
    key = (rec['mesh'], tuple(materials))
    if key in cache:
        return cache[key]
    data = p.load_json(p.contained(root, "meshes/" + p.hex_id(rec["mesh"]) + ".json"))
    p.validate_mesh(data)
    vertices = [mapped(data["vertices"][i:i+3]) for i in range(0, len(data["vertices"]), 3)]
    triangles = data["triangles"]
    faces = [(triangles[i], triangles[i+2], triangles[i+1]) for i in range(0, len(triangles), 3)]
    if any(i < 0 or i >= len(rec["materials"]) for i in data["faceMaterials"]):
        raise ValueError("Face material index out of range: " + rec["name"])
    me = bpy.data.meshes.new(rec["name"] + " | Unity mesh")
    me.from_pydata(vertices, [], faces)
    me.update()
    me["ulb_mesh"] = rec["mesh"]
    me["ulb_geometry"] = rec["mesh"]
    for mat in materials:
        me.materials.append(mat)
    for poly, slot in zip(me.polygons, data["faceMaterials"]):
        poly.material_index = slot
        poly.use_smooth = True
    for field, name in (("uv0", "UV0"), ("uv2", "UV2")):
        coords = data.get(field) or []
        if coords:
            layer = me.uv_layers.new(name=name)
            for loop in me.loops:
                i = loop.vertex_index * 2
                layer.data[loop.index].uv = coords[i:i+2]
    normals = data.get("normals") or []
    if normals:
        converted = [mapped(normals[i:i+3]) for i in range(0, len(normals), 3)]
        me.normals_split_custom_set([converted[l.vertex_index] for l in me.loops])
    if me.uv_layers.get("UV0"):
        me.uv_layers.active = me.uv_layers["UV0"]
        me.uv_layers["UV0"].active_render = True
    cache[key] = me
    return me


def assign_transform(ob, base, values):
    """Flatten ordinary transforms; preserve inherited shear in a private evaluated mesh."""
    matrix = unity_matrix(values)
    location, rotation, scale = matrix.decompose()
    reconstructed = Matrix.Translation(location) @ rotation.to_matrix().to_4x4() @ Matrix.Diagonal((*scale, 1))
    error = max(abs(matrix[i][j]-reconstructed[i][j]) for i in range(4) for j in range(4))
    ob.parent = None
    if error <= 1e-6:
        ob.data = base
        ob.matrix_world = matrix
        return
    # Blender Object TRS cannot represent arbitrary Unity parent-induced shear.
    # Keep the immutable shared base; only this instance gets evaluated geometry.
    work = base.copy()
    if 'ulb_mesh' in work:
        del work['ulb_mesh']
    work['ulb_shear'] = True
    corner_normals = [n.vector.copy() for n in base.corner_normals]
    per_face = [{base.loops[i].vertex_index: corner_normals[i] for i in face.loop_indices} for face in base.polygons]
    normal_matrix = matrix.to_3x3().inverted().transposed()
    work.transform(matrix)
    if matrix.determinant() < 0:
        work.flip_normals()
    transformed = [None]*len(work.loops)
    for face in work.polygons:
        for i in face.loop_indices:
            transformed[i] = (normal_matrix @ per_face[face.index][work.loops[i].vertex_index]).normalized()
    work.normals_split_custom_set(transformed)
    ob.data = work
    ob.matrix_world = Matrix.Identity(4)

def sync_scene(root, scene=None):
    scene = scene or bpy.context.scene
    manifest = p.load_json(Path(root)/"scene.json")
    p.validate_scene(manifest)
    project = manifest["projectId"]
    other_projects = [c for c in scene.collection.children if c.get("ulb_project") and c.get("ulb_project") != project]
    if other_projects:
        raise ValueError("This Blender scene already contains a different Unity project; use a separate Blender scene/file")
    collection = collection_for(scene, project)
    # Validate/build every asset before updating any scene object.
    owned = {o.get('ulb_id'): o for o in collection.objects if o.get('ulb_project') == project}
    slots, bases, updates, warnings = material_plan(root, manifest, owned)
    cache = {(me.get('ulb_geometry'), tuple(me.materials)): me for me in bpy.data.meshes if me.get('ulb_mesh')}
    meshes = {o['id']: build_mesh(root, o, slots[o['id']], cache) for o in manifest['objects']}
    for node, image in updates:
        node.image = image
    scene['ulb_material_warning'] = warnings[0] if warnings else ''
    for message in dict.fromkeys(warnings):
        print('Unity Live Bake:', message)
    keep = set()
    for rec in manifest["objects"]:
        keep.add(rec["id"])
        ob = owned.get(rec["id"])
        if ob is None:
            ob = bpy.data.objects.new(rec["name"], meshes[rec["id"]])
            collection.objects.link(ob)
        else:
            ob.data = meshes[rec["id"]]
        ob.name = rec["name"]
        assign_transform(ob, meshes[rec["id"]], rec["matrix"])
        ob["ulb_id"] = rec["id"]
        ob["ulb_project"] = project
        for slot, mat in zip(ob.material_slots, slots[rec['id']]):
            if slot.link == 'OBJECT' and slot.material != mat:
                slot.material = mat
        ob['ulb_slot_bases'] = json.dumps(bases[rec['id']])
        ob["ulb_token"] = rec["token"]
        ob["ulb_source_hash"] = rec["sourceHash"]
        ob["ulb_mesh_id"] = rec["mesh"]
    for oid, ob in owned.items():
        if oid not in keep:
            bpy.data.objects.remove(ob, do_unlink=True)
    # Only orphaned bridge datablocks; never purge user data globally.
    for me in list(bpy.data.meshes):
        if (me.get("ulb_mesh") or me.get("ulb_shear")) and me.users == 0:
            bpy.data.meshes.remove(me)
    for mat in list(bpy.data.materials):
        if mat.get("ulb_material") and mat.users == 0:
            bpy.data.materials.remove(mat)
    scene["ulb_project"] = project
    scene["ulb_revision"] = manifest["revision"]
    scene["ulb_scene_hash"] = manifest["sceneHash"]
    bpy.context.view_layer.update()
    return manifest




