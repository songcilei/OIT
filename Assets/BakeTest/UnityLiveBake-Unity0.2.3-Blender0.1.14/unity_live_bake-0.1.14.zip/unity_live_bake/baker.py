"""Per-instance UV2 Combined bake. All outputs become visible only via a final manifest."""
import json
import time
from pathlib import Path
import bpy
from . import protocol as p
from . import receiver, atlas


def _cycles_bake(**args):
    return bpy.ops.object.bake(**args)


def output_profile(scene):
    cfg = scene.render.image_settings
    follow = cfg.color_management == "FOLLOW_SCENE"
    view = scene.view_settings if follow else cfg.view_settings
    display = scene.display_settings if follow else cfg.display_settings
    profile = dict(fileFormat=cfg.file_format, colorDepth=int(cfg.color_depth), colorMode=cfg.color_mode,
                   management=cfg.color_management, display=display.display_device, transform=view.view_transform,
                   look=view.look, exposure=view.exposure, gamma=view.gamma, dither=scene.render.dither_intensity,
                   whiteBalance=view.use_white_balance, temperature=view.white_balance_temperature, tint=view.white_balance_tint,
                   curveEnabled=view.use_curve_mapping)
    if view.use_curve_mapping and view.curve_mapping:
        cm = view.curve_mapping
        profile['curves'] = [[(tuple(pt.location), pt.handle_type) for pt in curve.points] for curve in cm.curves]
        profile['blackLevel'],profile['whiteLevel'] = tuple(cm.black_level),tuple(cm.white_level)
    if cfg.file_format == 'PNG': profile['compression'] = cfg.compression
    if cfg.file_format == 'OPEN_EXR':
        profile['codec'] = cfg.exr_codec
        if not follow: profile['linearSpace'] = cfg.linear_colorspace_settings.name
    return profile


def write_status(root, state, message, project="", revision="", request="", done=0, total=0):
    p.atomic_json(Path(root)/"status.json", dict(state=state, message=message, projectId=project, revision=revision,
                                               requestId=request, done=done, total=total, unixTime=time.time(), supportsAtlas=True, supportsStopQueue=True, supportsBlenderOutput=True, addonVersion="0.1.14", supportsMainTexOverride=True, supportsSkipDegenerateUV2=True, supportsSkipUV2Validation=True))


class BakeSession:
    def __init__(self, root, request, scene=None):
        self.root = Path(root)
        self.req = request
        self.scene = scene or bpy.context.scene
        # Snapshot this Blender-local option once. A whole Unity batch uses one policy.
        self.uv_seam_guard = getattr(getattr(self.scene, "ulb_settings", None), "uv_seam_guard", True)
        self.items = []
        self.warnings = []
        self.skipped_degenerate_faces = 0
        self.index = 0
        self.cancelled = False
        self.atlas_mode = bool(request.get("atlas", False))
        self.atlas_image = None
        self.atlas_layout = []
        p.validate_request(request)
        if request["format"] == "BLENDER" and self.scene.render.image_settings.file_format not in ("PNG", "OPEN_EXR"):
            raise ValueError("当前 Blender 输出格式是 %s；请选择 PNG 或单层 OpenEXR。" % self.scene.render.image_settings.file_format)
        self.profile = output_profile(self.scene) if request["format"] == "BLENDER" else None
        self.output_format = request["format"]
        if self.profile:
            self.output_format = {"PNG":"PNG", "OPEN_EXR":"EXR"}.get(self.profile["fileFormat"])
            if not self.output_format:
                raise ValueError("当前 Blender 输出格式是 %s；请在输出属性选择 PNG 或单层 OpenEXR，再烘焙。" % self.profile["fileFormat"])
            if self.output_format == "PNG" and self.profile['display'] != 'sRGB':
                self.warnings.append("Blender PNG uses %s; Unity assumes sRGB. Match display profiles for color-critical review." % self.profile['display'])
            if self.output_format == "EXR" and self.profile.get('linearSpace') not in (None,'','Linear Rec.709'):
                self.warnings.append("EXR uses %s; convert the gamut in Unity to match Blender." % self.profile['linearSpace'])
        self.manifest = p.load_json(self.root/"scene.json")
        p.validate_scene(self.manifest)
        for field in ("projectId", "revision", "sceneHash"):
            if self.manifest[field] != request[field]:
                raise ValueError("Bake request refers to an old scene snapshot: " + field)
        # Reassert Unity geometry/transforms before baking; Blender-authored lights/world survive.
        receiver.sync_scene(root, self.scene)
        records = self.manifest["objects"]
        if not records:
            raise ValueError("No synced objects")
        if self.atlas_mode:
            self.atlas_layout = atlas.layout(len(records), request["resolution"], request["margin"])
        checked = {}
        for rec in records:
            if rec["mesh"] not in checked:
                data = p.load_json(p.contained(root, "meshes/"+rec["mesh"]+".json"))
                try:
                    info = {}
                    p.validate_uv2(data, skip_degenerate=bool(request.get("skipDegenerateUV2", False)), diagnostics=info, skip_quality=bool(request.get("skipUV2Validation", False)))
                except ValueError as e:
                    raise ValueError(rec["name"]+": "+str(e)) from e
                checked[rec["mesh"]] = info
            info = checked[rec["mesh"]]
            if info.get("qualityChecksSkipped"):
                self.warnings.append("%s: ALL UV2 quality checks skipped (degeneracy, overlap, bounds). UV/geometry unchanged; bake artifacts and cross-tile writes are possible. Invalid-face counts were NOT computed." % rec["name"])
            if info.get("degenerateFaces", 0):
                count = info["degenerateFaces"]
                self.skipped_degenerate_faces += count
                self.warnings.append("%s: skipped UV2 degeneration checks for %d triangles (sample face IDs: %s). Geometry was NOT removed; these faces may bake incorrectly." % (rec["name"], count, info["sampleFaces"]))
        coll = receiver.collection_for(self.scene, request["projectId"])
        self.objects = {o.get("ulb_id"): o for o in coll.objects}
        for rec in records:
            ob = self.objects[rec["id"]]
            if ob.hide_render or ob.hide_get() or not ob.visible_get():
                raise ValueError("Synced object is hidden/excluded: "+ob.name)
        self.signature = self._signature()
        self.old_engine = self.scene.render.engine
        self.old_samples = self.scene.cycles.samples
        self.old_bake = {k: getattr(self.scene.render.bake, k) for k in ("use_selected_to_active", "use_clear", "margin", "target", "use_pass_direct", "use_pass_indirect", "use_pass_color", "use_pass_diffuse", "use_pass_glossy", "use_pass_transmission", "use_pass_emit")}
        self.old_selected = list(bpy.context.selected_objects)
        self.old_active = bpy.context.view_layer.objects.active
        self.old_mode = bpy.context.object.mode if bpy.context.object else "OBJECT"
        if self.old_mode != "OBJECT":
            raise ValueError("Leave Edit/Sculpt mode before baking")
        self.scene.render.engine = "CYCLES"
        self.scene.cycles.samples = request["samples"]
        self.scene.render.bake.use_selected_to_active = False
        self.scene.render.bake.use_clear = True
        self.scene.render.bake.margin = request["margin"]
        self.scene.render.bake.target = "IMAGE_TEXTURES"
        self.finished = False
        write_status(root, "baking", ("UV2 validated; starting Cycles" if not self.warnings else ("WARNING: ALL UV2 quality checks skipped; starting Cycles" if request.get("skipUV2Validation",False) else "WARNING: %d degenerate UV2 faces allowed; starting Cycles" % self.skipped_degenerate_faces)), request["projectId"], request["revision"], request["id"], 0, len(records))

    def _signature(self):
        """Catch normal scene edits between bake steps, including lights and world changes."""
        records = []
        for ob in self.scene.objects:
            records.append((ob.name, ob.type, tuple(v for row in ob.matrix_world for v in row), ob.hide_render))
            if ob.type == "LIGHT":
                records.append((ob.data.type, tuple(ob.data.color), ob.data.energy, getattr(ob.data, "size", 0)))
        world = self.scene.world
        if world and world.use_nodes:
            for node in world.node_tree.nodes:
                vals = []
                for inp in node.inputs:
                    if hasattr(inp, "default_value"):
                        v = inp.default_value
                        vals.append(tuple(v) if hasattr(v, "__iter__") and not isinstance(v, str) else str(v))
                records.append((node.name, vals))
        records.append((self.scene.view_settings.view_transform, self.scene.view_settings.look,
                        self.scene.view_settings.exposure, self.scene.view_settings.gamma))
        if self.profile: records.append(output_profile(self.scene))
        return repr(records)

    def _stop_requested(self):
        path = self.root/"requests"/"stop"/(self.req["id"]+".json")
        try:
            marker = p.load_json(path)
        except FileNotFoundError:
            return False
        return (isinstance(marker, dict) and marker.get("schema") == 1
                and marker.get("projectId") == self.req["projectId"]
                and marker.get("requestId") == self.req["id"])

    def step(self):
        if self.finished:
            return False
        try:
            # One immutable marker per batch. No polling of Cycles / no hard interruption.
            # This boundary is also reached before the first object of a queued request.
            if not self.cancelled and self._stop_requested():
                self.cancelled = True
                self._finish("cancelled", "队列已停止：已烘焙 %d/%d 个物体，本批未应用。" % (self.index, len(self.manifest["objects"])))
                return False
            if self.cancelled:
                raise RuntimeError("Cancelled between objects; no partial result applied")
            current = p.load_json(self.root/"scene.json")
            if current["sceneHash"] != self.req["sceneHash"]:
                raise RuntimeError("Unity scene changed during bake; stale results were not published")
            if self._signature() != self.signature:
                raise RuntimeError("Blender scene/light/view settings changed during bake; retry after edits")
            rec = self.manifest["objects"][self.index]
            write_status(self.root, "baking", "Baking "+rec["name"], self.req["projectId"], self.req["revision"], self.req["id"], self.index, len(self.manifest["objects"]))
            self.items.append(self._bake_object(self.objects[rec["id"]], rec))
            self.index += 1
            if self.index < len(self.manifest["objects"]):
                return True
            # A transform/material update might arrive while the last blocking bake ran.
            if p.load_json(self.root/"scene.json")["sceneHash"] != self.req["sceneHash"]:
                raise RuntimeError("Unity scene changed during bake; results retained but not applied")
            if self.atlas_mode:
                write_status(self.root, "baking", "Saving shared atlas", self.req["projectId"], self.req["revision"], self.req["id"], self.index, len(self.manifest["objects"]))
                relative, digest = self._save_image(self.atlas_image, "atlas")
                for item in self.items:
                    item.update(image=relative, sha256=digest)
            # Saving a large atlas can take time too; recheck before publishing.
            if p.load_json(self.root/"scene.json")["sceneHash"] != self.req["sceneHash"]:
                raise RuntimeError("Unity scene changed before result publication")
            self._finish("complete", "")
            return False
        except Exception as e:
            self._finish("cancelled" if self.cancelled else "failed", str(e))
            raise

    def _bake_object(self, ob, rec):
        old_mesh = ob.data
        saved_slots = [(slot.link, slot.material) for slot in ob.material_slots]
        work = old_mesh.copy()
        ob.data = work
        mats = []
        image = None
        try:
            # Separate each instance's bake targets even if source mesh/materials are shared.
            for i, (_, source) in enumerate(saved_slots):
                mat = source.copy()
                mats.append(mat)
                ob.material_slots[i].link = "DATA"
                work.materials[i] = mat
            if self.atlas_mode:
                if self.atlas_image is None:
                    self.atlas_image = bpy.data.images.new("ULB Shared Atlas", self.req["resolution"], self.req["resolution"], alpha=True, float_buffer=True)
                    self.atlas_image.colorspace_settings.name = "Linear Rec.709"
                image = self.atlas_image
            else:
                image = bpy.data.images.new("ULB "+rec["token"], self.req["resolution"], self.req["resolution"], alpha=True, float_buffer=True)
                image.colorspace_settings.name = "Linear Rec.709"
            st = self.atlas_layout[self.index]["scaleOffset"] if self.atlas_mode else [1., 1., 0., 0.]
            if self.atlas_mode:
                for loop in work.uv_layers["UV2"].data:
                    uv = loop.uv.copy()
                    loop.uv = (uv.x*st[0]+st[2], uv.y*st[1]+st[3])
            for mat in mats:
                for node in mat.node_tree.nodes:
                    node.select = False
                target = mat.node_tree.nodes.new("ShaderNodeTexImage")
                target.name = "ULB_BAKE_TARGET"
                target.image = image
                target.select = True
                mat.node_tree.nodes.active = target
            work.uv_layers.active = work.uv_layers["UV2"]
            guard = self.uv_seam_guard and len(work.uv_layers) > 1
            work.uv_layers["UV0" if guard else "UV2"].active_render = True
            for selected in list(bpy.context.selected_objects):
                selected.select_set(False)
            ob.select_set(True)
            bpy.context.view_layer.objects.active = ob
            passes = {"COLOR", "DIRECT", "INDIRECT", "DIFFUSE", "EMIT"}
            if self.req.get("includeGlossy", True):
                passes.add("GLOSSY")
            args = dict(type="COMBINED", pass_filter=passes, use_selected_to_active=False,
                        use_clear=(not self.atlas_mode or self.index == 0), margin=self.req["margin"])
            if guard:
                # Do not pass uv_layer here. In Blender 5.0.1, baking via the active
                # edit UV gives different adjacent-face margins than the explicit override.
                args["margin_type"] = "ADJACENT_FACES"
            else:
                args["uv_layer"] = "UV2"
            denoise = self.scene.cycles.use_denoising
            margin_type = self.scene.render.bake.margin_type
            try:
                if guard:
                    self.scene.cycles.use_denoising = False
                if "FINISHED" not in _cycles_bake(**args):
                    raise RuntimeError("Cycles did not finish baking " + rec["name"])
            finally:
                if guard:
                    self.scene.cycles.use_denoising = denoise
                    self.scene.render.bake.margin_type = margin_type
            if self.atlas_mode:
                return dict(id=rec["id"], token=rec["token"], sourceHash=rec["sourceHash"], scaleOffset=st)
            relative, digest = self._save_image(image, rec["token"])
            return dict(id=rec["id"], token=rec["token"], sourceHash=rec["sourceHash"], image=relative, sha256=digest, scaleOffset=st)
        finally:
            ob.data = old_mesh
            for slot, (link, source) in zip(ob.material_slots, saved_slots):
                if link == 'OBJECT':
                    slot.link = link
                    slot.material = source
            bpy.data.meshes.remove(work)
            for mat in mats:
                if mat.users == 0:
                    bpy.data.materials.remove(mat)
            if image and not self.atlas_mode:
                bpy.data.images.remove(image)

    def _save_image(self, image, token):
        ext = ".png" if self.output_format == "PNG" else ".exr"
        relative = "results/"+self.req["id"]+"/"+token+ext
        path = p.contained(self.root, relative)
        path.parent.mkdir(parents=True, exist_ok=True)
        if self.profile:
            if output_profile(self.scene) != self.profile:
                raise RuntimeError("Blender output/color settings changed during bake; no batch published")
            # Use exactly Blender's Save As Render path. Do not mutate a single output setting.
            image.save_render(str(path), scene=self.scene)
        elif self.output_format == "PNG":
            settings = self.scene.render.image_settings
            old = (settings.file_format, settings.color_mode, settings.color_depth)
            try:
                settings.file_format = "PNG"
                settings.color_mode = "RGB"
                settings.color_depth = "8"
                image.save_render(str(path), scene=self.scene)
            finally:
                settings.file_format, settings.color_mode, settings.color_depth = old
        else:
            image.file_format = "OPEN_EXR"
            image.filepath_raw = str(path)
            image.save()
        return relative, p.sha256_file(path)

    def _finish(self, status, error):
        if self.finished:
            return
        self.finished = True
        if self.atlas_image is not None:
            bpy.data.images.remove(self.atlas_image)
            self.atlas_image = None
        self.scene.render.engine = self.old_engine
        self.scene.cycles.samples = self.old_samples
        for key, value in self.old_bake.items():
            setattr(self.scene.render.bake, key, value)
        for ob in list(bpy.context.selected_objects):
            ob.select_set(False)
        for ob in self.old_selected:
            if ob.name in bpy.context.view_layer.objects:
                ob.select_set(True)
        if self.old_active and self.old_active.name in bpy.context.view_layer.objects:
            bpy.context.view_layer.objects.active = self.old_active
        result = dict(schema=1, projectId=self.req["projectId"], id=self.req["id"], revision=self.req["revision"],
                      sceneHash=self.req["sceneHash"], status=status, error=error, format=self.output_format,
                      outputProfile=self.profile, colorDepth=self.profile["colorDepth"] if self.profile else 0, colorMode=self.profile["colorMode"] if self.profile else "",
                      completedObjects=self.index, totalObjects=len(self.manifest["objects"]), uvSeamGuard=self.uv_seam_guard, items=self.items if status == "complete" else [], warnings=self.warnings, skippedUV2Validation=bool(self.req.get("skipUV2Validation", False)), skippedDegenerateUV2=bool(self.req.get("skipDegenerateUV2", False)), skippedDegenerateFaces=self.skipped_degenerate_faces, atlas=self.atlas_mode, atlasSize=self.req["resolution"] if self.atlas_mode else 0)
        p.atomic_json(self.root/"results"/self.req["id"]/"result.json", result)
        p.atomic_json(self.root/"results"/"latest.json", result)
        write_status(self.root, "ready" if status == "complete" else status, error or "Bake complete; Unity can import", self.req["projectId"], self.req["revision"], self.req["id"], self.index, len(self.manifest["objects"]))

