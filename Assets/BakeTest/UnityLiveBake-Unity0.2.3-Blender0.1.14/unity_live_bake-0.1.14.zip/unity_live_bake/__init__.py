bl_info = {
    "name": "Unity Live Bake Bridge", "author": "Live Bake Bridge", "version": (0, 1, 14),
    "blender": (4, 2, 0), "location": "3D View > Sidebar > Unity Bake",
    "description": "Receive Unity scene instances and bake full appearance to existing UV2", "category": "Import-Export",
}
import time
from pathlib import Path
import bpy
from bpy.app.handlers import persistent
from bpy.props import StringProperty, IntProperty, BoolProperty, PointerProperty
from . import protocol as p
from . import receiver, baker

_RUNNING = False
_SESSION = None
_LAST_REVISION = ""
_MESSAGE = "Receiver stopped"


class ULBSettings(bpy.types.PropertyGroup):
    folder: StringProperty(name="Exchange folder", subtype="DIR_PATH")
    uv_seam_guard: BoolProperty(
        name="多 UV 接缝保护",
        description="多 UV 的 Combined 烘焙：保持源 UV0，使用活动 UV2 写图、相邻面扩边并临时关闭 Cycles 降噪。扩边像素数沿用 Unity 设置；关闭使用旧流程",
        default=True,
    )
    resolution: IntProperty(name="Resolution", default=1024, min=64, max=4096)


def _root():
    value = bpy.context.scene.ulb_settings.folder
    if not value:
        raise ValueError("Paste Unity's exchange folder path first")
    return Path(bpy.path.abspath(value)).resolve()


def _failure(root, req, error):
    result = dict(schema=1, projectId=req.get("projectId", ""), id=req.get("id", ""), revision=req.get("revision", ""), sceneHash=req.get("sceneHash", ""), status="failed", error=str(error), format=req.get("format", "PNG"), items=[], skippedUV2Validation=bool(req.get("skipUV2Validation", False)), skippedDegenerateUV2=bool(req.get("skipDegenerateUV2", False)))
    p.atomic_json(root/"results"/"latest.json", result)
    baker.write_status(root, "failed", str(error), req.get("projectId", ""), req.get("revision", ""), req.get("id", ""))


def tick():
    global _SESSION, _LAST_REVISION, _MESSAGE
    if not _RUNNING:
        return None
    try:
        root = _root()
        if _SESSION:
            _MESSAGE = "Baking — cancel takes effect after the current object"
            try:
                more = _SESSION.step()
            finally:
                if _SESSION.finished:
                    _MESSAGE = "Queue stopped; receiver ready" if _SESSION.cancelled else "Bake finished; inspect Unity status / results"
                    _SESSION = None
            return .2
        if not (root/"scene.json").is_file():
            _MESSAGE = "Waiting for Unity scene.json"
            baker.write_status(root, "waiting", _MESSAGE)
            return .5
        manifest = p.load_json(root/"scene.json")
        p.validate_scene(manifest)
        if manifest["revision"] != _LAST_REVISION or bpy.context.scene.get("ulb_revision") != manifest["revision"]:
            receiver.sync_scene(root)
            _LAST_REVISION = manifest["revision"]
            _MESSAGE = "Synced %d instances. Add lights in Blender, then bake in Unity." % len(manifest["objects"])
        request_path = root/"requests"/"bake.json"
        if request_path.exists():
            req = p.load_json(request_path)
            handled_path = root/"requests"/"handled.json"
            handled = p.load_json(handled_path) if handled_path.exists() else {}
            if req.get("id") != handled.get("id"):
                # Claim before starting: a restart must not replay an interrupted bake automatically.
                p.validate_request(req)
                p.atomic_json(handled_path, dict(id=req["id"], claimedAt=time.time()))
                try:
                    _SESSION = baker.BakeSession(root, req)
                except Exception as e:
                    _failure(root, req, e)
                    _MESSAGE = str(e)
                return .5
        baker.write_status(root, "ready", _MESSAGE, manifest["projectId"], manifest["revision"])
    except Exception as e:
        _MESSAGE = "Bridge error: " + str(e)
        print(_MESSAGE)
        try:
            baker.write_status(_root(), "error", _MESSAGE)
        except Exception:
            pass
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()
    return .5


class ULB_OT_start(bpy.types.Operator):
    bl_idname = "ulb.start"
    bl_label = "Start Live Receiver"
    def execute(self, context):
        global _RUNNING, _LAST_REVISION, _MESSAGE
        try:
            root = _root()
            root.mkdir(parents=True, exist_ok=True)
            if _RUNNING:
                return {"FINISHED"}
            _RUNNING = True
            _LAST_REVISION = ""
            _MESSAGE = "Receiver starting"
            if not bpy.app.timers.is_registered(tick):
                bpy.app.timers.register(tick, first_interval=.1)
            return {"FINISHED"}
        except Exception as e:
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}


class ULB_OT_stop(bpy.types.Operator):
    bl_idname = "ulb.stop"
    bl_label = "Stop Receiver / Cancel Bake"
    def execute(self, context):
        global _RUNNING, _MESSAGE
        if _SESSION:
            _SESSION.cancelled = True
            _MESSAGE = "Cancel requested; current object must finish first"
        else:
            _RUNNING = False
            _MESSAGE = "Receiver stopped"
            if bpy.app.timers.is_registered(tick):
                bpy.app.timers.unregister(tick)
            try:
                baker.write_status(_root(), "stopped", _MESSAGE)
            except Exception:
                pass
        return {"FINISHED"}


class ULB_OT_lights(bpy.types.Operator):
    bl_idname = "ulb.demo_lights"
    bl_label = "Add Starter Lighting (Optional)"
    bl_options = {"REGISTER", "UNDO"}
    def execute(self, context):
        from mathutils import Vector
        project = context.scene.get("ulb_project")
        objects = [o for o in context.scene.objects if project and o.get("ulb_project") == project and o.type == "MESH"]
        if not objects:
            self.report({"ERROR"}, "Sync a Unity scene first")
            return {"CANCELLED"}
        points = [o.matrix_world @ Vector(corner) for o in objects for corner in o.bound_box]
        center = sum(points, Vector())/len(points)
        extent = max(1.0, max((point-center).length for point in points))
        col = bpy.data.collections.new("LIVE BAKE | User lighting")
        context.scene.collection.children.link(col)
        for name, offset, power, color in (("Key", (-1.5, -1.5, 2.5), 500, (1,.85,.7)), ("Fill", (1.5, 1, 2), 180, (.65,.78,1))):
            data = bpy.data.lights.new(name, "AREA")
            ob = bpy.data.objects.new(name, data)
            col.objects.link(ob)
            ob.location = center + Vector(offset)*extent
            ob.rotation_euler = (center-ob.location).to_track_quat('-Z', 'Y').to_euler()
            data.energy = power*extent*extent
            data.shape = "DISK"
            data.size = extent*2
            data.color = color
        self.report({"INFO"}, "Added lights only; existing world, lights, cameras and view transform kept")
        return {"FINISHED"}


class ULB_PT_panel(bpy.types.Panel):
    bl_label = "Unity Live Bake 0.1.14"
    bl_idname = "ULB_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Unity Bake"
    def draw(self, context):
        layout = self.layout
        layout.prop(context.scene.ulb_settings, "folder")
        options = layout.column()
        options.enabled = _SESSION is None
        options.prop(context.scene.ulb_settings, "uv_seam_guard")
        row = layout.row()
        row.operator("ulb.start", icon="PLAY")
        row.operator("ulb.stop", icon="CANCEL")
        layout.operator("ulb.demo_lights", icon="LIGHT_AREA")
        layout.label(text="Running" if _RUNNING else "Stopped")
        box = layout.box()
        box.label(text=_MESSAGE[:90])
        if context.scene.get('ulb_material_warning'):
            box.label(text=context.scene['ulb_material_warning'], icon='INFO')
        box.label(text="Source geometry/UVs are owned by Unity.")
        box.label(text="Author lights/world here; bake from Unity.")
        box.label(text="Do not edit scene during a bake.")
        box.label(text="Cancel works between objects, not samples.")


@persistent
def reset_on_load(_):
    global _RUNNING, _SESSION, _LAST_REVISION, _MESSAGE
    # Timers are non-persistent; don't carry an old scene's receiver across .blend loads.
    _RUNNING = False
    _SESSION = None
    _LAST_REVISION = ""
    _MESSAGE = "Scene loaded; start the receiver again"


CLASSES = (ULBSettings, ULB_OT_start, ULB_OT_stop, ULB_OT_lights, ULB_PT_panel)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.ulb_settings = PointerProperty(type=ULBSettings)
    bpy.app.handlers.load_post.append(reset_on_load)


def unregister():
    global _RUNNING, _SESSION
    _RUNNING = False
    if bpy.app.timers.is_registered(tick):
        bpy.app.timers.unregister(tick)
    if _SESSION:
        _SESSION._finish("cancelled", "Add-on disabled")
        _SESSION = None
    if reset_on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(reset_on_load)
    del bpy.types.Scene.ulb_settings
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)

