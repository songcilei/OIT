# Unity ↔ Blender Live Bake v0.1.8

### Unity 0.2.4 / Blender 0.1.15：隐藏不删除材质
Unity 内通过层级眼睛、关闭 MeshRenderer 或停用物体/父级隐藏对象，Blender 只暂停该实例的视口显示和渲染，并保留对象、全部材质槽、图像和 Shader。隐藏对象不参与烘焙；重新显示后恢复先前的 Blender 可见性。隐藏期间真正更换的 Unity 主图仍按主贴图规则在显示时同步。删除 Renderer 或移出同步范围仍按删除处理。请配套升级两端；带隐藏 ID 的快照使用场景协议 2，使旧接收器拒绝而不是误删对象。


### Blender 接收器 0.1.14：保留 Blender Shader（Unity 端无需升级）

- 以 Unity Renderer ID + 材质槽序号识别已同步的材质。首次创建或复用材质，之后保留 Blender 节点、连线、采样、UV Mapping 和参数；Unity `_BaseMap` / `_MainTex` 的选取规则不变。重连、重开已保存的 `.blend`、烘焙前同步同样适用。
- 只有 Unity 导出的主贴图内容变化时才换主图节点的 Image；源图清空时切换到中性白图。不修改法线、自发光等其他贴图。多个实例共用材质又需要不同主图时，从现有 Shader 复制出独立版本。
- 保留最外层的主纹理节点即可；节点可改名、移动和重新接线。若删除、移入节点组或有多个候选，插件不会猜测或重建。要重新绑定，在材质最外层设置唯一目标 Image Texture 的 **Label** 为 `baseTexture`，然后重新同步（或重启 Receiver）。旧版场景若从未生成过主图节点，也可这样指定。
- Unity 若删除后重建了 Renderer，或重新排列了材质槽，这不等同于原有槽换贴图；请留意对应关系。


把 Unity 中摆放的 Prefab **场景实例**同步到 Blender，在 Blender 中布光，使用原网格的第二套 UV 烘焙 **颜色 + 灯光 + 阴影**，然后将结果绑定回 Unity 原实例，用 UV2 Unlit 显示。

这是可测试的第一版，不是 Unity 原生 Lightmap，也不是只把 FBX 来回导出。没有外部付费服务、账号或联网生成。

## 已验证环境

- Windows；Unity **2022.3.62f3**。
- Built-in / Standard，以及 **URP 14.0.11** 的 Unlit 渲染与 Lit 源材质导出。
- Blender **5.0.1**；插件声明最低 4.2，其他版本未实机验证。
- Unity 6、HDRP、Mac/Linux 尚未完成实机验证。

## 安装（不需要先修改项目代码）

1. 将本交付包解压到较短、固定的本地目录，例如 `D:\Tools\UnityBlenderLiveBake`。避免 Windows 路径过长。
2. Unity → **Window → Package Manager → + → Add package from disk**，选择 `UnityPackage/package.json`。
   - 也可选 **Add package from tarball**，安装 `dist/com.local.unity-blender-live-bake-0.1.8.tgz`。
   - 二选一，不要同时安装两份。
3. Blender → **Edit → Preferences → Add-ons → Install from Disk**，选择 `dist/unity_live_bake-0.1.8.zip`，启用 **Unity Live Bake Bridge**。
4. Blender 3D 视图按 **N**，打开 **Unity Bake** 面板。

## 第一次使用

### 1. Unity 选择同步范围

- 保存 Unity 场景。
- 在 Hierarchy 中选中要同步的一个或多个场景根节点。可以是包含许多 Prefab 的父物体。
- 打开 **Tools → Unity ↔ Blender Live Bake**。
- 点击 **Use Selected GameObjects as Sync Roots**。
- 点击 **Sync Now / Refresh Assets**。勾选 **Live sync** 后，移动/旋转/缩放、新增、复制、删除会按间隔增量更新，默认 0.5 秒。
- 点击 **Copy path**。默认交换目录是当前 Unity 项目的 `Library/UnityBlenderLiveBake`。
- 刚复制实例后建议保存场景；实例身份使用场景中的 GlobalObjectId，不是名称或数组顺序。

### 2. Blender 接收

- 推荐打开一个新的 Blender 文件，删除不需要参与烘焙的默认 Cube。插件不会擅自删除你原来的物体。
- 将上一步路径粘贴到 **Exchange folder**，点击 **Start Live Receiver**。
- Unity 内容出现在 `UNITY LIVE | 项目标识` 集合中。
- Unity 拥有该集合内的模型、变换、UV 和基础材质。不要在 Blender 手改这些内容后期待它们回传；下一次同步/烘焙前会恢复 Unity 的源状态。
- **灯光、World、相机、你自己的集合不会被同步覆盖。** 你在 Blender 布光；可点击 **Add Starter Lighting** 添加初始面光源，也可以完全自己布光。
- 交换目录只允许一个 Unity 项目和一个 Blender 接收器使用；不要开两个 Blender 同时接收同一目录。

### 3. 检查 UV2

- Unity `Mesh.uv2` → Blender `UV2` → Unlit Shader `TEXCOORD1`，始终是第二套 UV。
- 原材质贴图使用 `UV0`；烘焙写入 `UV2`，不会用 UV2 去重新采样原材质。
- 没有 UV2：在模型 Import Settings → Model 中打开 **Generate Lightmap UVs**，Apply，回工具窗口刷新；或在建模工具中做好第二套 UV。
- UV2 必须在 0..1 内、没有正面积重叠、没有退化 UV 三角形。
- UV2 岛间距应足够容纳所选分辨率下的扩边和 mipmap。检查能发现重叠，但不自动保证每个 UV 岛的 texel density / padding 合理。
- 工具**不自动重展开**、不覆盖现有 UV，不修改原模型文件。v0.1.1 提供显式「Generate Missing UV2 (Copies)」按钮，只为没有 UV2 的场景实例生成独立网格资产。

### 4. 一键烘焙并回传

在 Unity 窗口选择：
- **Per-instance resolution**：每个 MeshRenderer 独立贴图，默认 1024，可选 256–4096。
- **Cycles samples**：默认 64。
- **UV padding**：默认 16 像素。
- **Include glossy**：是否把镜面/高光也固定烘进去。
- **Output**：默认 PNG（包含 Blender 当前显示变换）；也可选 EXR 线性 HDR。
- **Auto-apply results**：默认开启。

点击 **Bake in Blender → Apply in Unity**。

Blender 依次烘焙每个场景实例。整个批次成功后才发布结果清单；Unity 检查项目、场景快照、实例身份、源数据哈希和图像校验值，导入贴图与材质，将其赋给原来的 MeshRenderer。

默认 Unity 结果目录：`Assets/LiveBakeGenerated/<场景名>/<物体名>/`（Unity 导入端 0.2.0 起）。

相同 Prefab 的不同实例使用不同的图。**不修改 Prefab 资产，不覆盖原材质资产。** 即使源网格和源材质相同，也不会因为共用同一贴图把两个位置的光照混在一起。

### 5. 恢复

- **Restore Original Materials**：恢复所有已加载场景中由本工具烘焙绑定的实例原材质、投影设置和原 lightmap 绑定。
- 应用/恢复支持 Undo。
- 烘焙贴图和材质资产会保留，不会自动删除。确认不需要旧批次后可自行整理。
- 应用后同步仍读取保留的原材质，不会把已烘焙颜色再送回 Blender 烘第二遍。
- 不要将 `LiveBakeBinding` 的原材质备份随意删除或 Apply 到 Prefab；若要清理，先 Restore。

## 两种输出及颜色匹配

### PNG：推荐用于“直接显示 Blender 的感觉”

- Cycles 的 Combined 结果经过 Blender 当前 View Transform / Look / Exposure，保存到 8-bit sRGB PNG。
- Unity 按 sRGB 贴图导入，用 UV2 Unlit 采样。
- **关闭 Unity 相机的 Tonemapping、Color Adjustments 等二次调色**，否则会再处理一次。
- 同样曝光/色彩配置下目标表面应接近 Blender；背景、抗锯齿、屏幕采样差异仍可能存在。
- Blender 的合成器、Glare/Bloom、景深、运动模糊、体积和相机屏幕效果不是表面 UV 烘焙，不会进入贴图。

### EXR：线性 HDR

- 不烘入 AgX/Filmic 显示变换和曝光，Unity 以线性纹理导入。
- 如需 Unity 和 Blender 显示一样，必须另行匹配两边的色彩管理/色调映射；不能默认认为 Unity ACES 与 Blender AgX 相同。

### 镜面与动态限制

高光/反射是固定到表面的颜色，不会随着 Unity 相机改变；Unlit 不再接受实时光照。适用于静态场景、风格化环境和固定外观道具，不适合需要真实动态镜面反射的产品展示。角色/道具移动后阴影仍留在贴图原位置，需重新烘焙。

## 第一版支持范围

| 功能 | 状态 |
|---|---|
| 场景 Prefab 实例/普通 GameObject | 支持静态 MeshRenderer + MeshFilter |
| 同步新增、删除、移动、旋转、缩放 | 支持，0.2–3 秒轮询可调 |
| 非均匀缩放、负缩放、父级引入的 shear | 支持；shear 在 Blender 使用私有求值网格保留 |
| 网格/纹理去重 | 内容哈希；普通实例复用网格，变换修改不重传纹理 |
| Unity 禁用 Read/Write 的模型和贴图 | 使用编辑器 MeshData 读取和 GPU 贴图导出 |
| 多子网格/多材质 | 支持；每实例合成一张 UV2 图，所有子网格用同一烘焙图 |
| Standard Metallic / URP Lit Metallic | 支持基础颜色、基础色图、法线、金属/光滑度、自发光、公共 UV0 Tiling/Offset |
| Repeat / Clamp、Point / Bilinear | 支持，Trilinear 在 Blender 对应 Linear |
| 原 AO 图 | 不乘进基础色，避免与 Cycles 几何遮蔽重复变暗；有提示，非 shader-identical |
| LODGroup | 仅 LOD0；其他 LOD 不参与烘焙 |
| SkinnedMesh、Terrain、粒子 | 不支持；跳过并提示 |
| 自定义 Shader、Shader Graph、HDRP、Specular workflow | 不支持，会阻止导出以免静默变错 |
| 透明、Alpha Clip、Detail/Parallax、MaterialPropertyBlock | 不支持，会提示处理后再导出 |
| 混合 U/V wrapping、Mirror wrapping | 不支持 |
| Unity 灯光同步 | 不包含；在 Blender 中布光 |
| 合并单图集 | v0.1.3 可选，按实例均匀网格分区，回传 Tiling/Offset |
| 自动 LOD 烘焙 / 按面积优化图集 / UV 重排 | 不包含 |
| 动画或实时烘焙 | 不包含；实时的是场景同步，烘焙是显式离线任务 |

Standard / URP 的 BRDF 与 Cycles Principled 并不完全一样。本工具用于把 Blender 做好的最终外观回传，不保证源 Unity 光照与 Blender 光照像素相同。

## 防错机制与注意事项

- 原子写入 `scene.json`，网格和纹理使用不可变内容哈希文件名，避免 Blender 读到半文件。
- 场景变化时不发布/不应用过期烘焙；结果保留，必须恢复场景或重新烘焙。
- 完整批次成功后才应用，不把失败一半的结果塞回场景。
- 每实例纹理 SHA-256、项目和实例映射检查。
- 接收器重启不会自动重复执行已认领的旧请求；中断后请显式重新烘焙。
- 烘焙期间不要编辑 Unity 或 Blender 场景。常见变换、灯光和显示设置变化会被检测，但不声称能发现所有第三方脚本对底层数据的修改。
- Blender 每个对象的 Cycles bake 是阻塞调用。界面可能暂时无响应；**取消在对象之间生效，不能承诺中途立即打断一个对象的采样**。
- 若 Unity 按钮提示已有排队请求，先让 Blender 接收。确认接收器停止且旧请求不需要时，可删除交换目录 `requests/bake.json` 后重新提交；不要在正在烘焙时这样操作。
- 交换目录是受信任的本机目录，不是对公网暴露的接口。不要选不可信共享目录或符号链接。
- 单实例独立 1K RGBA 未压缩约 4 MB（mipmap 会增加）；大量实例请降低分辨率。可用 v0.1.3 单图集模式控制总贴图尺寸；每实例仍有独立材质，不能等同于自动合批/减少 DrawCall。

## 测试与交付边界

`Docs/TEST_REPORT.md` 记录实际测试内容；`Tests/` 提供测试脚本与对照渲染。测试使用隔离项目，不改动你已打开的 Unity 项目，也没有对你当前 Blender 文件进行安装/覆盖。

这是第一版工具，建议先在场景副本与少量 Prefab 上试用。正式项目的自定义 Shader、海量场景和特殊 Prefab 数据需要额外适配和验证。

同步根节点所在场景未加载、或根节点本身被删除时，接收端保留上次快照，并提示重新加载/选择根节点；不会把“场景暂时未加载”当作删光所有物体。根节点内部子物体的删除仍会正常同步。

## v0.1.1：内置 Plane / 缺失 UV2 修复

`Missing UV2` 表示同步范围中至少一个网格没有第二套 UV，不是 Blender 版本问题。

- 新版窗口的 **UV2 Check / 第二套 UV** 列出缺失 UV2 的物体，点击 **定位** 选中对应场景物体。
- Unity 内置 Plane 没有 ModelImporter，因此不能按 FBX 的方式勾选 Generate Lightmap UVs。
- 点击 **Generate Missing UV2 (Copies) / 生成缺失 UV2 副本**：只处理当前同步范围内缺失 UV2 的静态网格。
- 新 Mesh 资产保存到 `Assets/LiveBakeGenerated/UV2Meshes/`；场景实例的 MeshFilter 指向副本。原 FBX/内置网格/Prefab 资产不变；已有 UV2 的物体不处理。
- 同源网格的多个实例共用一个 UV2 网格副本，但烘焙仍然每实例独立。
- 原 UV0、法线、切线、颜色、其他 UV 流、子网格保留；Unity 展 UV 可能为接缝拆分顶点，位置和渲染三角形保持。
- MeshCollider 不更换，因为几何表面不变。
- `LiveBakeUV2Binding` 在实例上保留原 Mesh 引用，支持 Undo。点击 **Restore Selected Original Meshes** 可恢复所选物体（含子物体）；已经应用烘焙材质时先 Restore Original Materials。
- 修复不自动保存场景、不自动提交烘焙。修复并同步后，在窗口再点击 Bake。
- 按钮只解决「缺失」，不擅自重排已经存在但重叠的 UV2。已有 UV2 的重叠仍会由 Blender 阻止。
- 原模型重新导入后，修复副本不会自动跟随原模型几何改变；需要先恢复原网格，再重新生成副本。

## v0.1.2：Unity 面板烘焙进度

窗口顶部新增 **烘焙进度 / Bake Progress**，与普通实时同步提示独立：

- 排队 / 等待 Blender 接收。
- Blender 烘焙：已完成物体数 / 总数、百分比、当前物体名称和运行耗时。
- 烘焙完成、等待导入（包括关闭 Auto-apply 的情况）。
- 正在导入并绑定：单独显示导入阶段状态。
- 完成、已应用到 Unity，耗时停止计时。
- 失败 / 取消；导入失败保留具体原因和烘焙文件，可手动 Apply Latest Result 重试。

百分比是 **已完成物体数量占比**，不是采样进度、预计剩余时间或按模型复杂度加权。一个复杂物体烘焙期间会停留在当前百分比，耗时仍更新。Blender 阻塞 bake 时没有新 heartbeat，面板说明距上次状态更新多久，但不会据此伪造失败。

Unity AssetDatabase 导入是同步操作；已在执行前安排一次面板刷新，阶段数据按真实进度更新，但耗时很长的同步资源导入期间界面仍可能暂时无法刷新。不是逐采样实时进度。

兼容旧 Blender 插件，无需重装 Blender。旧任务缺提交时间时，以本地请求文件时间作耗时起点。面板根据批次 ID 匹配，不让上一个批次的完成结果覆盖新任务进度。导入失败/中断不自动反复重试。

## v0.1.3：可选单图集 + 每实例 UV2 Tiling / Offset

在 Unity 面板 Bake 区域勾选 **合并烘焙图集 / Bake All to One Atlas**。

- **默认不勾选**：继续原流程，每个实例单独一张图，分辨率是每实例分辨率。
- **勾选**：所有同步范围内实际参与烘焙的 MeshRenderer 写入 **同一个 Blender Image**，整个批次完成后只保存一张 `atlas.png` / `atlas.exr`，Unity 只导入一个 `Atlas.png` / `Atlas.exr` 贴图资产。
- **Atlas resolution / 整图尺寸** 是整张图分辨率，默认 2048，支持 512/1024/2048/4096。独立模式的分辨率单独保留。
- 使用确定性的均匀网格分区，不旋转、不重新展开原 UV2。每实例单元内按原 UV2 加 padding 和半像素对齐。
- Unity 用 `uv2 * _BakeTex_ST.xy + _BakeTex_ST.zw` 采样。结果 JSON 每个 item 的 `scaleOffset=[tileX,tileY,offsetX,offsetY]`。
- Tiling/Offset 存在各实例烘焙材质的 `_BakeTex` 属性中，`LiveBakeBinding.bakeScaleOffset` 同时记录；**多个材质共用同一个贴图资产**。这版不是所有物体共用一个材质，也不承诺自动合批或减少 DrawCall。
- 原模型 Mesh/UV2 与源材质不修改；只在 Blender 临时工作网格上缩放 UV2，结束即恢复。相同 Prefab 的两个实例拥有不同图集单元与光照。
- 同时支持多材质子网格、PNG（显示变换）与 EXR（线性 HDR）。
- 每个单元外沿留出大于 bake margin 的安全间隔；Unity 图集纹理默认 **Clamp + Bilinear + 无 mipmap + 不压缩**，避免全局 mipmap 在远处把不同单元混色。代价是远处可能更容易闪烁/锯齿；后续如需 mipmap，必须做 tile-aware mip 生成而非直接打开。
- 单元扣掉边距后不足 16px，会拒绝提交/烘焙，请加大整图或减少同步实例/边距。
- 物体越多，单实例分辨率越低；网格是均匀分配，不按实际面积自动分配 texel density。未用完的格子为黑底。
- 批次中途失败/取消不发布部分图集；所有物体均成功后才保存并回传。已完成格子不会在下一物体烘焙时被清空。
- 开关切换后需重新烘焙。把图集结果切回独立图时，材质的 ST 自动恢复 `(1,1,0,0)`，不会沿用上次图集偏移。

### 升级注意

此功能需要 **Unity 和 Blender 两端都是 0.1.3**。旧 Blender 插件仍支持未勾选的独立图流程；勾选时 Unity 检查 Blender heartbeat 的 `supportsAtlas`，旧接收器会被明确拦住，不会静默忽略你的开关。

在已经运行的 Blender 中仅替换磁盘插件文件不代表已加载新代码。保存当前 .blend，退出并重新打开 Blender，然后在面板标题确认 **Unity Live Bake 0.1.3**，再点 Start Live Receiver。Unity Assets → Refresh 后重开工具窗口。升级不修改场景、不自动提交新烘焙。

## v0.1.4：可选 _MainTex → Blender Base Color

Unity 窗口同步设置中新增 **强制 _MainTex → Base Color / Use _MainTex Base Color**，默认关闭。

- 不勾选：原有 Standard / URP Lit 同步不变（URP 用 _BaseMap，Standard 用 _MainTex，乘原材质颜色）。
- 勾选：对同步范围内每个 MeshRenderer 的每个材质槽，直接取 `Material.GetTexture("_MainTex")` 的 Texture2D，连到 Blender Principled 的 Base Color。不经 _Color/_BaseColor 乘色，目的是使用原图颜色。
- 使用该 _MainTex 的 Tiling / Offset、Repeat/Clamp、Point/Linear 和 UV0。UV2 与图集 Tiling/Offset 不受影响。
- 标准材质其他已支持的 PBR 参数继续同步，保持其原映射。若 Smoothness 来源是原 Albedo alpha，保留原 _BaseMap/_MainTex alpha 来源，不误改成覆盖贴图 alpha。
- 标准材质没有 _MainTex 或明确为 null：保留正常同步并提示。不擅自替换为空白。Shader 默认白图若实际返回 Texture，则视为有效贴图。
- 自定义不透明 Shader 若有 _MainTex：允许简化导出为基础色贴图（Metallic=0、Roughness=0.5、无自发光），明确提示其他 Shader 效果/颜色/顶点变形不被复制。透明/Cutout、非 Texture2D、MaterialPropertyBlock 等限制仍保留。
- 若该自定义 Shader 没有有效 _MainTex，不伪造还原，仍报原来的 unsupported shader。关闭开关也恢复原来的支持限制。
- URP Inspector/导入器有时会把兼容用的隐藏 _MainTex 自动同步成 _BaseMap；工具读取的是 Unity 当时实际返回的 _MainTex，不修改它。如果两者本来一致，贴图不会变，但乘色连接方式会变。
- 已经应用烘焙材质的实例仍读取保存的原材质，不会把烘焙图再反馈烘焙。
- 开关改变会产生新的材质/场景哈希，避免旧缓存；Live sync 开启时自动同步，否则点击 Sync Now。已有烘焙不自动替换，需重新烘焙。
- 需 Blender 插件 0.1.4；保存 .blend 后退出并重开，确认标题 **Unity Live Bake 0.1.4**，Start Live Receiver。旧接收器不支持时有明确提示。

## v0.1.5：所有声明 _MainTex 贴图属性的 Shader 自动兼容

**本节覆盖 v0.1.4 及以前关于“自定义 Shader 必须勾 Toggle / 透明直接拒绝”的限制。** Blender 接收协议不变，继续使用已安装的 Blender 0.1.4，不用重装。

- 不再按 Shader 名称只允许 Lit。非标准 Shader 只要声明了精确名称 `_MainTex` 的 Texture 属性，就自动进入基础色兼容模式，与强制 _MainTex Toggle 是否开启无关。
- 是 Shader 的 Properties 属性，不是 Shader 名字/注释里出现 `_MainTex`；同名 Float/Vector 不能当作贴图读取。
- Texture2D RGB 直接作为 Blender Principled Base Color，保留 _MainTex Tiling/Offset。默认 Metallic=0，Roughness=0.5，不复制其他自定义着色效果。
- 透明/裁剪材质允许继续同步，但会明确警告：按不透明 RGB 显示和投影，Alpha、透明排序、裁剪轮廓不还原。树叶/玻璃等可能产生实体块和错误阴影，不能视为准确转换。
- _MainTex 未赋贴图时用白色并提示，不因空贴图中断。
- 自定义材质的镜像/混合轴 wrapping 用 Repeat 近似并提示。
- 原来已支持的 Standard/URP Lit 正常路径不变；遇到透明、Specular、Detail/Parallax 这类原不支持模式，如果具有 _MainTex，也会退回基础色兼容而非按 Shader 限制中断。
- 强制 _MainTex Toggle 仍控制标准 Lit 的基础色来源。原网格、材质、Prefab 资产不修改。
- 不具有 _MainTex 且不属于已支持标准材质的 Shader 会给出准确的属性缺失提示。Cubemap、Texture2DArray、RenderTexture 等不是静态 Texture2D，仍需转换；MaterialPropertyBlock、无 UV0、无 UV2 等独立限制没有被取消。

更新 Unity 后执行 Assets → Refresh，等待编译，重开工具窗口并点击 Sync Now / Refresh Assets。此次升级不启动烘焙、不改用户场景。

## v0.1.6：自定义 Shader 的 _BaseMap 支持

针对 PaiPai/Lit 仅声明 `_BaseMap` 的情况，自动基础色兼容现在接受 `_BaseMap` / `_MainTex` 任一 Texture 属性，不再要求只有 `_MainTex`。

自定义材质选择顺序：
1. 勾选强制 _MainTex 且 _MainTex 实际有贴图：使用 _MainTex。
2. 否则优先有贴图的 _BaseMap，再尝试有贴图的 _MainTex。
3. 两个都空时保留已声明的入口并按白色回退提示；两个都未声明时报告明确错误。

随被选入口同步 Tiling / Offset；Standard / URP Lit 已支持路径保持原逻辑。NoScaleOffset 属性可以读取默认 ST，无需修改原 Shader。基础色兼容不等于完整转换 PaiPai/Lit 的 _NormalMap 混合通道、MatCap、染色、顶点色或自定义光照。

Unity 端更新即可，Blender 0.1.4 接收器不变。当前针对项目 `F:\UnityProject\pp_ta_unity\UnityProject` 的内嵌包安装；目录名即使保留 @0.1.4，包内部版本为 0.1.6。不改 Shader/Material/Prefab/Scene，也不自动提交烘焙。

## v0.1.7：无效 UV2 副本修复与退化检查绕过

### 推荐：修复副本，不绕过

在 Unity 面板 **UV2 Check** 点击 **Scan Invalid UV2 / 扫描无效 UV2（含重叠）**。

- 列出缺失、非有限、越界、退化（三角形面积 < 1e-12）和重叠（三角形交集面积 > 1e-10）。重叠报告计数为被判定需移出保留集合的冲突面数，不是所有重叠配对数。
- 每个条目有“定位”和“修复此物体副本”；“修复全部无效 UV2 副本”作用于当前同步范围内所有无效实例，有确认提示。
- 先在可读副本上调用 Unity 展 UV2，再严格复查，不能只相信 unwrap 返回 true。
- 对仍退化/重叠的结果，优先保留源网格原先有效的 UV 图块：有效图块水平压至 86% 宽度，问题面拆分 UV 角点，单独排到右侧 10% 宽度区域并留间隔，必要时有限次追加处理因浮点舍入产生的冲突面。
- 保留几何三角形、位置、UV0、法线、切线、颜色、其他 UV 流与子网格归属；UV 接缝所需的顶点拆分可能增加顶点数量。
- 这不是美术精修展开，也不保证统一 texel density。新细小图块在低分辨率下可能不足像素，建议正常分辨率下检查烘焙效果。
- 全部准备的副本通过严格验证才赋给实例。若某个副本仍不合格，本次批量不替换场景引用；可单独处理其他对象。
- 副本保存到 Assets/LiveBakeGenerated/UV2Meshes；原 FBX/Prefab/已有有效 UV2 不覆盖，Collider 不改变；支持 Undo 和原网格恢复。不自动保存场景。
- 已应用烘焙材质的对象需先 Restore Original Materials，防止变更 UV 后旧贴图映射错位。

### 临时绕过：Skip Degenerate UV2

Bake 区域新增 **Skip Degenerate UV2 / 跳过退化 UV2 检查（有瑕疵风险）**，默认关闭。

- 开启后只跳过 UV2 面积为零/近零的错误，不改 UV、不删除三角形、不放宽缺失/非有限/越界/正面积重叠检查。
- 全部 UV 三角形退化仍拒绝（没有任何有效烘焙区域）。
- 跳过的面没有可靠 UV 面积，可能不写入有效像素、出现拉伸或采到其它面的颜色；完成不表示无瑕疵。
- PNG、EXR、单图集和独立图模式共用此选项。按实例累计跳过数量和样本面号写到 result.json / latest.json；Unity 进度面板在完成后仍显示警告。
- 旧 Blender 不支持该字段时 Unity 拒绝提交，避免请求被静默忽略。需 Blender 0.1.7，保存当前 .blend 后重启并 Start Live Receiver。
- 当前实际问题数据中，蓝房子.001 同时存在退化与重叠；只跳过退化仍会被重叠检查阻止，应修复副本。

### 升级

Unity 和 Blender 插件均需升级 0.1.7。Unity Assets → Refresh；Blender 保存 .blend 后退出重开，确认面板标题 **Unity Live Bake 0.1.7**。本次部署不会自动修复用户场景或自动开启绕过，需你点击对应按钮。

## v0.1.8：替换为“跳过全部 UV2 质量检查”

原“跳过退化 UV2 检查”面板开关替换为 **Skip UV2 Checks / 跳过全部 UV2 质量检查（高风险）**。

- 新开关默认关闭。旧版本保留的 skipDegenerateUV2=true 不自动迁移为更宽的权限，请升级后自行勾选。
- 开启时不执行 UV2 退化、重叠、0..1 范围检查；全退化坐标也不再被质量校验拦住。
- 唯一保留的是 Blender 执行所需的数据前提：UV2 存在、数组长度/索引合法、坐标有限（不能 NaN/Infinity）。无效基础数据仍报错，不偷换 UV0。
- 完全不改写 UV、不删除几何，也不自动展开。Blender 自己仍可能报烘焙执行错误；允许提交不等于保证成功或质量。
- 重叠表面会竞争同一像素；越界坐标可能缺失/采错，图集模式可能覆盖相邻实例的图块。图集 Tiling/Offset 不能修复原 UV2 越界。
- 结果写 skippedUV2Validation=true 及逐实例风险警告。此模式不计算无效面数量，不能把旧计数为零解读为“没有缺陷”。完成后 Unity 面板保留警告。
- 不勾选时恢复严格检查；手动扫描和副本修复仍严格校验，不受该选项影响。
- 请求用新字段 skipUV2Validation；旧窄范围请求保持原语义。Unity 检查 supportsSkipUV2Validation 和结果模式，不允许旧接收器静默误处理。
- 需两端 0.1.8。Unity 刷新编译；Blender 先保存 .blend，退出重开，确认标题 Unity Live Bake 0.1.8 并 Start Live Receiver。

## Blender 接收器 0.1.9：多 UV 接缝保护

在 Blender 的 **N → Unity Bake → 多 UV 接缝保护** 勾选（默认开启；随 .blend 保存）。在下一次 Unity 发起的 Combined 烘焙生效，单实例独立贴图和单图集均可使用。不改 Unity 0.1.8 客户端或请求协议。

- 开：多 UV 临时网格保留 UV0 为渲染采样层，激活 UV2 写入而不传显式 uv_layer override；每个对象烘焙期间关闭 Cycles 降噪，并使用 ADJACENT_FACES（相邻面）扩边。扩边像素数仍用 Unity 请求值。
- 关：原 0.1.8 UV2 显式烘焙路径，跟随场景降噪/扩边算法。选项在批次开始时锁定；不改变原 Mesh、UV 或长期场景设置。
- 这不是 UV 修复；重叠/越界、图块间距不足、硬法线等问题仍可能造成接缝。不降噪时暗部噪点可通过增加 Unity 面板采样改善。
- 单独升级 Blender 端时使用 `dist/unity_live_bake-0.1.9.zip`。保存 .blend、重启 Blender 后点 Start Live Receiver。


## Unity 端 0.2.0：按场景/物体整理，原位覆盖

在配置的 Unity 输出根目录内，普通贴图和材质使用 `<场景名>/<物体名>/<物体名>_Tex_001.png`、`<物体名>_Mat_001.mat`。同名物体共用目录，按 Renderer 的持久 ID 认领编号；重烘写回相同路径并保留 .meta GUID。不同格式使用不同扩展名，不删除旧格式。删除的实例可让位于同名替代物；不抢占仍存在但未选中的实例及非工具生成资产。改名/移动场景后进入相应新目录，不删除旧文件。清理非法文件名字符后相同的名称也按编号区分。

合并图集在 `<场景名>/_SharedAtlases/Atlas_Tex_001.png` 只存一份，材质仍在各物体目录；多个场景共用图集时选排序最前的场景作存放位置。同一组实例重烘覆盖原图集，实例集合不同则分配另一个图集槽，以免影响未参与本次烘焙的材质。

不会迁移或删除历史批次资产。还原原材质不等同于还原上次的贴图内容。交换目录中的任务 ID 与临时烘焙文件仍用于收发和验证，不是 Unity 最终资源目录。实测验证使用隔离 Unity 2022.3.62f3；未在用户场景运行烘焙。
## Unity 0.2.3 / Blender 0.1.13：自动跟随 Blender 输出

Unity → Bake → **跟随 Blender 输出设置（格式、色彩管理、位深）** 默认勾选。使用 Blender 当前场景 Output Properties → Output → File Format、Color、Color Depth 和 Color Management。支持 PNG / 单层 OpenEXR；不支持的格式会提示，不会静默改成 PNG。关闭可回到旧的 Unity 格式选项。

- PNG：按 Blender 原生 Save As Render 写出，支持 Follow Scene、Override；View Transform、Look、Exposure、Gamma 和位深不再由插件重设。要在普通 Unity Unlit 中显示 Blender 的最终观感，通常选 sRGB 显示设备 + PNG，并避免 Unity 再次 Tonemapping。16 位提高精度，不等于增加亮度。
- EXR：用 Blender 原生线性文件输出流程，遵循 16/32-bit、压缩和线性输出空间。不是将显示色调“再叠”到 HDR 数据上。非 sRGB 显示设备或非 Rec.709 线性输出需自行匹配 Unity 色域，当前插件并非通用 OCIO 显示器。
- Unity 默认导入设置：PNG16 使用 RGBA64，在 Linear 项目由桥接 Shader 做一次 sRGB 解码；PNG8 使用常规 sRGB 导入；EXR16/32 使用 Half/Float。目标平台格式覆盖、硬件支持、mipmap/filter 和项目后期仍可能导致差异。RGBA 文件的 alpha 可保留为纹理数据，但烘焙材质本身仍不透明。
- 颜色管理不包含 compositor、相机后期、辉光、显示器校准等屏幕效果。烘焙过程中请勿修改输出/颜色设置，用户场景不自动保存。

实测 Blender 5.0.1：PNG 8/16、RGB/RGBA、Follow Scene/Override 和 EXR 16/32；与 Blender 原生保存同一线性图像像素比对。Unity 2022.3.62f3 Linear 独立测试项目：四种精度输出导入实际材质、GPU 渲染像素核对通过。正式项目未自动提交烘焙或改动场景。
