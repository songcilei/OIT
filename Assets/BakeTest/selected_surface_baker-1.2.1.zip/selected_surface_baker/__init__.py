bl_info = {
    'name': 'Selected Surface Baker', 'author': 'Selected Surface Baker',
    'version': (1, 2, 1), 'blender': (5, 0, 0),
    'location': '3D View > N Sidebar > Surface Bake',
    'description': 'Bake Combined appearance or received shadows for selected meshes, with safe preview/restore',
    'category': 'Material',
}
import bpy
from bpy.props import StringProperty, BoolProperty, EnumProperty, IntProperty, PointerProperty, CollectionProperty
from bpy.app.handlers import persistent
from . import core


class SSBSlot(bpy.types.PropertyGroup):
    material: PointerProperty(type=bpy.types.Material)
    link: StringProperty(default='DATA')


class SSBObjectState(bpy.types.PropertyGroup):
    original_mesh: PointerProperty(type=bpy.types.Mesh)
    original_slots: CollectionProperty(type=SSBSlot)
    preview_applied: BoolProperty(default=False)
    preview_kind: StringProperty(default='COMBINED')
    combined_mesh: PointerProperty(type=bpy.types.Mesh)
    combined_material: PointerProperty(type=bpy.types.Material)
    combined_image: PointerProperty(type=bpy.types.Image)
    combined_path: StringProperty(subtype='FILE_PATH')
    shadow_mesh: PointerProperty(type=bpy.types.Mesh)
    shadow_material: PointerProperty(type=bpy.types.Material)
    shadow_image: PointerProperty(type=bpy.types.Image)
    shadow_path: StringProperty(subtype='FILE_PATH')


# Keep the 1.0 Combined/Shadow pointers so saved previews remain restorable.
for _channel, _, _ in core.CHANNELS[1:]:
    _prefix = _channel.lower() + '_'
    for _key, _type in [('mesh', bpy.types.Mesh), ('material', bpy.types.Material), ('image', bpy.types.Image)]:
        SSBObjectState.__annotations__[_prefix+_key] = PointerProperty(type=_type)
    SSBObjectState.__annotations__[_prefix+'path'] = StringProperty(subtype='FILE_PATH')

class SSBSettings(bpy.types.PropertyGroup):
    uv_seam_guard: BoolProperty(name='多 UV 接缝保护', default=True,
        description='Combined 烘焙多 UV 网格时使用相邻面扩边并临时关闭降噪。可能增加噪点；不改 UV 岛或场景降噪设置')
    combined_keep_environment: BoolProperty(name='保留非选中物体的预览材质', default=True,
        description='Combined 按当前场景烘焙，保留其他物体预览材质的间接补光。取消则使用原始场景材质（旧行为）。所选物体始终使用原始材质')
    channel: EnumProperty(name='烘焙通道', items=core.CHANNELS, default='COMBINED')
    output_dir: StringProperty(name='输出目录 / Output', subtype='DIR_PATH', default='//SurfaceBakes/')
    resolution: EnumProperty(name='贴图分辨率', items=[(str(n), '%d × %d' % (n,n), '') for n in (256,512,1024,2048,4096)], default='1024')
    samples: IntProperty(name='Cycles 采样', default=64, min=1, max=1024)
    margin: IntProperty(name='扩边像素', default=8, min=0, max=64)
    uv_mode: EnumProperty(name='烘焙 UV', items=[('ACTIVE','当前激活 UV','使用当前激活的 UV 层'),('SECOND','第二套 UV','使用列表中的第二层，不依赖名称')], default='ACTIVE')
    generate_missing_uv: BoolProperty(name='缺少目标 UV 时在副本上生成', default=True)
    follow_blender_output: BoolProperty(name='跟随 Blender 输出设置', default=True,
        description='PNG 或单层 OpenEXR：读取输出格式、颜色通道和位深。彩色图使用 Blender 原生色彩管理，数据贴图不套用显示变换')
    combined_format: EnumProperty(name='Combined 输出', items=[('PNG','PNG · 包含当前显示色调','另存线性 EXR 用于 Blender 正确预览'),('EXR','EXR · 线性 HDR','不将 AgX/曝光固化到文件')], default='PNG')
    invert_shadow: BoolProperty(name='阴影反相（白色表示阴影）', default=False)
    auto_preview: BoolProperty(name='完成后自动预览', default=False)
    busy: BoolProperty(default=False, options={'SKIP_SAVE'})
    message: StringProperty(default='选择接收表面的 Mesh，例如地面。')
    last_dir: StringProperty(subtype='DIR_PATH')
    last_kind: StringProperty(default='COMBINED')


class SSB_OT_bake(bpy.types.Operator):
    bl_idname = 'ssb.bake'
    bl_label = 'Bake Selected Surface'
    bl_options = {'REGISTER'}
    kind: EnumProperty(items=core.ALL_CHANNELS, default='COMBINED')

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and not context.scene.ssb_settings.busy and any(o.type == 'MESH' for o in context.selected_objects)

    def execute(self, context):
        try:
            results = core.run_batch(context, self.kind)
            core.rendered_view(context)
            self.report({'INFO'}, '烘焙完成：%d 个物体，%s' % (len(results), context.scene.ssb_settings.last_dir))
            return {'FINISHED'}
        except Exception as exc:
            context.scene.ssb_settings.message = '失败：'+str(exc)
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}


class SSB_OT_preview(bpy.types.Operator):
    bl_idname = 'ssb.preview'
    bl_label = 'Preview Baked Material'
    bl_options = {'REGISTER', 'UNDO'}
    kind: EnumProperty(items=core.ALL_CHANNELS, default='COMBINED')

    def execute(self, context):
        if context.scene.ssb_settings.busy or context.mode != 'OBJECT':
            return {'CANCELLED'}
        count = sum(core.apply_preview(o,self.kind) for o in context.selected_objects if o.type == 'MESH')
        if not count:
            self.report({'WARNING'}, '所选物体没有对应烘焙结果，请先烘焙。')
            return {'CANCELLED'}
        context.scene.ssb_settings.last_kind = self.kind
        # Do not change view transform/world/light settings. Use rendered/material mode to see result.
        core.rendered_view(context)
        self.report({'INFO'}, '已预览 %d 个物体；点击恢复原材质可还原。' % count)
        return {'FINISHED'}


class SSB_OT_restore(bpy.types.Operator):
    bl_idname = 'ssb.restore'
    bl_label = '恢复原材质 / Restore'
    bl_options = {'REGISTER', 'UNDO'}
    all_objects: BoolProperty(default=False)
    def execute(self, context):
        if context.scene.ssb_settings.busy:
            return {'CANCELLED'}
        objects = context.scene.objects if self.all_objects else context.selected_objects
        try:
            count = sum(core.restore_preview(o) for o in objects if o.type == 'MESH')
            self.report({'INFO'}, '恢复 %d 个物体；烘焙文件和新材质仍保留。' % count)
            self.report({'INFO'}, 'Shift+F5 返回 3D 视图；N 打开 Surface Bake 面板。')
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}


class SSB_OT_show_image(bpy.types.Operator):
    bl_idname = 'ssb.show_image'
    bl_label = '查看原始贴图 / Image'
    kind: EnumProperty(items=core.ALL_CHANNELS, default='COMBINED')
    def execute(self, context):
        ob = context.object
        if not ob or ob.type != 'MESH':
            return {'CANCELLED'}
        state = ob.ssb_state
        path = getattr(state,self.kind.lower()+'_path')
        if not path:
            self.report({'WARNING'}, '当前物体没有对应图片。')
            return {'CANCELLED'}
        try:
            image = bpy.data.images.load(path,check_existing=True)
            if self.kind in core.DATA_MAPS:
                image.colorspace_settings.name = 'Non-Color'
            # Explicit image-preview action changes only this editor, not scene state.
            area = context.area
            if area is None:
                raise ValueError('Image preview requires a visible editor area')
            area.type = 'IMAGE_EDITOR'
            area.spaces.active.image = image
            area.spaces.active.use_image_pin = True
            image.use_view_as_render = self.kind not in core.DATA_MAPS and path.lower().endswith('.exr')
            self.report({'INFO'}, 'Shift+F5 返回 3D 视图；N 打开 Surface Bake 面板。')
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}


class SSB_OT_export_fbx(bpy.types.Operator):
    bl_idname = 'ssb.export_fbx'
    bl_label = '导出选中模型 FBX'
    bl_description = '只导出选中的 Mesh，合为一个静态 FBX，写到上方输出目录，不覆盖已有文件'
    @classmethod
    def poll(cls, context):
        return context.mode=='OBJECT' and not context.scene.ssb_settings.busy and any(ob.type=='MESH' for ob in context.selected_objects)
    def execute(self, context):
        try:
            path=core.export_fbx(context)
            context.scene.ssb_settings.last_dir=str(path.parent)
            context.scene.ssb_settings.message='FBX: '+path.name
            self.report({'INFO'},str(path))
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'},str(exc))
            return {'CANCELLED'}

class SSB_OT_open_folder(bpy.types.Operator):
    bl_idname = 'ssb.open_folder'
    bl_label = '打开输出目录'
    def execute(self, context):
        path = context.scene.ssb_settings.last_dir or str(core.output_directory(context.scene.ssb_settings.output_dir))
        bpy.ops.wm.path_open(filepath=path)
        return {'FINISHED'}


class SSB_PT_panel(bpy.types.Panel):
    bl_label = 'Selected Surface Baker 1.2.1'
    bl_idname = 'SSB_PT_panel'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Surface Bake'
    def draw(self, context):
        layout = self.layout
        settings = context.scene.ssb_settings
        layout.enabled = not settings.busy
        layout.label(text='选择接收阴影的表面，不是投影物体')
        layout.prop(settings,'output_dir')
        layout.prop(settings,'resolution')
        row=layout.row(align=True);row.prop(settings,'samples');row.prop(settings,'margin')
        layout.prop(settings,'uv_mode')
        layout.prop(settings,'generate_missing_uv')
        layout.prop(settings,'follow_blender_output')
        if settings.follow_blender_output:
            cfg=context.scene.render.image_settings
            layout.label(text=f'输出：{cfg.file_format} / {cfg.color_mode} / {cfg.color_depth} bit')
        elif settings.channel not in core.DATA_MAPS:
            layout.prop(settings,'combined_format',text='彩色通道输出')
        layout.prop(settings,'invert_shadow')
        layout.prop(settings,'auto_preview')
        box=layout.box();box.prop(settings,'channel')
        if settings.channel == 'COMBINED':
            box.prop(settings,'combined_keep_environment')
            box.prop(settings,'uv_seam_guard')
        box.operator('ssb.bake',text='① 烘焙所选通道',icon='RENDER_STILL').kind=settings.channel
        row=box.row(align=True);row.operator('ssb.preview',text='预览所选通道',icon='MATERIAL').kind=settings.channel;row.operator('ssb.show_image',text='看贴图',icon='IMAGE_DATA').kind=settings.channel
        box=layout.box();box.label(text='2 · 接收表面的投影遮罩')
        box.operator('ssb.bake',text='② 创建材质并烘焙投影',icon='LIGHT_SUN').kind='SHADOW'
        row=box.row(align=True);row.operator('ssb.preview',text='预览黑白投影',icon='MATERIAL').kind='SHADOW';row.operator('ssb.show_image',text='看贴图',icon='IMAGE_DATA').kind='SHADOW'
        layout.operator('ssb.restore',icon='LOOP_BACK')
        layout.operator('ssb.export_fbx',icon='EXPORT')
        layout.operator('ssb.open_folder',icon='FILE_FOLDER')
        layout.separator()
        layout.label(text=settings.message[:90])
        layout.label(text='默认黑=阴影 / 白=无遮挡；支持反相。')
        layout.label(text='预览使用 Emission，避免二次受光。')
        layout.label(text='UV须无重叠；不会自动修复已有坏UV。')
        layout.label(text='逐物体同步烘焙，期间界面可能暂停。')


@persistent
def reset_busy(_):
    for scene in bpy.data.scenes:
        if hasattr(scene,'ssb_settings'):
            scene.ssb_settings.busy=False


CLASSES=(SSBSlot,SSBObjectState,SSBSettings,SSB_OT_bake,SSB_OT_preview,SSB_OT_restore,SSB_OT_show_image,SSB_OT_export_fbx,SSB_OT_open_folder,SSB_PT_panel)

def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Object.ssb_state=PointerProperty(type=SSBObjectState)
    bpy.types.Scene.ssb_settings=PointerProperty(type=SSBSettings)
    bpy.app.handlers.load_post.append(reset_busy)

def unregister():
    # Restore tool previews before removing their backup properties.
    for ob in bpy.data.objects:
        if ob.type=='MESH' and hasattr(ob,'ssb_state') and ob.ssb_state.preview_applied:
            core.restore_preview(ob)
    if reset_busy in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(reset_busy)
    del bpy.types.Scene.ssb_settings
    del bpy.types.Object.ssb_state
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)


