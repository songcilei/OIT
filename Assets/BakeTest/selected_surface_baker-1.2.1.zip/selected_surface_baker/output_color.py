"""SSB bake output: display-referred color files, scene-linear material previews, raw data maps."""
from contextlib import contextmanager
import bpy
import numpy as np

DATA_CHANNELS = frozenset(('AO','NORMAL','ROUGHNESS','SHADOW'))


def working_space():
    return bpy.data.colorspace.working_space


def profile(scene, settings, kind):
    cfg = scene.render.image_settings
    follow = settings.follow_blender_output
    data = kind in DATA_CHANNELS
    if follow and cfg.file_format not in ('PNG','OPEN_EXR'):
        raise ValueError('当前 Blender 输出是 %s；请选择 PNG 或单层 OpenEXR，或关闭「跟随 Blender 输出设置」。' % cfg.file_format)
    fmt = cfg.file_format if follow else ('PNG' if data or settings.combined_format == 'PNG' else 'OPEN_EXR')
    mode = cfg.color_mode if follow else 'RGB'
    if kind == 'NORMAL' and mode == 'BW':
        raise ValueError('法线需要三个颜色通道，请将输出 Color 从 BW 改为 RGB 或 RGBA。')
    view = cfg.view_settings if cfg.color_management == 'OVERRIDE' else scene.view_settings
    display = cfg.display_settings if cfg.color_management == 'OVERRIDE' else scene.display_settings
    return dict(followBlender=follow, fileFormat=fmt, colorMode=mode,
                colorDepth=int(cfg.color_depth) if follow else (32 if fmt=='OPEN_EXR' else 8),
                colorManagement='Non-Color' if data else cfg.color_management,
                viewTransform=view.view_transform, display=display.display_device, look=view.look,
                exposure=view.exposure, gamma=view.gamma,
                workingSpace=working_space(),
                displayTransformBaked=not data and fmt=='PNG')


@contextmanager
def scratch_scene():
    temp = bpy.data.scenes.new('SSB temporary image writer')
    try:
        yield temp
    finally:
        bpy.data.scenes.remove(temp)


def raw_save(image,path,fmt,mode,depth,src,*,lossless=False):
    # Separate writer so normal/roughness/visibility and the shading preview never
    # inherit filmic looks, display exposure, override gamut or dithering.
    with scratch_scene() as temp:
        cfg=temp.render.image_settings
        cfg.file_format, cfg.color_mode, cfg.color_depth = fmt, mode, str(depth)
        temp.view_settings.view_transform='Raw'
        temp.view_settings.look='None'
        temp.view_settings.exposure=0; temp.view_settings.gamma=1
        temp.render.dither_intensity=0
        if fmt=='PNG': cfg.compression=src.compression
        else:
            cfg.exr_codec='ZIP' if lossless else src.exr_codec
            cfg.color_management='OVERRIDE'
            cfg.linear_colorspace_settings.name=working_space()
        image.save_render(str(path), scene=temp)


def write(image,folder,stem,kind,scene,settings):
    prof=profile(scene,settings,kind)
    cfg=scene.render.image_settings; fmt=prof['fileFormat']; data=kind in DATA_CHANNELS
    path=folder/(stem+('.exr' if fmt=='OPEN_EXR' else '.png'))
    if kind=='SHADOW':
        values=np.empty(len(image.pixels),dtype=np.float32); image.pixels.foreach_get(values);rgba=values.reshape(-1,4)
        gray=np.clip(rgba[:,0]*.2126+rgba[:,1]*.7152+rgba[:,2]*.0722,0,1)
        rgba[:,:3]=(1-gray if settings.invert_shadow else gray)[:,None];rgba[:,3]=1
        image.pixels.foreach_set(values);image.update()
    if data:
        raw_save(image,path,fmt,prof['colorMode'],prof['colorDepth'],cfg)
        preview_path=path
    else:
        if prof['followBlender']:
            # Use the user's actual output scene, unmodified, for Follow Scene AND Override.
            image.save_render(str(path), scene=scene)
        elif fmt=='PNG':
            temp=scene.copy()
            try:
                c=temp.render.image_settings
                c.file_format,c.color_mode,c.color_depth='PNG','RGB','8'
                image.save_render(str(path),scene=temp)
            finally:
                bpy.data.scenes.remove(temp)
        else:
            raw_save(image,path,fmt,'RGB',32,cfg)
        # EXR may use override primaries, monochrome, reduced precision, etc. A raw
        # master preserves the scene-linear bake for preview without applying the
        # file's output transform twice. Reuse a standard RGB(A) Rec.709 EXR when possible.
        space=cfg.linear_colorspace_settings.name if fmt=='OPEN_EXR' and prof['followBlender'] and cfg.color_management=='OVERRIDE' else None
        if fmt=='OPEN_EXR' and prof['colorMode']!='BW' and working_space()=='Linear Rec.709' and space in (None,'','Linear Rec.709') and cfg.exr_codec not in {'DWAA','DWAB','B44','B44A','PXR24'}:
            preview_path=path
        else:
            preview_path=folder/(stem+'_linear_preview.exr')
            raw_save(image,preview_path,'OPEN_EXR','RGBA',32,cfg,lossless=True)
    preview=bpy.data.images.load(str(preview_path),check_existing=False)
    try:
        preview.colorspace_settings.name='Non-Color' if data else working_space()
        preview.pack();preview.use_fake_user=True
        return path,preview
    except Exception:
        bpy.data.images.remove(preview)
        raise
