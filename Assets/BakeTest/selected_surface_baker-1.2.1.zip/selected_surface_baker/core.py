"""Selected Surface Baker: safe local material/mesh snapshots and Cycles image bakes."""
import json
import re
import time
import uuid
from pathlib import Path
import bpy
import numpy as np
from . import output_color


CHANNELS = (
    ('COMBINED','Combined · 综合','材质、光照和阴影'),
    ('DIFFUSE','Diffuse Color · 漫反射颜色','Cycles Diffuse，仅颜色、不含直接或间接光'),
    ('AO','Ambient Occlusion · 环境遮蔽','非颜色灰度贴图'),
    ('NORMAL','Normal · 切线法线','切线空间 +X +Y +Z，非颜色 RGB'),
    ('ROUGHNESS','Roughness · 粗糙度','非颜色灰度贴图'),
    ('EMIT','Emission · 自发光','材质的自发光输出'),
)
ALL_CHANNELS = CHANNELS + (('SHADOW','Shadow · 投影遮罩','接收表面的投影'),)
DATA_MAPS = output_color.DATA_CHANNELS


def rendered_view(context):
    # Change only the invoking 3D view. If invoked from search/another editor,
    # use the current screen's 3D views; do not touch unrelated workspaces/windows.
    area=context.area
    areas=[area] if area and area.type=='VIEW_3D' else list(context.screen.areas) if context.screen else []
    for a in areas:
        if a.type=='VIEW_3D':
            a.spaces.active.shading.type='RENDERED'
            a.tag_redraw()


def export_fbx(context):
    meshes=[ob for ob in context.selected_objects if ob.type=='MESH']
    if not meshes or context.mode!='OBJECT':
        raise ValueError('请在物体模式选中要导出的 Mesh')
    folder=output_directory(context.scene.ssb_settings.output_dir)
    name=safe_name(meshes[0].name) if len(meshes)==1 else 'Selected_'+str(len(meshes))
    path=folder/(name+'_'+time.strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8]+'.fbx')
    result=bpy.ops.export_scene.fbx(filepath=str(path),check_existing=False,use_selection=True,
        object_types={'MESH'},bake_anim=False,use_custom_props=False,path_mode='AUTO')
    if 'FINISHED' not in result or not path.is_file() or not path.stat().st_size:
        raise RuntimeError('FBX 导出失败：'+str(path))
    return path


def safe_name(name):
    return re.sub(r'[^\w.-]+', '_', name, flags=re.UNICODE).strip('._')[:60] or 'Object'


def mesh_folder(root, name):
    # Keep valid Unicode, spaces and dots; never interpret a mesh name as a path.
    label = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', name).rstrip(' .') or 'Mesh'
    if re.fullmatch(r'(?:CON|PRN|AUX|NUL|CONIN\$|CONOUT\$|(?:COM|LPT)[1-9¹²³])', label.split('.')[0].rstrip(), re.I):
        label = '_' + label
    folder = root / label
    if folder.resolve().parent != root or folder.is_symlink():
        raise ValueError('不安全的 Mesh 输出目录：' + str(folder))
    folder.mkdir(exist_ok=True)
    return folder


def capture(ob):
    return (ob.data, [(slot.link, slot.material) for slot in ob.material_slots])


def set_source(ob, mesh, slots):
    ob.data = mesh
    for i, (link, material) in enumerate(slots):
        ob.material_slots[i].link = link
        if link == 'OBJECT':
            ob.material_slots[i].material = material
    ob.update_tag()


def restore_preview(ob):
    state = ob.ssb_state
    if not state.preview_applied:
        return False
    if state.original_mesh is None:
        raise ValueError(ob.name + ': original mesh backup missing; no destructive restore attempted')
    set_source(ob, state.original_mesh, [(x.link, x.material) for x in state.original_slots])
    state.preview_applied = False
    return True


def apply_preview(ob, kind):
    state = ob.ssb_state
    mesh = getattr(state, kind.lower() + '_mesh')
    material = getattr(state, kind.lower() + '_material')
    if not mesh or not material:
        return False
    if not state.preview_applied:
        state.original_mesh = ob.data
        state.original_slots.clear()
        for slot in ob.material_slots:
            saved = state.original_slots.add()
            saved.link, saved.material = slot.link, slot.material
    ob.data = mesh
    for slot in ob.material_slots:
        slot.link = 'OBJECT'
        slot.material = material
    state.preview_applied = True
    state.preview_kind = kind
    ob.update_tag()
    return True


def output_directory(value):
    if not value:
        raise ValueError('Choose an output directory')
    if value.startswith('//') and not bpy.data.filepath:
        raise ValueError('Save the .blend first, or choose an absolute output directory')
    folder = Path(bpy.path.abspath(value)).resolve()
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def preflight(context, objects, settings, kind):
    if context.mode != 'OBJECT':
        raise ValueError('Switch to Object Mode first')
    if not objects:
        raise ValueError('Select at least one mesh receiver (e.g. the ground)')
    if kind == 'SHADOW':
        lights = [o for o in context.scene.objects if o.type == 'LIGHT' and not o.hide_render and o.visible_get() and o.data.energy > 0 and getattr(o.data, 'use_shadow', True)]
        if not lights:
            raise ValueError('Shadow bake needs at least one visible, shadow-enabled light. World lighting alone is not supported by this tool')
    for ob in objects:
        if ob.library or ob.override_library or ob.data.library:
            raise ValueError(ob.name + ': make the linked/override object local before baking')
        if ob.hide_render or ob.hide_get() or not ob.visible_get():
            raise ValueError(ob.name + ': selected receiver is hidden or excluded')
        if any(m.show_render for m in ob.modifiers):
            raise ValueError(ob.name + ': apply/disable render modifiers on a duplicate first; this version preserves exact mesh/UV correspondence')
        mesh = ob.ssb_state.original_mesh if ob.ssb_state.preview_applied else ob.data
        if not mesh or not len(mesh.polygons):
            raise ValueError(ob.name + ': no mesh faces')
        if abs(ob.matrix_world.determinant()) < 1e-12:
            raise ValueError(ob.name + ': zero/degenerate object scale')
        if settings.uv_mode == 'SECOND' and len(mesh.uv_layers) < 2 and not settings.generate_missing_uv:
            raise ValueError(ob.name + ': second UV layer missing; enable Generate Missing UV')
        if settings.uv_mode == 'ACTIVE' and not mesh.uv_layers and not settings.generate_missing_uv:
            raise ValueError(ob.name + ': no UV map; enable Generate Missing UV')


def ensure_uv(context, ob, mesh, settings):
    if settings.uv_mode == 'SECOND' and len(mesh.uv_layers) >= 2:
        uv = mesh.uv_layers[1]
    elif settings.uv_mode == 'ACTIVE' and mesh.uv_layers:
        uv = mesh.uv_layers.active or mesh.uv_layers[0]
    else:
        # Work mesh is private; original asset is never unwrapped.
        if not mesh.uv_layers:
            mesh.uv_layers.new(name='UVMap')
        uv = mesh.uv_layers.new(name='SSB_BakeUV')
        mesh.uv_layers.active = uv
        for obj in list(context.selected_objects):
            obj.select_set(False)
        ob.select_set(True)
        context.view_layer.objects.active = ob
        bpy.ops.object.mode_set(mode='EDIT')
        try:
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.uv.smart_project(angle_limit=1.1519173, island_margin=.035)
        finally:
            bpy.ops.object.mode_set(mode='OBJECT')
        uv = mesh.uv_layers.active
    # Cheap preflight: overlap is not exhaustively tested; warn in UI/docs.
    mesh.calc_loop_triangles()
    for face in mesh.loop_triangles:
        coords = [uv.data[i].uv for i in face.loops]
        for co in coords:
            if not np.isfinite(co.x) or not np.isfinite(co.y) or co.x < -1e-6 or co.x > 1+1e-6 or co.y < -1e-6 or co.y > 1+1e-6:
                raise ValueError(ob.name + ': bake UV must contain finite coordinates inside 0..1')
        a, b, c = coords
        area = abs((float(b.x)-a.x)*(float(c.y)-a.y)-(float(b.y)-a.y)*(float(c.x)-a.x))*.5
        if area < 1e-12:
            raise ValueError(ob.name + ': degenerate UV triangle; repair UVs before baking')
    return uv.name


def matte_material():
    mat = bpy.data.materials.new('SSB temporary white receiver')
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    diffuse = nt.nodes.new('ShaderNodeBsdfDiffuse')
    diffuse.inputs['Color'].default_value = (1, 1, 1, 1)
    out = nt.nodes.new('ShaderNodeOutputMaterial')
    nt.links.new(diffuse.outputs[0], out.inputs['Surface'])
    return mat


def new_preview_material(name, image, uv_name):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    mat.use_fake_user = True
    nt = mat.node_tree
    nt.nodes.clear()
    uv = nt.nodes.new('ShaderNodeUVMap')
    uv.uv_map = uv_name
    uv.location = (-500, 0)
    tex = nt.nodes.new('ShaderNodeTexImage')
    tex.image = image
    tex.extension = 'EXTEND'
    tex.location = (-260, 0)
    emission = nt.nodes.new('ShaderNodeEmission')
    emission.inputs['Strength'].default_value = 1
    emission.location = (30, 0)
    out = nt.nodes.new('ShaderNodeOutputMaterial')
    out.location = (240, 0)
    nt.links.new(uv.outputs['UV'], tex.inputs['Vector'])
    nt.links.new(tex.outputs['Color'], emission.inputs['Color'])
    nt.links.new(emission.outputs[0], out.inputs['Surface'])
    nt.nodes.active = tex
    return mat


def save_image(image, folder, stem, kind, scene, settings):
    return output_color.write(image, folder, stem, kind, scene, settings)


def bake_one(context, ob, kind, settings, batch_folder):
    original_mesh, slots = capture(ob)
    work = original_mesh.copy()
    work.name = ob.name + ' SSB bake mesh'
    source_render_uv = next((uv.name for uv in original_mesh.uv_layers if uv.active_render), None)
    ob.data = work
    temporary = []
    image = None
    keep_mesh = False
    try:
        if not work.materials:
            work.materials.append(None)
        for i in range(len(work.materials)):
            src = slots[i][1] if i < len(slots) else None
            if kind == 'SHADOW' or src is None:
                mat = matte_material()
            else:
                mat = src.copy()
                if not mat.use_nodes:
                    mat.use_nodes = True
                    mat.node_tree.nodes.get('Principled BSDF').inputs['Base Color'].default_value = src.diffuse_color
            temporary.append(mat)
            work.materials[i] = mat
            ob.material_slots[i].link = 'DATA'
        uv_name = ensure_uv(context, ob, work, settings)
        # Blender 5.0.1: an explicit bake uv_layer is not equivalent to using
        # the active edit UV for adjacent-face margins on multi-UV meshes.
        # Set the destination only on the private copy, retaining the render UV
        # for existing source shaders with implicit image coordinates.
        work.uv_layers.active = work.uv_layers[uv_name]
        if source_render_uv:
            work.uv_layers[source_render_uv].active_render = True
        multi_combined = kind == 'COMBINED' and len(work.uv_layers)>1
        resolution = int(settings.resolution)
        image = bpy.data.images.new('SSB temporary bake', resolution, resolution, alpha=True, float_buffer=True)
        image.colorspace_settings.name = 'Non-Color' if kind in DATA_MAPS else output_color.working_space()
        for mat in temporary:
            for node in mat.node_tree.nodes:
                node.select = False
            node = mat.node_tree.nodes.new('ShaderNodeTexImage')
            node.name = 'SSB_BAKE_TARGET'
            node.image = image
            node.select = True
            mat.node_tree.nodes.active = node
        for selected in list(context.selected_objects):
            selected.select_set(False)
        ob.select_set(True)
        context.view_layer.objects.active = ob
        args = dict(type=kind, use_selected_to_active=False, use_clear=True, margin=settings.margin)
        if kind == 'COMBINED':
            args['pass_filter'] = {'COLOR', 'DIRECT', 'INDIRECT', 'DIFFUSE', 'GLOSSY', 'TRANSMISSION', 'EMIT'}
        elif kind == 'DIFFUSE':
            args['pass_filter'] = {'COLOR'}
        elif kind == 'NORMAL':
            args.update(normal_space='TANGENT', normal_r='POS_X', normal_g='POS_Y', normal_b='POS_Z')
        prev_denoise = context.scene.cycles.use_denoising
        try:
            if multi_combined and settings.uv_seam_guard:
                context.scene.cycles.use_denoising = False
                args['margin_type'] = 'ADJACENT_FACES'
            denoise_used = context.scene.cycles.use_denoising
            if 'FINISHED' not in bpy.ops.object.bake(**args):
                raise RuntimeError('Cycles bake did not finish: '+kind)
        finally:
            context.scene.cycles.use_denoising = prev_denoise
        stem = safe_name(ob.name)+'_'+kind.lower()+'_'+uuid.uuid4().hex[:8]
        path, preview = save_image(image, batch_folder, stem, kind, context.scene, settings)
        material = new_preview_material('SSB '+ob.name+' '+kind.title(), preview, uv_name)
        # Preserve source slots on private result mesh; per-object preview overrides them.
        work.materials.clear()
        if slots:
            for _, source in slots:
                work.materials.append(source)
        else:
            work.materials.append(None)
        work.use_fake_user = True
        keep_mesh = True
        return dict(object=ob, mesh=work, material=material, image=preview, file=str(path), uv=uv_name, source_render_uv=source_render_uv, denoise=denoise_used, margin_type=args.get("margin_type", context.scene.render.bake.margin_type))
    finally:
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        set_source(ob, original_mesh, slots)
        if not keep_mesh:
            bpy.data.meshes.remove(work)
        for mat in temporary:
            if mat.users == 0:
                bpy.data.materials.remove(mat)
        if image:
            bpy.data.images.remove(image)


def run_batch(context, kind):
    settings = context.scene.ssb_settings
    objects = sorted([o for o in context.selected_objects if o.type == 'MESH'], key=lambda o: o.name)
    output_profile = output_color.profile(context.scene, settings, kind)
    preflight(context, objects, settings, kind)
    root = output_directory(settings.output_dir)
    batch_id = uuid.uuid4().hex
    records_by_folder = {}
    scene = context.scene
    before_selected = list(context.selected_objects)
    before_active = context.view_layer.objects.active
    # Always restore every selected receiver's source before the first bake, so a
    # repeated or multi-object bake never uses any target's own baked preview.
    # For Combined, other objects are part of the visible lighting environment.
    preserve_environment = kind == 'COMBINED' and settings.combined_keep_environment
    targets = set(objects)
    prev_previews = [(o, o.ssb_state.preview_kind) for o in scene.objects
                     if o.type == 'MESH' and o.ssb_state.preview_applied
                     and (not preserve_environment or o in targets)]
    engine, samples = scene.render.engine, scene.cycles.samples
    bake_keys = ['use_selected_to_active', 'use_clear', 'margin', 'target', 'use_pass_direct', 'use_pass_indirect', 'use_pass_color', 'use_pass_diffuse', 'use_pass_glossy', 'use_pass_transmission', 'use_pass_emit', 'use_cage', 'cage_object', 'normal_space', 'normal_r', 'normal_g', 'normal_b']
    before_bake = {key: getattr(scene.render.bake, key) for key in bake_keys}
    # Snapshot all selected sources only after preview materials have been restored.
    staged = []
    completed = False
    settings.busy = True
    context.window_manager.progress_begin(0, len(objects))
    try:
        for ob, _ in prev_previews:
            restore_preview(ob)
        scene.render.engine = 'CYCLES'
        scene.cycles.samples = settings.samples
        scene.render.bake.use_selected_to_active = False
        scene.render.bake.use_cage = False
        scene.render.bake.cage_object = None
        scene.render.bake.target = 'IMAGE_TEXTURES'
        for i, ob in enumerate(objects):
            settings.message = '%s %d/%d: %s' % (kind, i+1, len(objects), ob.name)
            context.window_manager.progress_update(i)
            # All targets are now on their original meshes, including active previews.
            mesh_name = ob.data.name
            folder = mesh_folder(root, mesh_name)
            r = bake_one(context, ob, kind, settings, folder)
            staged.append(r)
            records_by_folder.setdefault(folder, []).append(dict(name=ob.name, mesh=mesh_name,
                image=r['file'], uv=r['uv'], sourceRenderUV=r['source_render_uv'],
                denoise=r['denoise'], marginType=r['margin_type']))
        summary = dict(tool='Selected Surface Baker', version='1.2.1', batchId=batch_id, outputProfile=output_profile, kind=kind, resolution=int(settings.resolution), samples=settings.samples, margin=settings.margin, shadowConvention=('white shadow / black visible' if settings.invert_shadow else 'black shadow / white visible'))
        if kind == 'COMBINED':
            summary['otherObjectPreviewMaterials'] = 'AS_VISIBLE' if preserve_environment else 'RESTORE_SOURCE'
        for folder, records in records_by_folder.items():
            (folder/('manifest_'+kind.lower()+'_'+batch_id+'.json')).write_text(
                json.dumps(dict(summary, objects=records), ensure_ascii=False, indent=2), encoding='utf-8')
        for result in staged:
            state = result['object'].ssb_state
            prefix = kind.lower()
            setattr(state, prefix+'_material', result['material'])
            setattr(state, prefix+'_mesh', result['mesh'])
            setattr(state, prefix+'_image', result['image'])
            setattr(state, prefix+'_path', result['file'])
        completed = True
        settings.last_dir = str(next(iter(records_by_folder)) if len(records_by_folder) == 1 else root)
        settings.last_kind = kind
        settings.message = '完成 %d 个物体 · %s · %s px' % (len(staged), kind, settings.resolution)
        return staged
    finally:
        scene.render.engine = engine
        scene.cycles.samples = samples
        for key, value in before_bake.items():
            setattr(scene.render.bake, key, value)
        for ob in list(context.selected_objects):
            ob.select_set(False)
        for ob in before_selected:
            if ob.name in context.view_layer.objects:
                ob.select_set(True)
        if before_active and before_active.name in context.view_layer.objects:
            context.view_layer.objects.active = before_active
        # Reapply earlier previews only AFTER every object has baked, avoiding light feedback.
        for ob, previous_kind in prev_previews:
            apply_preview(ob, previous_kind)
        if completed and settings.auto_preview:
            for ob in objects:
                apply_preview(ob, kind)
        settings.busy = False
        context.window_manager.progress_end()



