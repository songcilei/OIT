# 实测报告 — 2026-11-12

## 环境与方式

Windows / Unity 2022.3.62f3 / Blender 5.0.1。独立 Unity QA 项目 + Blender 后台进程，不在用户现有项目中试验。

## 已通过

### 协议单元测试（12 项）

- UV 相邻三角形共享边不误判重叠。
- 重复三角形、反向重复 UV 拒绝。
- 缺失、退化、越界 UV2 拒绝。
- 非有限浮点、非法顶点索引拒绝。
- 交换路径越界拦截。
- JSON 原子覆盖与 UTF-8。
- 三角形交集面积。
- 非法请求 schema 拒绝。

### Unity 导出与往返

- 实际两个 Prefab 场景实例 + 一个地面，三实例导出。
- 普通实例复用同一网格数据。
- 无变化不重写 revision；移动改变 revision，不新增网格文件。
- 禁用实例会从同步清单移除。
- 关闭 mesh Read/Write 仍可导出。
- 两个自定义桥接 Shader 在 Unity 编译成功。
- 设置与同步根节点可跨 Unity 编辑器重启保存。
- Blender 三个不同位置实例分别得到不同烘焙贴图。
- 导回三个实例、生成三份独立烘焙材质。
- 原 Prefab 资产依然引用 Standard 材质，未被覆盖。
- 应用后再次导出仍使用原材质，源场景 hash 保持一致。
- 对象移动后拒绝应用旧结果。
- 恢复原材质成功，再次应用成功。
- Unity Built-in 中实际相机渲染出 UV2 Unlit 烘焙图。

### Blender

- UV2 的每个 loop 值与 Unity 导出值一致，没有重展开。
- 坐标转换、绕序与法线方向一致。
- 正/负行列式的父级 shear 变换保持世界顶点位置及法线。
- 重同步不删除用户灯光/World。
- Combined bake 写入每实例 UV2，烘焙后源网格、源材质和烘焙设置恢复。
- PNG 显示变换输出。
- EXR 线性浮点输出与关闭 glossy 的路径。
- 对象之间取消不会发布部分成功结果。
- 烘焙中 Unity 快照改变会失败，不自动应用旧结果。
- 接收器 timer 路径也执行了同步/状态发布测试。

### URP

Unity 2022.3 + URP 14.0.11 独立 QA 项目：
- UV2 Unlit 实际相机输出通过，非仅检查 Shader 名称。
- URP/Lit 源材质参数导出通过。

## 图像证据

- `blender-source.png`：Blender 原始 Cycles 光照场景。
- `blender-baked-unlit.png`：同一场景以烘焙贴图 + Emission 显示，关闭第二次显示变换。
- `unity-baked-unlit.png`：真正 Unity Built-in 相机输出，场景中没有额外灯光也保留原阴影。
- `unity-urp-baked-unlit.png`：真正 URP 相机输出（较早 128px/实例的小尺寸测试批次）。

最终主往返测试使用 512px/实例、16 samples；这是功能验证场景，不代表生产烘焙质量或复杂场景性能。初始背景不同属于 Blender World 与 Unity 相机纯色背景差异；比较的是物体表面及阴影。

## 尚未覆盖

- Unity 6、HDRP、其他操作系统。
- 大规模（数千实例）性能及显存压力。
- 所有材质贴图组合的像素级匹配；Standard/URP 与 Cycles 不同 BRDF 不可能自动完全等价。
- 所有第三方编辑器扩展、脚本修改底层数据、动态网格、程序化纹理。
- 所有中断点/断电故障注入。
- 正式项目打包平台的贴图压缩、shader stripping 和运行时性能。

结论：核心链路在上述环境实测可用，定位 v0.1 首版；先在项目副本的小范围中试用。

## v0.1.1 UV2 修复回归

实测：Unity 2022.3.62f3 + Blender 5.0.1。

- 复现内置 Plane 原始 Mesh 缺 UV2。
- 一次扫描精确找出三个缺 UV2 的场景实例。
- Read/Write 关闭的多子网格源 Mesh 成功复制/展 UV2。
- 原内置 Mesh、原源资产、原 Prefab 不变，已有 UV2 和原 Mesh 引用不变。
- 同源实例共用生成的 Mesh 副本；再次修复为 no-op。
- 按三角形角点比较：位置、UV0、法线、切线、颜色、UV3、子网格归属保持。
- MeshCollider 保持原引用。
- 生成资产及实例引用在保存/重开场景后仍有效。
- 恢复所选物体原网格成功，生成资产保留以便恢复。
- Unity 生成的 UV2 实际通过 Blender 正面积重叠检查，4 个测试实例完成 Cycles 烘焙。

OIT 项目实际排查：`Assets/BakeTest/BakeTest.unity` 同步 6 个物体，其中只有内置 Plane 缺 UV2。

## v0.1.2 进度反馈回归

Unity 2022.3.62f3 测试通过：14 个状态/窗口检查、6 个实际异步导入错误路径检查。

- 2/6 = 33% 显示真实数量并提取当前物体 Plane。
- 阻塞 bake 的旧心跳不推进百分比、不伪造失败。
- 已提交时间/旧文件时间回退；成功、失败后的计时固定。
- 旧批次状态/结果、外站点项目被忽略。
- 已完成结果优先于旧 baking 状态；等待导入、导入中、导入失败、完成、取消分别呈现。
- 面板可实例化，所有变更脚本编译通过。
- 真正经过延迟回调进入导入；故意使用过期 sceneHash，验证导入失败状态持久化、Busy 正确释放、不自动重复导入、后续新批次不受旧失败阻挡。

未声称逐采样进度或所有同步导入阶段都能平滑刷新。实际 OIT 工程只更新引用包，不自动启动烘焙、不改场景。

## v0.1.3 单图集模式回归

Unity 2022.3.62f3、Blender 5.0.1、URP 14.0.11 隔离 QA 环境：

- 图集布局 4 组单元测试：1/2/3/6/9/10/50 实例分区、边距、边界 texel center、确定性、容量不足和非法参数。
- Unity 提交：toggle 发送 atlas/整图尺寸，旧 Blender capability 被拒绝，容量不足被拒绝。
- Unity 结果验证：重叠/非有限 ST、多文件“单图集”被拒绝；旧独立图结果默认 identity ST。
- Blender 3 实例直接写入一个 float Image，依次 bake；前两个已写入 tile 不被后续 bake 清空，所有 tile 有实际像素，未使用格子为黑色。
- 最终批次仅一张 PNG；单张浮点 EXR 也通过。
- 不带 atlas 字段的旧请求仍输出每实例独立图片和 identity ST。
- 图集中途取消释放临时 Image，不发布部分图集。
- 多材质子网格实测：每个 tile 包含两个材质的烘焙颜色，不仅保留最后一个材质槽。
- Unity 导入：3 个实例引用同一个 Texture 资产，磁盘只有一个 Atlas.png，各实例 ST 与结果一致。
- 开关 ON → OFF → ON 后贴图引用和 ST 正确；原网格/UV2 不变，原材质恢复正常；不会把 Atlas 材质二次反馈导出。
- Unity Built-in 相机输出 `unity-atlas-unlit.png` 已检查；独立模式输出 `unity-individual-unlit-regression.png` 已检查。
- URP 独立测试项目实际渲染 `unity-urp-atlas.png`，与 Built-in 图像的 RGB 平均绝对误差为 0（本测试相机/场景配置下）。
- 原进度反馈的 14 项回归继续通过。

第一版分配方式为等分网格，不声称按面积优化或自动合批。Atlas 无 mipmap 防跨格串色，远处采样质量/性能仍需根据正式场景实测。没有在用户 OIT 场景自动提交收费/耗时烘焙。

## v0.1.4 _MainTex 覆盖回归

Unity 2022.3.62f3 + URP 14 测试项目，Blender 5.0.1：

- 14 项 Unity 回归：标准模式保持，URP _BaseMap 与 _MainTex 使用不同图片时实际取 _MainTex，多材质槽均处理，映射与其他 PBR 参数分离，原 Albedo alpha smoothness 保留。
- 开/关材质哈希变化、重复开启稳定、关闭恢复原 hash；源材质不修改。
- 缺失 _MainTex 回退提示、自定义不透明 base-only、自定义关闭仍拒绝、透明自定义拒绝。
- 已应用烘焙的实例取原材质，不反馈烘焙图。
- Blender 5 组快照实际节点检查：普通、覆盖、缺失、自定义、恢复普通；覆盖时实际 Image Color 直接连接 Base Color、贴图文件和 Tiling/Offset 符合记录。
- 实际 Cycles UV2 烘焙成功。

测试中确认 URP 材质导入可能自动镜像 _BaseMap 到隐藏 _MainTex；测试在导入完成后设置两者不同，再验证导出。工具不篡改这个 Unity 行为。

## v0.1.5 自动 _MainTex Shader 兼容测试（2026-11-17）

Unity 2022.3.62f3：13 项回归通过，包括自定义 Shader 在 Toggle OFF/ON 下均可导出、ST 保留、透明/Cutout 不再中断但明确近似提示、空贴图白色回退、镜像采样近似、正常 Standard 路径不变、不支持 Standard 模式回退、Float 伪属性拒绝、Cubemap 准确类型错误、源材质不修改。

Blender 5.0.1：接收 10 组导出快照，验证直接 BaseColor / 标准乘色 / 空白材质节点；实际 Cycles UV2 烘焙通过。未声称真实还原任意自定义 Shader 的光照、透明、顶点变形等效果。测试在隔离项目完成。

## v0.1.6 _BaseMap 兼容修复（2026-11-17）

项目只读确认：`F:/UnityProject/pp_ta_unity/UnityProject/Packages/com.ifreetalk.render-pipeline/Shaders/Shaders/Lit.shader` 声明 [NoScaleOffset] _BaseMap；`Assets/ResOriginSources/NewPaiPai_AI_01/Materials/dimian_01_d.mat` 的基础色纹理绑定于该属性。

范围为单个导出模块的小修复 + UI 提示和版本标识，不改变协议，不扩大为自定义渲染管线转换；按该仓库 lightweight 工作流处理。

实测：隔离 Unity 2022.3.62f3 项目中 9 项 BaseMap 回归（无 MainTex、强制开关、双入口优先级、各自 ST、空入口回退、哈希稳定、原材质不改）；Blender 5.0.1 接收 8 组节点/路径/ST 检查及实际 Cycles UV2 烘焙通过。使用与实际属性声明匹配的轻量测试 Shader，不将它表述为完整 PaiPai 管线验证。

未打开/批处理运行用户的完整团结 1.10.4 项目，实际项目 Console 刷新后的编译/同步仍由用户确认。未修改其已有场景、美术、Packages manifest 或其他工作区改动；正式工程的自定义 Shader 外观还原不在本修复范围。

## v0.1.7 无效 UV2 修复与有限绕过（2026-11-17）

- 实际导出副本 pCube1.025 / pCube1.024 / 蓝房子.001 / pCube1.023 在 Unity 普通 unwrap 后仍退化；新严格修复在副本分配独立图块后全部通过。
- 五对象（四问题对象+有效对照）合计 67167 三角形由 Blender 严格检查并实际低分辨率 Cycles 烘焙成功，没有启用跳过。
- 9 项修复安全测试通过；原几何/UV0/其他顶点流、原资产、有效实例与恢复链验证。
- Python 12 原协议、4 图集、9 skip 单元测试通过。
- 实际 skip bake 在独立图/图集下成功，警告保留且原几何/UV不变；全部退化拒绝。
- 5 项 Unity 跳过能力握手、请求和完成风险显示检查通过。
- 用户完整团结工程未自动执行修复/烘焙；用户需要重启 Blender 载入 0.1.7、Unity 刷新后主动点击。未声称生产画面无瑕疵。

## v0.1.8 全 UV2 质量检查绕过

- Python：12 原协议 + 4 图集 + 9 旧退化绕过 + 7 新全绕过测试通过。新模式证明不调用面积/重叠质量计算，输入数据未修改；缺失、数组长度错误、非有限值、非法索引仍拒绝。
- Blender 5.0.1：实际带重叠 UV 的独立图与图集 bake 均成功，警告持久化，几何/UV保持；越界和全退化通过任务初始化，后两项未声称生产烘焙图可用。
- Unity 2022.3.62f3：编译通过；6 项请求、能力握手、成功后警告、关闭严格、导入模式不符拒绝、旧请求语义保留测试通过。
- 用户当前 12 实例、68657 三角形导出快照通过新版只读全绕过验证，不启动用户正式场景烘焙。
- 未在用户完整团结工程自动提交生产烘焙或验收画面；跳过只是放行，不修复画面。
