using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using LiveBakeBridge;
using LiveBakeBridge.Editor;
public static class UVRepairSafetyRegression {
 static void Check(bool b,string why){if(!b)throw new Exception("FAIL: "+why);Debug.Log("PASS: "+why);}
 static Mesh MeshWithBadUV(){var m=new Mesh{name="Safety"};m.vertices=new[]{Vector3.zero,Vector3.right,Vector3.up};m.triangles=new[]{0,1,2};m.uv=new[]{Vector2.zero,Vector2.right,Vector2.up};m.uv2=new[]{Vector2.zero,Vector2.zero,Vector2.one};m.RecalculateNormals();return m;}
 public static void Run(){try{
  EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);var root=new GameObject("SafetyRoot");var first=root.AddComponent<MeshFilter>();var original=MeshWithBadUV();AssetDatabase.CreateAsset(original,AssetDatabase.GenerateUniqueAssetPath("Assets/UVSafetySource.asset"));first.sharedMesh=original;
  EditorSceneManager.SaveScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene(),"Assets/UVSafety.unity");
  var blocked=new GameObject("BlockedBlendShape");var second=blocked.AddComponent<MeshFilter>();var shape=MeshWithBadUV();shape.AddBlendShapeFrame("Shape",100,new Vector3[3],new Vector3[3],new Vector3[3]);second.sharedMesh=shape;
  bool threw=false;try{UV2Repair.GenerateFor(new[]{first,second},true);}catch(InvalidOperationException){threw=true;}Check(threw&&first.sharedMesh==original&&first.GetComponent<LiveBakeUV2Binding>()==null,"preflight failure leaves all original scene references intact");
  original.UploadMeshData(true);Check(UV2Audit.Inspect(original).degenerate==1,"audit works on non-readable source");Check(UV2Repair.GenerateFor(new[]{first},true)==1,"non-readable invalid mesh repaired");var generated=first.sharedMesh;Check(UV2Audit.Inspect(generated).Valid,"repair result passes strict audit");
  var uv=generated.uv2;var indices=generated.triangles;uv[indices[1]]=uv[indices[0]];generated.uv2=uv;
  Check(UV2Repair.GenerateFor(new[]{first},true)==1,"second repair of modified copy supported");Check(first.GetComponent<LiveBakeUV2Binding>().originalMesh==original,"repeated repair backup points to original source not intermediate copy");
  var bake=root.AddComponent<LiveBakeBinding>();bake.applied=true;uv=first.sharedMesh.uv2;indices=first.sharedMesh.triangles;uv[indices[1]]=uv[indices[0]];first.sharedMesh.uv2=uv;threw=false;try{UV2Repair.GenerateFor(new[]{first},true);}catch(InvalidOperationException){threw=true;}Check(threw,"baked instance requires restore before re-UV");bake.applied=false;
  Selection.activeGameObject=root;Check(UV2Repair.RestoreSelected()==1&&first.sharedMesh==original,"restoration reaches original source after repeated repairs");
  Check(AssetDatabase.LoadAssetAtPath<Mesh>(AssetDatabase.GetAssetPath(generated))!=null,"restore keeps old generated asset for recovery");
  Debug.Log("UV2_REPAIR_SAFETY_PASSED");EditorApplication.Exit(0);
 }catch(Exception e){Debug.LogException(e);EditorApplication.Exit(1);}}
}
