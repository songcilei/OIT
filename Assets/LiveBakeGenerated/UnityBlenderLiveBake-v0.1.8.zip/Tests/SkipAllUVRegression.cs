using System;
using System.IO;
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using LiveBakeBridge.Editor;
public static class SkipAllUVRegression {
 static void Check(bool b,string m){if(!b)throw new Exception("FAIL: "+m);Debug.Log("PASS: "+m);}
 static void Ready(string folder,BridgeStatus status){status.unixTime=BakeProgress.Now;BridgeIO.Json(Path.Combine(folder,"status.json"),status);}
 public static void Run(){try{
  EditorSceneManager.OpenScene("Assets/Fixture.unity");BakeImporter.RestoreAllLoaded();var s=BridgeSettings.instance;s.rootIds=new[]{BridgeIO.Id(GameObject.Find("SyncRoot"))};s.folder=Path.GetFullPath("../skip-all-request-exchange");s.liveSync=false;s.autoImport=false;s.forceMainTexBaseColor=false;s.atlas=false;s.skipDegenerateUV2=true;s.skipUV2Validation=true;s.Persist();
  var m=SceneExporter.Export(true);var status=new BridgeStatus{projectId=m.projectId,revision=m.revision,state="ready",supportsAtlas=true,supportsSkipDegenerateUV2=true,supportsMainTexOverride=true};Ready(s.Folder,status);
  bool reject=false;try{BridgeService.RequestBake();}catch(InvalidOperationException e){reject=e.Message.Contains("0.1.8");}Check(reject,"old degeneracy-only receiver cannot accept full bypass");
  status.supportsSkipUV2Validation=true;Ready(s.Folder,status);var req=BridgeService.RequestBake();Check(req.skipUV2Validation&&!req.skipDegenerateUV2,"new UI sends only new all-quality flag");
  var result=new BakeResult{schema=1,projectId=m.projectId,id=req.id,revision=m.revision,sceneHash=m.sceneHash,status="complete",format="PNG",items=new BakeItem[3],skippedUV2Validation=true,warnings=new[]{"ALL UV2 quality checks skipped"}};
  var view=BakeProgress.Evaluate(req,status,result,null,m.projectId,req.id,BakeProgress.Now,req.queuedAt,BakeProgress.Now);Check(view.phase=="complete"&&view.warning.Contains("全部 UV2")&&view.warning.Contains("ALL UV2"),"complete result still visibly warns about full bypass");
  BridgeIO.Json(Path.Combine(s.Folder,"results","latest.json"),result);s.skipUV2Validation=false;req=BridgeService.RequestBake();Check(!req.skipUV2Validation&&!req.skipDegenerateUV2,"OFF remains strict even if old saved degeneracy toggle was true");
  // Matching result mode mismatch must be rejected before asset import/scene mutation.
  result.id=req.id;BridgeIO.Json(Path.Combine(s.Folder,"results","latest.json"),result);reject=false;try{BakeImporter.ImportLatest();}catch(InvalidOperationException e){reject=e.Message.Contains("quality-check bypass");}Check(reject,"import rejects mismatched full-bypass result mode");
  var legacy=new BakeRequest{projectId="p",id="old",skipDegenerateUV2=true,queuedAt=1};var lr=new BakeResult{projectId="p",id="old",status="complete",items=new BakeItem[1],skippedDegenerateUV2=true,skippedDegenerateFaces=3,warnings=new[]{"legacy"}};
  view=BakeProgress.Evaluate(legacy,null,lr,null,"p","old",4,1,3);Check(view.warning.Contains("退化")&&!view.warning.Contains("全部"),"legacy result keeps original narrow warning semantics");
  var win=EditorWindow.GetWindow<LiveBakeWindow>();win.Repaint();win.Close();Debug.Log("SKIP_ALL_UNITY_PASSED");EditorApplication.Exit(0);
 }catch(Exception e){Debug.LogException(e);EditorApplication.Exit(1);}}
}
