using System;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using LiveBakeBridge.Editor;
public static class BaseMapRegression {
 static void Check(bool b,string m){if(!b)throw new Exception("FAIL: "+m);Debug.Log("PASS: "+m);}
 static SceneManifest Snap(string name){var m=SceneExporter.Export(true);BridgeIO.Json(Path.Combine(BridgeSettings.instance.Folder,name+".json"),m);return m;}
 static Texture2D Make(string name,Color color){var t=new Texture2D(4,4);t.SetPixels(Enumerable.Repeat(color,16).ToArray());t.Apply();string p="Assets/"+name+".png";File.WriteAllBytes(p,t.EncodeToPNG());AssetDatabase.ImportAsset(p,ImportAssetOptions.ForceSynchronousImport);return AssetDatabase.LoadAssetAtPath<Texture2D>(p);}
 public static void Run(){try{
  EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);var root=new GameObject("BaseMapRoot");var cube=GameObject.CreatePrimitive(PrimitiveType.Cube);cube.transform.SetParent(root.transform);var mesh=UnityEngine.Object.Instantiate(cube.GetComponent<MeshFilter>().sharedMesh);Unwrapping.GenerateSecondaryUVSet(mesh);AssetDatabase.CreateAsset(mesh,"Assets/BaseMapMesh.asset");cube.GetComponent<MeshFilter>().sharedMesh=mesh;
  var red=Make("BaseMapTestRed",Color.red);var blue=Make("BaseMapTestBlue",Color.blue);
  var mat=new Material(Shader.Find("QA/BaseMapOnly"));mat.name="dimian_01_d_fixture";mat.SetTexture("_BaseMap",red);AssetDatabase.CreateAsset(mat,"Assets/BaseMapMaterial.asset");var r=cube.GetComponent<MeshRenderer>();r.sharedMaterial=mat;EditorSceneManager.SaveScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene(),"Assets/BaseMapQA.unity");
  var s=BridgeSettings.instance;s.folder=Path.GetFullPath("../basemap-exchange");s.rootIds=new[]{BridgeIO.Id(root)};s.liveSync=false;s.autoImport=false;s.forceMainTexBaseColor=false;s.Persist();
  var off=Snap("base-off");Check(!mat.HasProperty("_MainTex")&&off.materials[0].directBaseTexture&&!string.IsNullOrEmpty(off.materials[0].baseTexture),"BaseMap-only shader exported without MainTex property or toggle");
  s.forceMainTexBaseColor=true;Check(Snap("base-on").sceneHash==off.sceneHash,"MainTex toggle ON still falls back to BaseMap when no MainTex exists");
  var dual=new Material(Shader.Find("QA/DualBaseTexture"));dual.SetTexture("_BaseMap",red);dual.SetTexture("_MainTex",blue);dual.SetTextureScale("_BaseMap",new Vector2(2,3));dual.SetTextureOffset("_BaseMap",new Vector2(.1f,.2f));dual.SetTextureScale("_MainTex",new Vector2(4,5));r.sharedMaterial=dual;s.forceMainTexBaseColor=false;var a=Snap("dual-base");Check(a.materials[0].baseTexture==off.materials[0].baseTexture&&a.materials[0].baseTextureTiling.SequenceEqual(new[]{2f,3f,.1f,.2f}),"default selects BaseMap with its ST when both exist");
  s.forceMainTexBaseColor=true;var c=Snap("dual-main");Check(c.materials[0].baseTexture!=a.materials[0].baseTexture&&c.materials[0].baseTextureTiling[0]==4,"explicit MainTex override selects MainTex with own ST");
  dual.SetTexture("_MainTex",null);Check(Snap("dual-empty-main").materials[0].baseTexture==a.materials[0].baseTexture,"empty MainTex does not hide populated BaseMap");dual.SetTexture("_MainTex",blue);dual.SetTexture("_BaseMap",null);s.forceMainTexBaseColor=false;Check(Snap("dual-empty-base").materials[0].baseTexture==c.materials[0].baseTexture,"empty BaseMap falls back to populated MainTex");
  r.sharedMaterial=mat;mat.SetTexture("_BaseMap",null);var blank=Snap("blank");Check(string.IsNullOrEmpty(blank.materials[0].baseTexture)&&SceneExporter.Warnings.Any(w=>w.Contains("_BaseMap 未设置")),"empty BaseMap has accurate white fallback warning");mat.SetTexture("_BaseMap",red);Check(Snap("restored").sceneHash==off.sceneHash,"original mapping stable after mode switches");
  Check(mat.GetTexture("_BaseMap")==red,"source BaseMap material unmodified");var window=EditorWindow.GetWindow<LiveBakeWindow>();window.Repaint();window.Close();Debug.Log("BASEMAP_UNITY_PASSED");EditorApplication.Exit(0);
 }catch(Exception e){Debug.LogException(e);EditorApplication.Exit(1);}}
}
