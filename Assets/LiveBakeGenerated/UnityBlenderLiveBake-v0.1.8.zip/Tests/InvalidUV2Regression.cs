using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using LiveBakeBridge;
using LiveBakeBridge.Editor;
public static class InvalidUV2Regression {
 static void Check(bool b,string message){if(!b)throw new Exception("FAIL: "+message);Debug.Log("PASS: "+message);}
 static Mesh Square(bool bad){var m=new Mesh{name="TwoTriangles"};m.vertices=new[]{Vector3.zero,Vector3.right,Vector3.up,new Vector3(2,0,0),new Vector3(3,0,0),new Vector3(2,1,0)};m.triangles=new[]{0,1,2,3,4,5};m.uv=new[]{new Vector2(0,0),new Vector2(1,0),new Vector2(0,1),new Vector2(0,0),new Vector2(1,0),new Vector2(0,1)};m.uv2=new[]{new Vector2(.1f,.1f),new Vector2(.4f,.1f),new Vector2(.1f,.4f),new Vector2(.6f,.6f),new Vector2(bad?.6f:.9f,.6f),new Vector2(.6f,.9f)};m.RecalculateNormals();m.RecalculateTangents();m.colors=Enumerable.Repeat(Color.cyan,6).ToArray();m.uv3=m.uv;return m;}
 static string[] Corners(Mesh m){var ps=m.vertices;var uv=m.uv;var ns=m.normals;return Enumerable.Range(0,m.subMeshCount).SelectMany(sub=>m.GetTriangles(sub).Select(i=>sub+"|"+ps[i].ToString("F6")+"|"+uv[i].ToString("F6")+"|"+ns[i].ToString("F6"))).OrderBy(x=>x,StringComparer.Ordinal).ToArray();}
 public static void Run(){try{
  EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);var root=new GameObject("InvalidUVQA");var mat=new Material(Shader.Find("Standard"));AssetDatabase.CreateAsset(mat,"Assets/InvalidUVMat.mat");var filters=new List<MeshFilter>();
  var bad=Square(true);var valid=Square(false);Check(UV2Audit.Inspect(bad).degenerate==1,"scan exact UV degeneration");Check(UV2Audit.Inspect(valid).Valid,"valid non-overlapping mesh accepted");var rescued=UV2Audit.RescueDegenerate(bad,UV2Audit.Inspect(bad));Check(UV2Audit.Inspect(rescued).Valid,"isolated face chart rescue validates");Check(Corners(bad).SequenceEqual(Corners(rescued)),"rescue preserves geometry/UV0/normals/corner order");Check(rescued.colors.All(x=>x==Color.cyan)&&rescued.uv3.Length==rescued.vertexCount&&rescued.tangents.Length==rescued.vertexCount,"rescue copies all vertex streams to split corners");
  var overlap=Square(false);overlap.uv2=overlap.uv2.Take(3).Concat(overlap.uv2.Take(3)).ToArray();Check(UV2Audit.Inspect(overlap).overlaps>0,"overlap scanner detects duplicate islands");var range=Square(false);var ru=range.uv2;ru[0]=new Vector2(2,0);range.uv2=ru;Check(UV2Audit.Inspect(range).outOfRange==1,"range scanner rejects tiled UV");
  var sources=new Dictionary<MeshFilter,Mesh>();var cornerHashes=new Dictionary<MeshFilter,string[]>();var sourceUVs=new Dictionary<MeshFilter,Vector2[]>();
  string input=@"F:\UnityProject\pp_ta_unity\UnityProject\Library\UnityBlenderLiveBake";var manifest=BridgeIO.Read<SceneManifest>(input+"/scene.json");
  foreach(var ob in manifest.objects){var record=BridgeIO.Read<MeshRecord>(input+"/meshes/"+ob.mesh+".json");if(!record.hasUV2)continue;var m=ProbeUVReunwrap.Load(record);m.name=ob.name;var audit=UV2Audit.Inspect(m);if(audit.Valid){UnityEngine.Object.DestroyImmediate(m);continue;}Debug.Log("AUDIT_REAL "+ob.name+" "+audit.Summary);AssetDatabase.CreateAsset(m,AssetDatabase.GenerateUniqueAssetPath("Assets/InvalidUVSource.asset"));var go=new GameObject(ob.name);go.transform.SetParent(root.transform);var mf=go.AddComponent<MeshFilter>();mf.sharedMesh=m;go.AddComponent<MeshRenderer>().sharedMaterials=Enumerable.Repeat(mat,m.subMeshCount).ToArray();filters.Add(mf);sources[mf]=m;cornerHashes[mf]=Corners(m);sourceUVs[mf]=m.uv2.ToArray();}
  var goodGo=new GameObject("ValidUntouched");goodGo.transform.SetParent(root.transform);AssetDatabase.CreateAsset(valid,"Assets/ValidUVSource.asset");var good=goodGo.AddComponent<MeshFilter>();good.sharedMesh=valid;goodGo.AddComponent<MeshRenderer>().sharedMaterial=mat;
  EditorSceneManager.SaveScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene(),"Assets/InvalidUVQA.unity");var s=BridgeSettings.instance;s.rootIds=new[]{BridgeIO.Id(root)};s.folder=Path.GetFullPath("../invalid-uv-exchange");s.autoImport=false;s.liveSync=false;s.forceMainTexBaseColor=false;s.Persist();
  Check(filters.Count>=3,"real scene problem meshes loaded into isolated test project");Check(UV2Audit.Scan().Count==filters.Count,"scan lists invalid instances only");
  // Explicit rescan/repair; no user project object is edited.
  int n=UV2Repair.GenerateFor(filters.Concat(new[]{good}),true);Check(n==filters.Count,"repair applied only to invalid instances");
  foreach(var mf in filters){Check(UV2Audit.Inspect(mf.sharedMesh).Valid,"repaired UV2 strictly valid: "+mf.name);Check(Corners(mf.sharedMesh).SequenceEqual(cornerHashes[mf]),"original surfaces/UV0 preserved: "+mf.name);Check(sources[mf].uv2.SequenceEqual(sourceUVs[mf]),"source asset UV2 unchanged: "+mf.name);}
  Check(good.sharedMesh==valid,"valid object mesh not replaced");Check(UV2Repair.GenerateFor(filters,true)==0,"repair repeated on valid copies is no-op");
  SceneExporter.Export(true);EditorSceneManager.SaveScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene());
  Selection.activeGameObject=root;Check(UV2Repair.RestoreSelected()==filters.Count,"restore original mesh references");foreach(var mf in filters)Check(mf.sharedMesh==sources[mf],"restore reaches original source: "+mf.name);
  // Missing-generation existing API still works and strict post-validation does not rely on bypass.
  var missing=Square(false);missing.uv2=null;var missGo=new GameObject("Missing");missGo.transform.SetParent(root.transform);var missFilter=missGo.AddComponent<MeshFilter>();missFilter.sharedMesh=missing;missGo.AddComponent<MeshRenderer>().sharedMaterial=mat;
  Check(UV2Repair.GenerateFor(new[]{missFilter})==1&&UV2Audit.Inspect(missFilter.sharedMesh).Valid,"missing UV2 path preserved");
  Debug.Log("INVALID_UV2_UNITY_PASSED");EditorApplication.Exit(0);
 }catch(Exception e){Debug.LogException(e);EditorApplication.Exit(1);}}
}
