using System;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEditor;
using LiveBakeBridge.Editor;
public static class ProbeUVReunwrap {
 public static int Bad(Mesh m){var u=m.uv2;int bad=0;foreach(var sub in Enumerable.Range(0,m.subMeshCount)){var tr=m.GetTriangles(sub);for(int k=0;k<tr.Length;k+=3){var a=u[tr[k]];var bb=u[tr[k+1]];var c=u[tr[k+2]];double ar=Math.Abs(((double)bb.x-a.x)*((double)c.y-a.y)-((double)bb.y-a.y)*((double)c.x-a.x))*.5;if(ar<1e-12)bad++;}}return bad;}
 public static Mesh Load(MeshRecord d){var m=new Mesh();m.indexFormat=UnityEngine.Rendering.IndexFormat.UInt32;m.vertices=Enumerable.Range(0,d.vertices.Length/3).Select(i=>new Vector3(d.vertices[i*3],d.vertices[i*3+1],d.vertices[i*3+2])).ToArray();m.normals=Enumerable.Range(0,d.normals.Length/3).Select(i=>new Vector3(d.normals[i*3],d.normals[i*3+1],d.normals[i*3+2])).ToArray();m.uv=Enumerable.Range(0,d.uv0.Length/2).Select(i=>new Vector2(d.uv0[i*2],d.uv0[i*2+1])).ToArray();m.uv2=Enumerable.Range(0,d.uv2.Length/2).Select(i=>new Vector2(d.uv2[i*2],d.uv2[i*2+1])).ToArray();m.subMeshCount=d.faceMaterials.Max()+1;for(int sub=0;sub<m.subMeshCount;sub++)m.SetTriangles(Enumerable.Range(0,d.faceMaterials.Length).Where(i=>d.faceMaterials[i]==sub).SelectMany(i=>d.triangles.Skip(i*3).Take(3)).ToArray(),sub);return m;}
 public static void Run(){try{string root=@"F:\UnityProject\pp_ta_unity\UnityProject\Library\UnityBlenderLiveBake";var s=BridgeIO.Read<SceneManifest>(root+"/scene.json");foreach(var ob in s.objects){var d=BridgeIO.Read<MeshRecord>(root+"/meshes/"+ob.mesh+".json");if(!d.hasUV2)continue;var m=Load(d);int before=Bad(m);if(before==0){UnityEngine.Object.DestroyImmediate(m);continue;}UnwrapParam.SetDefaults(out var param);param.packMargin=.04f;bool ok=Unwrapping.GenerateSecondaryUVSet(m,param);Debug.Log("PROBE "+ob.name+" before="+before+" after="+Bad(m)+" ok="+ok);UnityEngine.Object.DestroyImmediate(m);}EditorApplication.Exit(0);}catch(Exception e){Debug.LogException(e);EditorApplication.Exit(1);}}
}
