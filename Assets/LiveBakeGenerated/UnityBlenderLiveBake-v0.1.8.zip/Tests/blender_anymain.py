import sys,uuid
from pathlib import Path
import bpy
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'BlenderAddon'))
from unity_live_bake import protocol as p,receiver,baker
root=R/'Tests/anymain-exchange';bpy.ops.wm.read_factory_settings(use_empty=True)
for mode in ['custom-off','custom-on','transparent','cutout','empty','mirror','standard','standard-transparent','standard-parallax','final']:
 m=p.load_json(root/(mode+'.json'));p.atomic_json(root/'scene.json',m);receiver.sync_scene(root)
 rec=m['materials'][0];mat=next(x for x in bpy.data.materials if x.get('ulb_material')==rec['id']);bsdf=next(n for n in mat.node_tree.nodes if n.type=='BSDF_PRINCIPLED')
 if rec['baseTexture']:
  link=bsdf.inputs['Base Color'].links[0].from_node;assert link.type==('TEX_IMAGE' if rec['directBaseTexture'] else 'MIX_RGB')
 else:assert not bsdf.inputs['Base Color'].is_linked and tuple(bsdf.inputs['Base Color'].default_value)==(1,1,1,1)
 print('PASS: Blender received '+mode,flush=True)
world=bpy.data.worlds.new('QA');world.use_nodes=True;world.node_tree.nodes['Background'].inputs[1].default_value=.5;bpy.context.scene.world=world
req=dict(schema=1,projectId=m['projectId'],id=uuid.uuid4().hex,revision=m['revision'],sceneHash=m['sceneHash'],resolution=64,samples=2,margin=2,format='PNG',includeGlossy=False)
s=baker.BakeSession(root,req)
while s.step():pass
assert p.load_json(root/'results/latest.json')['status']=='complete'
print('ANY_MAINTEX_BLENDER_PASSED',flush=True)
