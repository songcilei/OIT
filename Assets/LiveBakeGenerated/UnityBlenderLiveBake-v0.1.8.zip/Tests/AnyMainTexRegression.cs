using System;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using LiveBakeBridge.Editor;
public static class AnyMainTexRegression {
 static void Check(bool c,string s){if(!c)throw new Exception("FAIL: "+s);Debug.Log("PASS: "+s);}
 static SceneManifest Snap(string name){var m=SceneExporter.Export(true);BridgeIO.Json(Path.Combine(BridgeSettings.instance.Folder,name+".json"),m);return m;}
 public static void Run(){try{
  EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
  var root=new GameObject("AnyMainRoot");var go=GameObject.CreatePrimitive(PrimitiveType.Cube);go.transform.SetParent(root.transform);
  var mesh=UnityEngine.Object.Instantiate(go.GetComponent<MeshFilter>().sharedMesh);Unwrapping.GenerateSecondaryUVSet(mesh);AssetDatabase.CreateAsset(mesh,"Assets/AnyMainMesh.asset");go.GetComponent<MeshFilter>().sharedMesh=mesh;
  var tex=new Texture2D(4,4);tex.SetPixels(Enumerable.Repeat(Color.red,16).ToArray());tex.Apply();File.WriteAllBytes("Assets/AnyMainRed.png",tex.EncodeToPNG());AssetDatabase.ImportAsset("Assets/AnyMainRed.png",ImportAssetOptions.ForceSynchronousImport);var ti=(TextureImporter)AssetImporter.GetAtPath("Assets/AnyMainRed.png");ti.isReadable=false;ti.SaveAndReimport();var texture=AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/AnyMainRed.png");
  var mat=new Material(Shader.Find("QA/AnyMainTex"));mat.SetTexture("_MainTex",texture);mat.SetTextureScale("_MainTex",new Vector2(2,3));mat.SetTextureOffset("_MainTex",new Vector2(.2f,.3f));AssetDatabase.CreateAsset(mat,"Assets/AnyMainCustom.mat");var renderer=go.GetComponent<MeshRenderer>();renderer.sharedMaterial=mat;
  EditorSceneManager.SaveScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene(),"Assets/AnyMainQA.unity");var s=BridgeSettings.instance;s.folder=Path.GetFullPath("../anymain-exchange");s.rootIds=new[]{BridgeIO.Id(root)};s.liveSync=false;s.autoImport=false;s.forceMainTexBaseColor=false;s.Persist();
  var off=Snap("custom-off");Check(off.materials[0].directBaseTexture&&!string.IsNullOrEmpty(off.materials[0].baseTexture),"custom Shader accepted with override toggle OFF");Check(off.materials[0].baseTextureTiling.SequenceEqual(new[]{2f,3f,.2f,.3f}),"custom Tiling Offset retained");s.forceMainTexBaseColor=true;Check(Snap("custom-on").sceneHash==off.sceneHash,"custom fallback independent of override toggle");s.forceMainTexBaseColor=false;
  mat.renderQueue=3000;mat.SetOverrideTag("RenderType","Transparent");Check(Snap("transparent").objects.Length==1&&SceneExporter.Warnings.Any(w=>w.Contains("不透明 RGB")),"transparent Shader accepted as opaque approximation with warning");mat.SetOverrideTag("RenderType","TransparentCutout");mat.EnableKeyword("_ALPHATEST_ON");Check(Snap("cutout").objects.Length==1,"cutout no longer blocked by Shader rule");mat.DisableKeyword("_ALPHATEST_ON");mat.renderQueue=-1;mat.SetOverrideTag("RenderType","Opaque");
  mat.SetTexture("_MainTex",null);var empty=Snap("empty");Check(string.IsNullOrEmpty(empty.materials[0].baseTexture)&&SceneExporter.Warnings.Any(w=>w.Contains("白色基础色")),"empty MainTex falls back to white with warning");
  mat.SetTexture("_MainTex",texture);texture.wrapMode=TextureWrapMode.Mirror;Check(Snap("mirror").objects.Length==1&&SceneExporter.Warnings.Any(w=>w.Contains("Repeat")),"custom mirror sampler approximated without interruption");texture.wrapMode=TextureWrapMode.Repeat;
  var standard=new Material(Shader.Find("Standard"));standard.SetTexture("_MainTex",texture);renderer.sharedMaterial=standard;var normal=Snap("standard");Check(!normal.materials[0].directBaseTexture,"supported Standard normal sync unchanged");standard.SetFloat("_Mode",3);Check(Snap("standard-transparent").materials[0].directBaseTexture,"unsupported Standard mode uses MainTex fallback");standard.SetFloat("_Mode",0);standard.EnableKeyword("_PARALLAXMAP");Check(Snap("standard-parallax").materials[0].directBaseTexture,"unsupported PBR layers use MainTex fallback");
  renderer.sharedMaterial=new Material(Shader.Find("QA/NotTextureMainTex"));bool rejected=false;try{SceneExporter.Export();}catch(InvalidOperationException e){rejected=e.Message.Contains("no _BaseMap or _MainTex texture property");}Check(rejected,"MainTex float property is not mistaken for texture");
  renderer.sharedMaterial=mat;mat.SetTexture("_MainTex",new Cubemap(4,TextureFormat.RGBA32,false));rejected=false;try{SceneExporter.Export();}catch(InvalidOperationException e){rejected=e.Message.Contains("not a Texture2D");}Check(rejected,"non-2D resource produces accurate resource error instead of Lit error");mat.SetTexture("_MainTex",texture);Snap("final");Check(mat.shader.name=="QA/AnyMainTex"&&mat.GetTexture("_MainTex")==texture,"source material Shader and texture preserved");
  Debug.Log("ANY_MAINTEX_UNITY_PASSED");EditorApplication.Exit(0);
 }catch(Exception e){Debug.LogException(e);EditorApplication.Exit(1);}}
}

