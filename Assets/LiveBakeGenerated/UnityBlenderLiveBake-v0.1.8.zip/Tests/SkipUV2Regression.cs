using System;
using System.IO;
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using LiveBakeBridge.Editor;
public static class SkipUV2Regression {
 static void Check(bool b,string message){if(!b)throw new Exception("FAIL: "+message);Debug.Log("PASS: "+message);}
 public static void Run(){try{
  EditorSceneManager.OpenScene("Assets/Fixture.unity");BakeImporter.RestoreAllLoaded();var root=GameObject.Find("SyncRoot");var s=BridgeSettings.instance;s.rootIds=new[]{BridgeIO.Id(root)};s.folder=Path.GetFullPath("../skip-request-exchange");s.liveSync=false;s.autoImport=false;s.forceMainTexBaseColor=false;s.atlas=false;s.skipDegenerateUV2=true;s.Persist();
  var m=SceneExporter.Export(true);var st=new BridgeStatus{state="ready",projectId=m.projectId,revision=m.revision,unixTime=BakeProgress.Now,supportsAtlas=true,supportsMainTexOverride=true};BridgeIO.Json(Path.Combine(s.Folder,"status.json"),st);
  bool rejected=false;try{BridgeService.RequestBake();}catch(InvalidOperationException e){rejected=e.Message.Contains("0.1.7");}Check(rejected,"old Blender cannot silently ignore bypass option");
  st.supportsSkipDegenerateUV2=true;BridgeIO.Json(Path.Combine(s.Folder,"status.json"),st);var req=BridgeService.RequestBake();Check(req.skipDegenerateUV2,"explicit toggle serializes request flag");
  var result=new BakeResult{schema=1,projectId=m.projectId,id=req.id,revision=m.revision,sceneHash=m.sceneHash,status="complete",items=new BakeItem[3],skippedDegenerateUV2=true,skippedDegenerateFaces=9,warnings=new[]{"pCube1.025: skipped 9 degenerate UV2 faces"}};
  var view=BakeProgress.Evaluate(req,st,result,null,m.projectId,req.id,BakeProgress.Now,req.queuedAt,BakeProgress.Now);Check(view.phase=="complete"&&view.warning.Contains("pCube1.025")&&view.warning.Contains("9"),"completed bake retains instance warning and skipped count");
  BridgeIO.Json(Path.Combine(s.Folder,"results","latest.json"),result);s.skipDegenerateUV2=false;req=BridgeService.RequestBake();Check(!req.skipDegenerateUV2,"OFF mode restores strict request");
  var win=EditorWindow.GetWindow<LiveBakeWindow>();win.Repaint();win.Close();Check(true,"new UV2 controls compile and window opens");Debug.Log("SKIP_UV2_UNITY_PASSED");EditorApplication.Exit(0);
 }catch(Exception e){Debug.LogException(e);EditorApplication.Exit(1);}}
}
