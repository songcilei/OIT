import importlib.util,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];spec=importlib.util.spec_from_file_location('protocol',R/'BlenderAddon/unity_live_bake/protocol.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
root=Path(r'F:\UnityProject\pp_ta_unity\UnityProject\Library\UnityBlenderLiveBake');m=p.load_json(root/'scene.json');n=0
for ob in m['objects']:
 d=p.load_json(root/'meshes'/(ob['mesh']+'.json'));info={};n+=p.validate_uv2(d,diagnostics=info,skip_quality=True);assert info['qualityChecksSkipped']
 print('PASS: read-only full-bypass validation',ob['name'],flush=True)
print('REAL_SKIP_ALL_VALIDATION_PASSED',len(m['objects']),n,flush=True)
