import unittest,copy
from unittest.mock import patch
from test_skip_uv2 import p,m
class AllTests(unittest.TestCase):
 def test_overlap_and_degenerate(self):
  a=m();a['triangles'] += [0,1,2];a['faceMaterials'] += [0];before=copy.deepcopy(a);d={}
  with patch.object(p,'intersection_area',side_effect=AssertionError('quality executed')),patch.object(p,'_area',side_effect=AssertionError('area executed')):
   self.assertEqual(p.validate_uv2(a,diagnostics=d,skip_quality=True),3)
  self.assertEqual(a,before);self.assertTrue(d['qualityChecksSkipped']);self.assertNotIn('degenerateFaces',d)
 def test_bounds(self):
  a=m();a['uv2'][0]=-20;a['uv2'][-1]=200
  self.assertEqual(p.validate_uv2(a,skip_quality=True),2)
 def test_all_degenerate(self):
  a=m();a['uv2']=[0]*12;self.assertEqual(p.validate_uv2(a,skip_quality=True),2)
 def test_default_still_strict(self):
  with self.assertRaises(ValueError):p.validate_uv2(m())
 def test_legacy_skip_still_rejects_overlap(self):
  a=m();a['triangles']+=[0,1,2];a['faceMaterials']+=[0]
  with self.assertRaisesRegex(ValueError,'overlaps'):p.validate_uv2(a,skip_degenerate=True)
 def test_requirements(self):
  for mode in ['missing','length','nan','infinity','index']:
   a=m()
   if mode=='missing':a['uv2']=[]
   elif mode=='length':a['uv2']=a['uv2'][:-1]
   elif mode=='nan':a['uv2'][0]=float('nan')
   elif mode=='infinity':a['uv2'][0]=float('inf')
   else:a['triangles'][0]=999
   with self.subTest(mode=mode),self.assertRaises(ValueError):p.validate_uv2(a,skip_quality=True)
 def test_bool_type(self):
  r=dict(schema=1,id='a'*32,projectId='b'*24,revision='c'*32,sceneHash='d'*64,resolution=64,samples=1,margin=2,format='PNG',skipUV2Validation='false')
  with self.assertRaisesRegex(ValueError,'boolean'):p.validate_request(r)
if __name__=='__main__':unittest.main(verbosity=2)
