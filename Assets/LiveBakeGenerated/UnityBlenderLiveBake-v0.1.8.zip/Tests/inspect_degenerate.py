import json,math,sys
from pathlib import Path
root=Path(r'F:\UnityProject\pp_ta_unity\UnityProject\Library\UnityBlenderLiveBake')
manifest=json.loads((root/'scene.json').read_text(encoding='utf-8-sig'))
out=[]
for ob in manifest['objects']:
 m=json.loads((root/'meshes'/(ob['mesh']+'.json')).read_text(encoding='utf-8-sig'));uv=m.get('uv2') or [];verts=m['vertices'];bad=[]
 if not uv:out.append({'name':ob['name'],'missing':True});continue
 for j in range(0,len(m['triangles']),3):
  ids=m['triangles'][j:j+3];u=[uv[i*2:i*2+2] for i in ids];a=abs((u[1][0]-u[0][0])*(u[2][1]-u[0][1])-(u[1][1]-u[0][1])*(u[2][0]-u[0][0]))*.5
  if a<1e-12:
   v=[verts[i*3:i*3+3] for i in ids];x=[v[1][k]-v[0][k] for k in range(3)];y=[v[2][k]-v[0][k] for k in range(3)];cross=[x[1]*y[2]-x[2]*y[1],x[2]*y[0]-x[0]*y[2],x[0]*y[1]-x[1]*y[0]]
   bad.append({'face':j//3,'uv_area':a,'geometry_area_local':math.sqrt(sum(c*c for c in cross))*.5,'uv':u,'indices':ids})
 if bad:out.append({'name':ob['name'],'id':ob['id'],'mesh':ob['mesh'],'triangle_count':len(m['triangles'])//3,'bad_count':len(bad),'examples':bad[:3]})
print(json.dumps({'objects':len(manifest['objects']),'invalid_count':len(out),'invalid':out},ensure_ascii=False,indent=2))
