import unittest,importlib.util
from pathlib import Path
R=Path(__file__).resolve().parents[1];s=importlib.util.spec_from_file_location('protocol',R/'BlenderAddon/unity_live_bake/protocol.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
def m():return dict(schema=1,vertices=[0,0,0,1,0,0,0,1,0,2,0,0,3,0,0,2,1,0],triangles=[0,1,2,3,4,5],faceMaterials=[0,0],normals=[],uv0=[],uv2=[.1,.1,.4,.1,.1,.4,.8,.8,.8,.8,.9,.9],hasUV2=True)
class SkipTests(unittest.TestCase):
 def test_default_rejects(self):
  with self.assertRaisesRegex(ValueError,'degenerate'):p.validate_uv2(m())
 def test_skip_reports(self):
  d={};self.assertEqual(p.validate_uv2(m(),True,d),2);self.assertEqual(d['degenerateFaces'],1);self.assertEqual(d['sampleFaces'],[1]);self.assertEqual(d['validTriangles'],1)
 def test_no_modification(self):
  import copy
  a=m();b=copy.deepcopy(a);p.validate_uv2(a,True);self.assertEqual(a,b)
 def test_all_rejects(self):
  a=m();a['uv2']=[0]*12
  with self.assertRaisesRegex(ValueError,'All UV2'):p.validate_uv2(a,True)
 def test_missing(self):
  a=m();a['hasUV2']=False
  with self.assertRaisesRegex(ValueError,'Missing'):p.validate_uv2(a,True)
 def test_range(self):
  a=m();a['uv2'][-1]=2
  with self.assertRaisesRegex(ValueError,'0..1'):p.validate_uv2(a,True)
 def test_nonfinite(self):
  a=m();a['uv2'][-1]=float('nan')
  with self.assertRaises(ValueError):p.validate_uv2(a,True)
 def test_overlap_not_skipped(self):
  a=m();a['triangles'] += [0,1,2];a['faceMaterials'] += [0]
  with self.assertRaisesRegex(ValueError,'faces 0 and 2'):p.validate_uv2(a,True)
 def test_index_after_skipping(self):
  a=m();a['triangles']=[3,4,5,0,1,2,0,1,2];a['faceMaterials']=[0,0,0]
  with self.assertRaisesRegex(ValueError,'faces 1 and 2'):p.validate_uv2(a,True)
if __name__=='__main__':unittest.main(verbosity=2)
