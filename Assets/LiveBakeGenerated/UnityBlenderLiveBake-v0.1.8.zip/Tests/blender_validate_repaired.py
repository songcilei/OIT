import sys,time,uuid
from pathlib import Path
import bpy
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'BlenderAddon'))
from unity_live_bake import protocol as p,receiver,baker
root=R/'Tests/invalid-uv-exchange';bpy.ops.wm.read_factory_settings(use_empty=True)
m=p.load_json(root/'scene.json');checked=set();total=0
for ob in m['objects']:
 if ob['mesh'] in checked:continue
 data=p.load_json(root/'meshes'/(ob['mesh']+'.json'));start=time.time();n=p.validate_uv2(data);total+=n;checked.add(ob['mesh']);print('PASS: Blender strict UV2 validation after repair',ob['name'],n,'triangles',round(time.time()-start,2),'seconds',flush=True)
receiver.sync_scene(root);print('PASS: repaired mesh scene received with preserved material slots',flush=True)
world=bpy.data.worlds.new('RepairTest');world.use_nodes=True;world.node_tree.nodes['Background'].inputs[1].default_value=.5;bpy.context.scene.world=world
req=dict(schema=1,projectId=m['projectId'],id=uuid.uuid4().hex,revision=m['revision'],sceneHash=m['sceneHash'],resolution=64,samples=1,margin=2,format='PNG',includeGlossy=False)
session=baker.BakeSession(root,req)
while session.step():pass
result=p.load_json(root/'results/latest.json');assert result['status']=='complete' and not result['skippedDegenerateUV2'] and not result['warnings']
print('PASS: repaired real meshes complete strict Cycles bake with no bypass warnings',flush=True)
print('REPAIRED_REAL_UV2_BLENDER_PASSED',len(checked),total,flush=True)

