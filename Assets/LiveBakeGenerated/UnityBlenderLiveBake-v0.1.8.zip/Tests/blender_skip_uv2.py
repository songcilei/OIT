import sys,uuid,copy,hashlib,json
from pathlib import Path
import bpy
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'BlenderAddon'))
from unity_live_bake import protocol as p,receiver,baker
root=R/'Tests/skip-uv-exchange';root.mkdir(exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
mesh=dict(schema=1,id='a'*64,vertices=[0,0,0,1,0,0,0,0,1,2,0,0,3,0,0,2,0,1],triangles=[0,2,1,3,5,4],normals=[0,1,0]*6,faceMaterials=[0,0],uv0=[0,0,0,1,1,0]*2,uv2=[.1,.1,.4,.1,.1,.4,.8,.8,.8,.8,.9,.9],hasUV2=True)
mat=dict(id='b'*64,name='Plain',shader='Standard',color=[.8,.3,.1,1],emission=[0,0,0,1],tiling=[1,1,0,0],metallic=0,roughness=.5)
obj=dict(id='fake-scene-id',token='c'*24,name='PartialDegenerate',mesh=mesh['id'],sourceHash='d'*64,matrix=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],materials=[mat['id']],hasUV2=True)
m=dict(schema=1,projectId='e'*24,revision='f'*32,sceneHash='0'*64,objects=[obj],materials=[mat]);p.atomic_json(root/'meshes'/(mesh['id']+'.json'),mesh);p.atomic_json(root/'scene.json',m)
world=bpy.data.worlds.new('QA');world.use_nodes=True;world.node_tree.nodes['Background'].inputs[1].default_value=.6;bpy.context.scene.world=world
base=dict(schema=1,projectId=m['projectId'],id=uuid.uuid4().hex,revision=m['revision'],sceneHash=m['sceneHash'],resolution=64,samples=2,margin=2,format='PNG',includeGlossy=False)
try:baker.BakeSession(root,base);raise AssertionError('default should fail')
except ValueError as e:assert 'degenerate' in str(e)
print('PASS: default path rejects same partial-degenerate fixture',flush=True)
for mode in [False,True]:
 req=dict(base,id=uuid.uuid4().hex,skipDegenerateUV2=True,atlas=mode)
 session=baker.BakeSession(root,req);ob=next(o for o in bpy.context.scene.objects if o.get('ulb_id')==obj['id']);uv=[tuple(x.uv) for x in ob.data.uv_layers['UV2'].data];tri=len(ob.data.polygons)
 while session.step():pass
 result=p.load_json(root/'results/latest.json');assert result['status']=='complete';assert result['skippedDegenerateFaces']==1 and result['skippedDegenerateUV2'] and len(result['warnings'])==1
 assert len(ob.data.polygons)==tri==2 and [tuple(x.uv) for x in ob.data.uv_layers['UV2'].data]==uv
 print('PASS: real bake with bypass, warning persisted, geometry/UV unchanged; atlas='+str(mode),flush=True)
# Use a new mesh identifier so receiver does not reuse immutable cached geometry.
bad=copy.deepcopy(mesh);bad['id']='1'*64;bad['uv2']=[0]*12;p.atomic_json(root/'meshes'/(bad['id']+'.json'),bad);m['objects'][0]['mesh']=bad['id'];m['revision']=uuid.uuid4().hex;p.atomic_json(root/'scene.json',m)
req=dict(base,id=uuid.uuid4().hex,revision=m['revision'],skipDegenerateUV2=True)
try:baker.BakeSession(root,req);raise AssertionError('all-degenerate should fail')
except ValueError as e:assert 'All UV2' in str(e)
print('PASS: all-degenerate mesh still blocked with bypass enabled',flush=True)
print('SKIP_UV2_BLENDER_PASSED',flush=True)
