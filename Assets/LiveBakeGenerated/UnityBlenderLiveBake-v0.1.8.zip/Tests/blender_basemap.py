import sys,uuid
from pathlib import Path
import bpy
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'BlenderAddon'))
from unity_live_bake import protocol as p,receiver,baker
root=R/'Tests/basemap-exchange';bpy.ops.wm.read_factory_settings(use_empty=True)
for mode in ['base-off','base-on','dual-base','dual-main','dual-empty-main','dual-empty-base','blank','restored']:
 m=p.load_json(root/(mode+'.json'));p.atomic_json(root/'scene.json',m);receiver.sync_scene(root);rec=m['materials'][0]
 mat=next(x for x in bpy.data.materials if x.get('ulb_material')==rec['id']);node=next(n for n in mat.node_tree.nodes if n.type=='BSDF_PRINCIPLED')
 if rec['baseTexture']:
  image=node.inputs['Base Color'].links[0].from_node;assert image.type=='TEX_IMAGE' and Path(image.image.filepath).resolve()==(root/rec['baseTexture']).resolve()
  mapping=image.inputs['Vector'].links[0].from_node;assert abs(mapping.inputs['Scale'].default_value.x-rec['baseTextureTiling'][0])<1e-6
 else:assert not node.inputs['Base Color'].is_linked
 print('PASS: Blender BaseMap mapping '+mode,flush=True)
world=bpy.data.worlds.new('QA');world.use_nodes=True;world.node_tree.nodes['Background'].inputs[1].default_value=.5;bpy.context.scene.world=world
req=dict(schema=1,projectId=m['projectId'],id=uuid.uuid4().hex,revision=m['revision'],sceneHash=m['sceneHash'],resolution=64,samples=2,margin=2,format='PNG',includeGlossy=False)
s=baker.BakeSession(root,req)
while s.step():pass
assert p.load_json(root/'results/latest.json')['status']=='complete'
print('BASEMAP_BLENDER_PASSED',flush=True)
