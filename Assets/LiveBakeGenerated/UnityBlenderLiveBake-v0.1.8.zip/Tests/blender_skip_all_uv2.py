import sys,uuid,copy
from pathlib import Path
import bpy
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'BlenderAddon'))
from unity_live_bake import protocol as p,receiver,baker
root=R/'Tests/skip-all-exchange';root.mkdir(exist_ok=True);bpy.ops.wm.read_factory_settings(use_empty=True)
world=bpy.data.worlds.new('QA');world.use_nodes=True;world.node_tree.nodes['Background'].inputs[1].default_value=.5;bpy.context.scene.world=world
mesh=dict(schema=1,id='a'*64,vertices=[0,0,0,1,0,0,0,0,1,2,0,0,3,0,0,2,0,1],triangles=[0,2,1,3,5,4],normals=[0,1,0]*6,faceMaterials=[0,0],uv0=[0,0,0,1,1,0]*2,uv2=[.1,.1,.4,.1,.1,.4]*2,hasUV2=True)
mat=dict(id='b'*64,name='Plain',shader='Standard',color=[.8,.3,.1,1],emission=[0,0,0,1],tiling=[1,1,0,0],metallic=0,roughness=.5)
ob=dict(id='qa',token='c'*24,name='OverlapAndBounds',mesh=mesh['id'],sourceHash='d'*64,matrix=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],materials=[mat['id']],hasUV2=True)
m=dict(schema=1,projectId='e'*24,revision='f'*32,sceneHash='0'*64,objects=[ob],materials=[mat]);p.atomic_json(root/'meshes'/(mesh['id']+'.json'),mesh);p.atomic_json(root/'scene.json',m)
req=dict(schema=1,projectId=m['projectId'],id=uuid.uuid4().hex,revision=m['revision'],sceneHash=m['sceneHash'],resolution=64,samples=1,margin=2,format='PNG',includeGlossy=False)
try:baker.BakeSession(root,req);raise AssertionError('expected reject')
except ValueError as e:assert 'overlaps' in str(e)
for mode in [False,True]:
 request=dict(req,id=uuid.uuid4().hex,skipUV2Validation=True,atlas=mode);s=baker.BakeSession(root,request);obj=next(o for o in bpy.context.scene.objects if o.get('ulb_id')=='qa');before=[tuple(l.uv) for l in obj.data.uv_layers['UV2'].data]
 while s.step():pass
 result=p.load_json(root/'results/latest.json');assert result['status']=='complete' and result['skippedUV2Validation'] and result['warnings'] and not result['skippedDegenerateUV2'];assert len(obj.data.polygons)==2 and [tuple(l.uv) for l in obj.data.uv_layers['UV2'].data]==before
 print('PASS: actual overlap bake reaches completion with persistent risk; atlas='+str(mode),flush=True)
# Out-of-range and all-degenerate may still fail in Cycles itself; test startup accepts them without quality checks.
for char,uv,label in [('1',[-.1,.1,1.1,.1,.1,1.1]*2,'out-of-range'),('2',[0]*12,'all-degenerate')]:
 bad=copy.deepcopy(mesh);bad['id']=char*64;bad['uv2']=uv;p.atomic_json(root/'meshes'/(bad['id']+'.json'),bad);m['objects'][0]['mesh']=bad['id'];p.atomic_json(root/'scene.json',m)
 s=baker.BakeSession(root,dict(req,id=uuid.uuid4().hex,skipUV2Validation=True));assert s.warnings;s._finish('cancelled','QA startup only')
 print('PASS: bypass permits startup for '+label,flush=True)
print('SKIP_ALL_BLENDER_PASSED',flush=True)
