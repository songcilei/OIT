import importlib.util
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("protocol", ROOT/"BlenderAddon/unity_live_bake/protocol.py")
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)


def square():
    return dict(schema=1,vertices=[0,0,0,1,0,0,1,1,0,0,1,0],triangles=[0,1,2,0,2,3],faceMaterials=[0,0],uv0=[],normals=[],hasUV2=True,uv2=[.1,.1,.9,.1,.9,.9,.1,.9])


class ProtocolTests(unittest.TestCase):
    def test_shared_edge_not_overlap(self):
        self.assertEqual(p.validate_uv2(square()),2)
    def test_duplicate_overlap(self):
        m=square();m['triangles']=[0,1,2,0,1,2]
        with self.assertRaisesRegex(ValueError,"overlaps"):p.validate_uv2(m)
    def test_reverse_duplicate_overlap(self):
        m=square();m['triangles']=[0,1,2,2,1,0]
        with self.assertRaisesRegex(ValueError,"overlaps"):p.validate_uv2(m)
    def test_zero_uv(self):
        m=square();m['uv2']=[0]*8
        with self.assertRaisesRegex(ValueError,"degenerate"):p.validate_uv2(m)
    def test_missing_uv(self):
        m=square();m['hasUV2']=False
        with self.assertRaisesRegex(ValueError,"Missing"):p.validate_uv2(m)
    def test_tiled_uv(self):
        m=square();m['uv2'][0]=1.5
        with self.assertRaisesRegex(ValueError,"0..1"):p.validate_uv2(m)
    def test_finite(self):
        m=square();m['vertices'][0]=float('nan')
        with self.assertRaises(ValueError):p.validate_mesh(m)
    def test_index(self):
        m=square();m['triangles'][0]=8
        with self.assertRaises(ValueError):p.validate_mesh(m)
    def test_path_traversal(self):
        with tempfile.TemporaryDirectory() as d:
            for path in ['../secret','../../x','C:/secret','/secret']:
                with self.assertRaises(ValueError):p.contained(d,path)
            self.assertEqual(p.contained(d,'results/test.png'),Path(d).resolve()/'results/test.png')
    def test_atomic_and_utf8(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'sub'/'test.json';p.atomic_json(f,{'中文':'test'});p.atomic_json(f,{'中文':'new'});self.assertEqual(p.load_json(f),{'中文':'new'})
            self.assertFalse(list(f.parent.glob('*.tmp')))
    def test_overlap_area(self):
        a=((0,0),(1,0),(0,1));b=((.1,.1),(.2,.1),(.1,.2));self.assertAlmostEqual(p.intersection_area(a,b),.005)
    def test_invalid_request(self):
        with self.assertRaises(ValueError):p.validate_request({'schema':99})

if __name__=='__main__':unittest.main(verbosity=2)
