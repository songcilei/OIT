using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using LiveBakeBridge;
using LiveBakeBridge.Editor;
public static class URPProof {
    static string output=Environment.GetEnvironmentVariable("ULB_TEST_OUTPUT") ?? Path.GetFullPath("../");
    public static void Run(){try{
        EditorSceneManager.OpenScene("Assets/Fixture.unity");PlayerSettings.colorSpace=ColorSpace.Linear;
        var renderer=ScriptableObject.CreateInstance<UniversalRendererData>();AssetDatabase.CreateAsset(renderer,"Assets/QARenderer.asset");
        var asset=UniversalRenderPipelineAsset.Create(renderer);AssetDatabase.CreateAsset(asset,"Assets/QAPipeline.asset");asset.msaaSampleCount=1;
        GraphicsSettings.renderPipelineAsset=asset;QualitySettings.renderPipeline=asset;
        var go=new GameObject("URP Proof Camera");var cam=go.AddComponent<Camera>();go.AddComponent<UniversalAdditionalCameraData>().renderPostProcessing=false;cam.transform.position=new Vector3(7,6,-9);cam.transform.LookAt(new Vector3(1,.3f,0));cam.orthographic=true;cam.orthographicSize=3.15f;cam.clearFlags=CameraClearFlags.SolidColor;cam.backgroundColor=new Color(.18f,.22f,.26f);cam.allowHDR=false;
        var rt=new RenderTexture(1000,700,24,RenderTextureFormat.ARGB32,RenderTextureReadWrite.sRGB);rt.Create();
        cam.targetTexture=rt;cam.Render();
        var req=new UniversalRenderPipeline.SingleCameraRequest{destination=rt};RenderPipeline.SubmitRenderRequest(cam,req);
        var prev=RenderTexture.active;RenderTexture.active=rt;var image=new Texture2D(1000,700,TextureFormat.RGB24,false);image.ReadPixels(new Rect(0,0,1000,700),0,0);image.Apply();File.WriteAllBytes(Path.Combine(output,"unity-urp-baked-unlit.png"),image.EncodeToPNG());RenderTexture.active=prev;
        var pix=image.GetPixels32();int colors=pix.Where(c=>c.r>c.b*2&&c.r>c.g*1.5f).Count();if(colors<100)throw new Exception("URP render did not show baked color textures");Debug.Log("PASS: UV2 Unlit renders under URP 14, red pixel count="+colors);
        cam.targetTexture=null;rt.Release();UnityEngine.Object.DestroyImmediate(go);
        BakeImporter.RestoreAllLoaded();var mat=new Material(Shader.Find("Universal Render Pipeline/Lit"));mat.SetColor("_BaseColor",new Color(.4f,.7f,.2f));mat.SetFloat("_Smoothness",.3f);AssetDatabase.CreateAsset(mat,"Assets/URPSource.mat");foreach(var rr in UnityEngine.Object.FindObjectsOfType<MeshRenderer>())rr.sharedMaterial=mat;
        var root=GameObject.Find("SyncRoot");var s=BridgeSettings.instance;s.folder=Path.Combine(output,"urp-exchange");s.rootIds=new[]{BridgeIO.Id(root)};s.autoImport=false;s.liveSync=false;s.Persist();var manifest=SceneExporter.Export(true);if(manifest.objects.Length!=3||manifest.materials.Any(m=>m.shader!="Universal Render Pipeline/Lit"))throw new Exception("URP source export failed");Debug.Log("PASS: URP Lit material source export");
        Debug.Log("URP_PROOF_PASSED");EditorApplication.Exit(0);
    }catch(Exception e){Debug.LogException(e);EditorApplication.Exit(1);}}
}

