using System;
using System.IO;
using UnityEditor;
using UnityEngine;
using LiveBakeBridge.Editor;
public static class ProgressRegression {
 static void Check(bool b,string m){if(!b)throw new Exception("FAIL: "+m);Debug.Log("PASS: "+m);}
 public static void Run(){try{
  var req=new BakeRequest{projectId="p",id="new",queuedAt=100,objectCount=6};
  var status=new BridgeStatus{projectId="p",requestId="new",state="baking",done=2,total=6,message="Baking Plane",unixTime=110};
  var v=BakeProgress.Evaluate(req,status,null,null,"p","",120,100,0);
  Check(v.phase=="baking"&&v.done==2&&v.total==6&&Math.Abs(v.Fraction-1f/3)<.001&&v.currentObject=="Plane","2/6 displays actual object progress and current Plane");
  Check(v.elapsed==20,"elapsed starts at submitted time");
  var stale=BakeProgress.Evaluate(req,status,null,null,"p","",220,100,0);Check(stale.phase=="baking"&&stale.Fraction==v.Fraction&&stale.warning.Contains("不能据此判定失败"),"blocking object heartbeat doesn't fake percent or fail");
  var old=new BakeResult{projectId="p",id="old",status="complete",items=new BakeItem[99]};
  status.requestId="old";v=BakeProgress.Evaluate(req,status,old,null,"p","old",120,100,111);Check(v.phase=="queued"&&v.done==0&&v.total==6,"old batch status and result ignored");
  status.requestId="new";var result=new BakeResult{projectId="p",id="new",status="complete",items=new BakeItem[6]};
  v=BakeProgress.Evaluate(req,status,result,null,"p","",200,100,150);Check(v.phase=="awaiting_import"&&v.done==6&&v.elapsed==50,"complete result overrides baking status; stops bake timer");
  var imp=new BakeImportProgress{projectId="p",requestId="new",state="importing",done=3,total=6,updatedAt=160};
  v=BakeProgress.Evaluate(req,status,result,imp,"p","",170,100,150);Check(v.phase=="importing"&&v.done==3&&v.elapsed==70,"separate truthful import phase");
  imp.state="failed";imp.message="Scene changed";v=BakeProgress.Evaluate(req,status,result,imp,"p","",220,100,150);Check(v.phase=="import_failed"&&v.warning=="Scene changed"&&v.elapsed==60,"import failure visible and stable after successful bake");
  imp.state="complete";imp.updatedAt=180;v=BakeProgress.Evaluate(req,status,result,imp,"p","new",220,100,150);Check(v.phase=="complete"&&v.Fraction==1&&v.elapsed==80,"final imported success and fixed duration");
  result.status="failed";result.error="UV overlap";v=BakeProgress.Evaluate(req,status,result,null,"p","",220,100,150);Check(v.phase=="failed"&&v.warning=="UV overlap","bake error displayed");
  result.status="cancelled";v=BakeProgress.Evaluate(req,status,result,null,"p","",220,100,150);Check(v.phase=="cancelled","cancellation displayed");
  req.queuedAt=0;v=BakeProgress.Evaluate(req,null,null,null,"p","",130,100,0);Check(v.elapsed==30,"old Blender/old request uses file time fallback");
  req.projectId="other";v=BakeProgress.Evaluate(req,status,result,null,"p","",220,100,150);Check(!v.hasTask,"foreign project ignored");
  Check(BakeProgress.Duration(3661)=="1:01:01","long elapsed formatting");
  var w=EditorWindow.GetWindow<LiveBakeWindow>("Blender Live Bake");w.Repaint();w.Close();Check(true,"updated progress window instantiates");
  Debug.Log("PROGRESS_REGRESSION_PASSED");EditorApplication.Exit(0);
 }catch(Exception e){Debug.LogException(e);EditorApplication.Exit(1);}}
 public static void AsyncFailure(){
  try {
   var settings=BridgeSettings.instance;settings.liveSync=false;settings.autoImport=false;settings.rootIds=Array.Empty<string>();settings.folder=Path.GetFullPath("../../Tests/progress-async-exchange");settings.Persist();
   string id=Guid.NewGuid().ToString("N");
   BridgeIO.Json(Path.Combine(settings.Folder,"results","latest.json"),new BakeResult{schema=1,projectId=BridgeIO.ProjectId,id=id,status="complete",format="PNG",sceneHash="deliberately-stale",items=Array.Empty<BakeItem>()});
   BakeProgress.ScheduleImport();Check(BakeProgress.PendingImport==id,"import queued before blocking asset processing");
   var state=BridgeIO.Read<BakeImportProgress>(Path.Combine(settings.Folder,"unity-import-progress.json"));Check(state.state=="importing","importing status published before processing");
   double deadline=EditorApplication.timeSinceStartup+30;EditorApplication.CallbackFunction check=null;
   check=()=>{
    if(BakeProgress.PendingImport!=null&&EditorApplication.timeSinceStartup<deadline)return;
    EditorApplication.update-=check;
    try {
     Check(BakeProgress.PendingImport==null&&!BridgeService.Busy,"async import clears busy state after failure");
     var failure=BridgeIO.Read<BakeImportProgress>(Path.Combine(settings.Folder,"unity-import-progress.json"));Check(failure.requestId==id&&failure.state=="failed"&&failure.message.Contains("Scene changed"),"actual stale import error persisted");
     Check(!BakeProgress.CanAutoImport(settings.Folder,id),"failed batch will not auto-retry on reload");
     Check(BakeProgress.CanAutoImport(settings.Folder,"new-request"),"new batch not blocked by old failure");
     Debug.Log("PROGRESS_ASYNC_PASSED");EditorApplication.Exit(0);
    }catch(Exception e){Debug.LogException(e);EditorApplication.Exit(1);}
   };EditorApplication.update+=check;
  }catch(Exception e){Debug.LogException(e);EditorApplication.Exit(1);}
 }}

