using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using LiveBakeBridge;
using LiveBakeBridge.Editor;
public static class BridgeIntegrationTest {
    static void Check(bool condition,string message){if(!condition)throw new Exception("TEST FAILED: "+message);Debug.Log("PASS: "+message);}
    public static void ExportFixture() {
        try {
            PlayerSettings.colorSpace=ColorSpace.Linear;
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
            var root=new GameObject("SyncRoot");
            var primitive=GameObject.CreatePrimitive(PrimitiveType.Cube);var cube=UnityEngine.Object.Instantiate(primitive.GetComponent<MeshFilter>().sharedMesh);UnityEngine.Object.DestroyImmediate(primitive);
            cube.name="FixtureCube";Unwrapping.GenerateSecondaryUVSet(cube);AssetDatabase.CreateAsset(cube,"Assets/FixtureCube.asset");
            var tex=new Texture2D(4,4,TextureFormat.RGBA32,false);var pixels=new Color[16];for(int y=0;y<4;y++)for(int x=0;x<4;x++)pixels[y*4+x]=(x<2?(y<2?Color.red:Color.blue):(y<2?Color.green:Color.yellow));tex.SetPixels(pixels);tex.Apply();File.WriteAllBytes("Assets/Source.png",tex.EncodeToPNG());AssetDatabase.ImportAsset("Assets/Source.png",ImportAssetOptions.ForceSynchronousImport);
            var ti=(TextureImporter)AssetImporter.GetAtPath("Assets/Source.png");ti.isReadable=false;ti.sRGBTexture=true;ti.textureCompression=TextureImporterCompression.Uncompressed;ti.SaveAndReimport();
            var mat=new Material(Shader.Find("Standard"));mat.name="Fixture Standard";mat.SetTexture("_MainTex",AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Source.png"));mat.SetColor("_Color",new Color(.8f,.9f,1,1));mat.SetFloat("_Glossiness",.2f);AssetDatabase.CreateAsset(mat,"Assets/Source.mat");
            var template=new GameObject("FixturePrefab");template.AddComponent<MeshFilter>().sharedMesh=cube;template.AddComponent<MeshRenderer>().sharedMaterial=mat;var prefab=PrefabUtility.SaveAsPrefabAsset(template,"Assets/FixturePrefab.prefab");UnityEngine.Object.DestroyImmediate(template);
            for(int i=0;i<2;i++) {var g=(GameObject)PrefabUtility.InstantiatePrefab(prefab,root.transform);g.name="Box "+i;g.transform.position=new Vector3(i*2,0.5f,0);g.transform.rotation=Quaternion.Euler(0,i*27,0);g.transform.localScale=i==0?Vector3.one:new Vector3(-1,1.4f,1);}
            var floor=new GameObject("Floor");floor.transform.SetParent(root.transform);floor.transform.position=new Vector3(1,-.15f,0);floor.transform.localScale=new Vector3(7,.2f,5);floor.AddComponent<MeshFilter>().sharedMesh=cube;var floorMat=new Material(Shader.Find("Standard"));floorMat.color=new Color(.6f,.6f,.6f);AssetDatabase.CreateAsset(floorMat,"Assets/Floor.mat");floor.AddComponent<MeshRenderer>().sharedMaterial=floorMat;
            EditorSceneManager.SaveScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene(),"Assets/Fixture.unity");
            var settings=BridgeSettings.instance;settings.folder=Path.GetFullPath("../../exchange");settings.rootIds=new[]{BridgeIO.Id(root)};settings.liveSync=false;settings.autoImport=false;settings.Persist();
            var a=SceneExporter.Export(true);Check(a.objects.Length==3,"3 instance export");Check(a.objects.Select(o=>o.mesh).Distinct().Count()==1,"mesh data deduplicated");
            var count=Directory.GetFiles(Path.Combine(settings.Folder,"meshes")).Length;
            var b=SceneExporter.Export();Check(a.revision==b.revision,"unchanged scene no rewrite");
            root.transform.GetChild(0).position+=Vector3.right*.25f;var moved=SceneExporter.Export();Check(moved.revision!=a.revision,"transform increments revision");Check(Directory.GetFiles(Path.Combine(settings.Folder,"meshes")).Length==count,"transform does not re-export mesh");
            root.transform.GetChild(1).gameObject.SetActive(false);Check(SceneExporter.Export().objects.Length==2,"disabled instance removed from manifest");root.transform.GetChild(1).gameObject.SetActive(true);
            cube.UploadMeshData(true);SceneExporter.Invalidate();var final=SceneExporter.Export(true);Check(final.objects.Length==3,"non-readable mesh export");
            EditorSceneManager.SaveScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene());
            foreach(var name in new[]{"LiveBakeBridge/UV2 Unlit","Hidden/LiveBakeBridge/TextureExport"}){var sh=Shader.Find(name);Check(sh!=null,"shader exists "+name);Check(!ShaderUtil.GetShaderMessages(sh).Any(m=>m.severity==UnityEditor.Rendering.ShaderCompilerMessageSeverity.Error),"shader compiles "+name);}
            var request=new BakeRequest{projectId=final.projectId,id=Guid.NewGuid().ToString("N"),revision=final.revision,sceneHash=final.sceneHash,resolution=512,samples=16,margin=8,format="PNG",includeGlossy=true};BridgeIO.Json(Path.Combine(settings.Folder,"requests","bake.json"),request);
            Debug.Log("FIXTURE_EXPORTED "+settings.Folder);EditorApplication.Exit(0);
        } catch(Exception e){Debug.LogException(e);EditorApplication.Exit(1);}
    }
    public static void ImportFixture() {
        try {
            EditorSceneManager.OpenScene("Assets/Fixture.unity");var s=BridgeSettings.instance;Check(s.folder==Path.GetFullPath("../../exchange"),"settings survive editor restart");s.liveSync=false;s.autoImport=false;
            int n=BakeImporter.ImportLatest();Check(n==3,"bake imports for all instances");
            var bindings=UnityEngine.Object.FindObjectsOfType<LiveBakeBinding>();Check(bindings.Length==3,"original materials preserved on instances");Check(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/FixturePrefab.prefab").GetComponent<Renderer>().sharedMaterial.shader.name=="Standard","source Prefab material not modified");
            Check(bindings.Select(x=>x.GetComponent<Renderer>().sharedMaterial).Distinct().Count()==3,"per-instance baked materials are unique");
            var scene=SceneExporter.Export(true);var result=BridgeIO.Read<BakeResult>(Path.Combine(s.Folder,"results","latest.json"));Check(scene.sceneHash==result.sceneHash,"export after apply still uses original materials");
            var first=bindings[0];first.transform.position+=Vector3.right;bool rejected=false;try{BakeImporter.ImportLatest();}catch(InvalidOperationException){rejected=true;}Check(rejected,"stale result rejected after transform edit");first.transform.position-=Vector3.right;
            Check(BakeImporter.RestoreAllLoaded()==3,"restore materials on all instances");Check(bindings.All(x=>x.GetComponent<Renderer>().sharedMaterial.shader.name=="Standard"),"restored Standard materials");
            BakeImporter.ImportLatest();EditorSceneManager.SaveScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene());var cameraGo=new GameObject("Proof camera");var camera=cameraGo.AddComponent<Camera>();camera.transform.position=new Vector3(7,6,-9);camera.transform.LookAt(new Vector3(1,.3f,0));camera.orthographic=true;camera.orthographicSize=3.15f;camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=new Color(.18f,.22f,.26f);camera.allowHDR=false;camera.allowMSAA=false;
            var rt=new RenderTexture(1000,700,24,RenderTextureFormat.ARGB32,RenderTextureReadWrite.sRGB);camera.targetTexture=rt;camera.Render();var old=RenderTexture.active;RenderTexture.active=rt;var cpu=new Texture2D(1000,700,TextureFormat.RGB24,false);cpu.ReadPixels(new Rect(0,0,1000,700),0,0);cpu.Apply();File.WriteAllBytes(Path.GetFullPath("../unity-baked-unlit.png"),cpu.EncodeToPNG());RenderTexture.active=old;camera.targetTexture=null;rt.Release();UnityEngine.Object.DestroyImmediate(cpu);UnityEngine.Object.DestroyImmediate(rt);UnityEngine.Object.DestroyImmediate(cameraGo);
            Debug.Log("ROUNDTRIP_PASSED");EditorApplication.Exit(0);
        }catch(Exception e){Debug.LogException(e);EditorApplication.Exit(1);}
    }
}



