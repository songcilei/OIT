import sys,uuid,copy,hashlib,json
from pathlib import Path
import numpy as np
import bpy
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'BlenderAddon'))
from unity_live_bake import protocol as p,receiver,baker,atlas
bpy.ops.wm.read_factory_settings(use_empty=True)
source=R/'Tests/atlas-exchange';root=R/'Tests/atlas-multimaterial-exchange';root.mkdir(exist_ok=True)
m=p.load_json(source/'scene.json');newmesh={};materials=[]
for i,em in enumerate(([1.,.005,.005,1.],[.005,1.,.005,1.])):
 mat=copy.deepcopy(m['materials'][0]);mat.update(id=hashlib.sha256(str(em).encode()).hexdigest(),name='Emission '+str(i),color=[0.,0.,0.,1.],emission=em,metallic=0.,roughness=1.)
 for key in ('baseTexture','normalTexture','metallicTexture','occlusionTexture','emissionTexture'):mat[key]=None
 materials.append(mat)
for obj in m['objects']:
 old=obj['mesh']
 if old not in newmesh:
  mesh=p.load_json(source/'meshes'/(old+'.json'));mesh['faceMaterials']=[i%2 for i in range(len(mesh['faceMaterials']))];mesh['id']=hashlib.sha256(json.dumps(mesh,sort_keys=True).encode()).hexdigest();p.atomic_json(root/'meshes'/(mesh['id']+'.json'),mesh);newmesh[old]=mesh['id']
 obj['mesh']=newmesh[old];obj['materials']=[mat['id'] for mat in materials];obj['sourceHash']=hashlib.sha256(json.dumps(obj,sort_keys=True).encode()).hexdigest()
m['materials']=materials;m['revision']=uuid.uuid4().hex;m['sceneHash']=hashlib.sha256(json.dumps(m,sort_keys=True).encode()).hexdigest();p.atomic_json(root/'scene.json',m)
req=dict(schema=1,projectId=m['projectId'],id=uuid.uuid4().hex,revision=m['revision'],sceneHash=m['sceneHash'],resolution=512,samples=2,margin=4,format='PNG',includeGlossy=False,atlas=True)
s=baker.BakeSession(root,req)
while s.step():pass
result=p.load_json(root/'results/latest.json');assert result['status']=='complete' and result['atlas']
im=bpy.data.images.load(str(root/result['items'][0]['image']));pix=np.empty(512*512*4,dtype=np.float32);im.pixels.foreach_get(pix);pix=pix.reshape(512,512,4)
for entry in atlas.layout(3,512,4):
 x,y,w,h=entry['content'];tile=pix[y:y+h,x:x+w,:3];red=np.sum((tile[:,:,0]>.1)&(tile[:,:,0]>tile[:,:,1]*2));green=np.sum((tile[:,:,1]>.1)&(tile[:,:,1]>tile[:,:,0]*2));assert red>100 and green>100,(red,green)
print('PASS: every atlas tile includes both submesh materials; no last-slot overwrite',flush=True)
print('ATLAS_MULTIMATERIAL_PASSED',flush=True)
