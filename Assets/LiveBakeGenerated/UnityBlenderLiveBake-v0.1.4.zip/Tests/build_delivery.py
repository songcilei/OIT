import json, zipfile, tarfile, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
DIST=ROOT/'dist';DIST.mkdir(exist_ok=True)
VERSION=json.loads((ROOT/'UnityPackage/package.json').read_text(encoding='utf-8-sig'))['version']
# Include only source in the add-on, never Blender Python bytecode/cache files.
addon=DIST/f'unity_live_bake-{VERSION}.zip'
with zipfile.ZipFile(addon,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted((ROOT/'BlenderAddon/unity_live_bake').glob('*.py')):
  z.write(p,'unity_live_bake/'+p.name)
package=DIST/f'com.local.unity-blender-live-bake-{VERSION}.tgz'
with tarfile.open(package,'w:gz') as tar:
 for p in sorted((ROOT/'UnityPackage').rglob('*')):
  if p.is_file():tar.add(p,arcname='package/'+p.relative_to(ROOT/'UnityPackage').as_posix(),recursive=False)
# Sanitize test output by copying only explicit markers.
markers=[]
for name in ['unity-export.log','blender-roundtrip.log','unity-import.log','blender-extended.log','blender-transforms.log','unity-urp.log','uv2-repair-unity.log','uv2-repair-blender.log','progress-unity.log','progress-async-unity.log','atlas-prepare.log','atlas-blender.log','atlas-import.log','atlas-urp.log','atlas-multimaterial.log','maintex-unity.log','maintex-blender.log']:
 path=ROOT/'Tests'/name
 if path.exists():
  markers.append('=== '+name+' ===')
  for line in path.read_text(encoding='utf-8',errors='replace').splitlines():
   if line.startswith('PASS:') or any(k in line for k in ['ROUNDTRIP_PASSED','EXTENDED_TESTS_PASSED','TRANSFORM_TESTS_PASSED','URP_PROOF_PASSED','UV2_REPAIR_REGRESSION_PASSED','UV2_REPAIR_BLENDER_BAKE_PASSED','PROGRESS_REGRESSION_PASSED','PROGRESS_ASYNC_PASSED','ATLAS_PREPARE_PASSED','ATLAS_BLENDER_TESTS_PASSED','ATLAS_UNITY_IMPORT_PASSED','ATLAS_URP_PASSED','ATLAS_MULTIMATERIAL_PASSED','MAINTEX_UNITY_PASSED','MAINTEX_BLENDER_PASSED']):markers.append(line)
(ROOT/'Tests/test-summary.txt').write_text('\n'.join(markers)+'\n',encoding='utf-8')
bundle=DIST/f'UnityBlenderLiveBake-v{VERSION}.zip'
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED) as z:
 for directory in ['UnityPackage','BlenderAddon','Docs']:
  for p in sorted((ROOT/directory).rglob('*')):
   if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':z.write(p,p.relative_to(ROOT).as_posix())
 z.write(ROOT/'README_使用说明.md','README_使用说明.md')
 for p in sorted((ROOT/'Tests').iterdir()):
  if p.is_file() and not p.name.startswith('patch_') and p.suffix in ['.py','.cs','.png','.txt','.md']:z.write(p,p.relative_to(ROOT).as_posix())
 for p in [addon,package]:z.write(p,'dist/'+p.name)
report=[]
for p in [addon,package,bundle]:
 with open(p,'rb') as f:sha=hashlib.sha256(f.read()).hexdigest()
 report.append(dict(file=p.name,bytes=p.stat().st_size,sha256=sha))
 # Assert expected install entry exists inside the delivery.
 if p.suffix=='.zip':
  with zipfile.ZipFile(p) as z:assert z.testzip() is None
(DIST/'checksums.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))




