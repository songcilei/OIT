import sys,uuid
from pathlib import Path
import bpy
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'BlenderAddon'))
from unity_live_bake import protocol as p,receiver,baker
root=R/'Tests/maintex-exchange';bpy.ops.wm.read_factory_settings(use_empty=True)
for mode in ['normal','override','missing','custom','normal-again']:
 m=p.load_json(root/(mode+'.json'));p.atomic_json(root/'scene.json',m);receiver.sync_scene(root)
 for rec in m['materials']:
  mat=next(x for x in bpy.data.materials if x.get('ulb_material')==rec['id']);nt=mat.node_tree;bsdf=next(n for n in nt.nodes if n.type=='BSDF_PRINCIPLED')
  if rec.get('directBaseTexture'):
   src=bsdf.inputs['Base Color'].links[0].from_node;assert src.type=='TEX_IMAGE' and src.label=='baseTexture'
   mapping=src.inputs['Vector'].links[0].from_node;st=rec['baseTextureTiling'];assert abs(mapping.inputs['Scale'].default_value.x-st[0])<1e-6 and abs(mapping.inputs['Location'].default_value.y-st[3])<1e-6
   assert Path(src.image.filepath).resolve()==(root/rec['baseTexture']).resolve()
   if rec.get('smoothnessTexture'):
    smooth=next(n for n in nt.nodes if n.type=='TEX_IMAGE' and n.label=='smoothnessTexture');assert smooth.inputs['Vector'].links[0].from_node!=mapping
  elif rec.get('baseTexture'):assert bsdf.inputs['Base Color'].links[0].from_node.type=='MIX_RGB'
 print('PASS: Blender material links and texture mapping correct:',mode,flush=True)
# Renderable bake on override snapshot, ensures new nodes are actually usable by Cycles.
m=p.load_json(root/'override.json');p.atomic_json(root/'scene.json',m);receiver.sync_scene(root)
world=bpy.data.worlds.new('MainTexQA');world.use_nodes=True;world.node_tree.nodes['Background'].inputs[1].default_value=.5;bpy.context.scene.world=world
req=dict(schema=1,projectId=m['projectId'],id=uuid.uuid4().hex,revision=m['revision'],sceneHash=m['sceneHash'],resolution=64,samples=2,margin=2,format='PNG',includeGlossy=False)
s=baker.BakeSession(root,req)
while s.step():pass
assert p.load_json(root/'results/latest.json')['status']=='complete'
print('PASS: override material completes actual Cycles UV2 bake',flush=True)
print('MAINTEX_BLENDER_PASSED',flush=True)
