import importlib.util
import unittest
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'BlenderAddon/unity_live_bake/atlas.py'
spec=importlib.util.spec_from_file_location('atlas',p);atlas=importlib.util.module_from_spec(spec);spec.loader.exec_module(atlas)
class AtlasTests(unittest.TestCase):
 def test_layout_counts(self):
  for count in [1,2,3,6,9,10,50]:
   a=atlas.layout(count,2048,16);self.assertEqual(len(a),count);self.assertEqual(a,atlas.layout(count,2048,16))
   for i,entry in enumerate(a):
    sx,sy,ox,oy=entry['scaleOffset'];self.assertTrue(0<ox<ox+sx<1 and 0<oy<oy+sy<1)
    x,y,r,t=entry['cell'];cx,cy,w,h=entry['content'];self.assertGreaterEqual(cx-x,18);self.assertGreaterEqual(r-(cx+w),18)
    for other in a[:i]:
     xx,yy,rr,tt=other['cell'];self.assertTrue(r<=xx or rr<=x or t<=yy or tt<=y)
 def test_texel_centers(self):
  for a in atlas.layout(6,512,8):
   sx,sy,ox,oy=a['scaleOffset'];x,y,w,h=a['content'];self.assertAlmostEqual(ox*512,x+.5);self.assertAlmostEqual((ox+sx)*512,x+w-.5)
 def test_insufficient_capacity(self):
  with self.assertRaises(ValueError):atlas.layout(100,256,32)
 def test_invalid(self):
  for args in [(0,512,8),(-1,512,8),(3,513,8),(1,512,-1),(1,512,65)]:
   with self.assertRaises(ValueError):atlas.layout(*args)
if __name__=='__main__':unittest.main(verbosity=2)
