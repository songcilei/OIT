import sys, math
from pathlib import Path
import bpy
from mathutils import Matrix, Vector, Euler
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'BlenderAddon'))
from unity_live_bake import receiver,protocol as p
bpy.ops.wm.read_factory_settings(use_empty=True)
m=receiver.sync_scene(R/'exchange');coll=receiver.collection_for(bpy.context.scene,m['projectId']);ob=list(coll.objects)[0];base=ob.data
original=[v.co.copy() for v in base.vertices]
for sign in [1,-1]:
 u=Matrix.Translation(Vector((3,2,1))) @ Euler((.2,.3,.1)).to_matrix().to_4x4() @ Matrix.Diagonal((2,sign*1.3,.6,1)) @ Euler((.3,.8,0)).to_matrix().to_4x4()
 vals=[v for row in u for v in row];world=receiver.unity_matrix(vals)
 receiver.assign_transform(ob,base,vals);bpy.context.view_layer.update()
 assert ob.data.get('ulb_shear')
 for v,source in zip(ob.data.vertices,original):assert (ob.matrix_world@v.co-world@source).length<1e-5
 for face in ob.data.polygons:
  assert face.normal.dot(ob.data.corner_normals[face.loop_start].vector)>.99
 print('PASS: inherited shear and normals, determinant sign',sign,flush=True)
print('TRANSFORM_TESTS_PASSED',flush=True)
