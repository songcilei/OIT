from pathlib import Path
import sys, uuid
import bpy
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'BlenderAddon'))
from unity_live_bake import protocol as p, receiver, baker
root=R/'Tests/uv2-repair-exchange'
bpy.ops.wm.read_factory_settings(use_empty=True)
m=receiver.sync_scene(root)
for mid in {o['mesh'] for o in m['objects']}:
 data=p.load_json(root/'meshes'/(mid+'.json'));n=p.validate_uv2(data);print('PASS: Unity-generated UV2 validates without overlap, triangles',n,flush=True)
world=bpy.data.worlds.new('Test');world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(1,1,1,1);world.node_tree.nodes['Background'].inputs[1].default_value=.5;bpy.context.scene.world=world
req=dict(schema=1,projectId=m['projectId'],id=uuid.uuid4().hex,revision=m['revision'],sceneHash=m['sceneHash'],resolution=64,samples=1,margin=2,format='PNG',includeGlossy=False)
session=baker.BakeSession(root,req)
while session.step():pass
result=p.load_json(root/'results/latest.json');assert result['status']=='complete' and len(result['items'])==4
print('UV2_REPAIR_BLENDER_BAKE_PASSED',flush=True)
