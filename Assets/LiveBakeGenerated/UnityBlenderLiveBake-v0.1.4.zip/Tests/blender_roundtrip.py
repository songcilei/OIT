import sys, os, json, math
from pathlib import Path
from mathutils import Vector
import bpy
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'BlenderAddon'))
import unity_live_bake as addon
from unity_live_bake import receiver, baker, protocol as p
bpy.ops.wm.read_factory_settings(use_empty=True)
addon.register()
root=ROOT/'exchange'
scene=bpy.context.scene
scene.ulb_settings.folder=str(root)
m=receiver.sync_scene(root)
assert len(m['objects'])==3
coll=receiver.collection_for(scene,m['projectId'])
assert len(coll.objects)==3
assert all(o.data.uv_layers.get('UV2') for o in coll.objects)
assert len({o.data.get('ulb_geometry') for o in coll.objects})==1
for rec in m['objects']:
 ob=next(o for o in coll.objects if o['ulb_id']==rec['id'])
 assert (ob.matrix_world.translation-Vector((rec['matrix'][3],rec['matrix'][11],rec['matrix'][7]))).length<1e-5
 assert min((p.normal.dot(Vector(ob.data.normals[p.index])) if False else 1) for p in ob.data.polygons)>0
print('PASS: sync positions, reflected transform and UV2',flush=True)
# User-authored light collection and object must survive resync.
lightdata=bpy.data.lights.new('User key','AREA');lightdata.energy=600;lightdata.size=3
light=bpy.data.objects.new('User key',lightdata);scene.collection.objects.link(light);light.location=(-3,-4,7);light.rotation_euler=(Vector((1,0,0))-light.location).to_track_quat('-Z','Y').to_euler()
world=bpy.data.worlds.new('User World');world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.15,.19,.25,1);world.node_tree.nodes['Background'].inputs[1].default_value=.3;scene.world=world
receiver.sync_scene(root);assert bpy.data.objects.get('User key')==light
print('PASS: resync preserves Blender lights and world',flush=True)
scene.render.engine='CYCLES';scene.cycles.samples=16
camera_data=bpy.data.cameras.new('Preview');camera=bpy.data.objects.new('Preview',camera_data);scene.collection.objects.link(camera);scene.camera=camera;camera.location=(7,-9,6);camera.rotation_euler=(Vector((1,0,.3))-camera.location).to_track_quat('-Z','Y').to_euler();camera_data.type='ORTHO';camera_data.ortho_scale=9
scene.render.resolution_x=1000;scene.render.resolution_y=700;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.render.filepath=str(ROOT/'Tests/blender-source.png');bpy.ops.render.render(write_still=True)
old_engine=scene.render.engine
req=p.load_json(root/'requests/bake.json')
session=baker.BakeSession(root,req)
while session.step(): pass
result=p.load_json(root/'results/latest.json');assert result['status']=='complete',result
assert len(result['items'])==3
assert scene.render.engine==old_engine
assert len({i['sha256'] for i in result['items']})==3,'Per-instance lighting should yield distinct textures'
print('PASS: Cycles Combined bake to 3 unique UV2 images; source data restored',flush=True)
for ob in coll.objects:
 assert all('ULB_BAKE_TARGET' not in mat.node_tree.nodes for mat in ob.data.materials)
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'Tests/BlenderFixture.blend'))
# Re-render using baked appearance, source lighting excluded by emission-only shader.
for item in result['items']:
 ob=next(o for o in coll.objects if o['ulb_id']==item['id'])
 ob.data=ob.data.copy();mat=bpy.data.materials.new('Baked '+ob.name);mat.use_nodes=True;nt=mat.node_tree;nt.nodes.clear();out=nt.nodes.new('ShaderNodeOutputMaterial');em=nt.nodes.new('ShaderNodeEmission');im=nt.nodes.new('ShaderNodeTexImage');im.image=bpy.data.images.load(str(root/item['image']));uv=nt.nodes.new('ShaderNodeUVMap');uv.uv_map='UV2';nt.links.new(uv.outputs['UV'],im.inputs['Vector']);nt.links.new(im.outputs['Color'],em.inputs['Color']);nt.links.new(em.outputs[0],out.inputs[0]);ob.data.materials.clear();ob.data.materials.append(mat)
 for poly in ob.data.polygons:poly.material_index=0
scene.view_settings.view_transform='Standard';scene.view_settings.look='None';scene.view_settings.exposure=0;scene.view_settings.gamma=1
scene.render.filepath=str(ROOT/'Tests/blender-baked-unlit.png');bpy.ops.render.render(write_still=True)
print('BLENDER_ROUNDTRIP_PASSED',flush=True)
