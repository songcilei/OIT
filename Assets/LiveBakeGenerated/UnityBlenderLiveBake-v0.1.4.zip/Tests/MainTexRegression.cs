using System;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using LiveBakeBridge;
using LiveBakeBridge.Editor;
public static class MainTexRegression {
 static void Check(bool b,string s){if(!b)throw new Exception("FAIL: "+s);Debug.Log("PASS: "+s);}
 static Texture2D Tex(string name,Color color){var t=new Texture2D(8,8,TextureFormat.RGBA32,false);t.SetPixels(Enumerable.Repeat(color,64).ToArray());t.Apply();string p="Assets/"+name+".png";File.WriteAllBytes(p,t.EncodeToPNG());AssetDatabase.ImportAsset(p,ImportAssetOptions.ForceSynchronousImport);var ti=(TextureImporter)AssetImporter.GetAtPath(p);ti.isReadable=false;ti.textureCompression=TextureImporterCompression.Uncompressed;ti.SaveAndReimport();return AssetDatabase.LoadAssetAtPath<Texture2D>(p);}
 static SceneManifest Snap(string name){var m=SceneExporter.Export();BridgeIO.Json(Path.Combine(BridgeSettings.instance.Folder,name+".json"),m);return m;}
 public static void Run(){try{
  EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);PlayerSettings.colorSpace=ColorSpace.Linear;
  var root=new GameObject("MainTexRoot");var go=GameObject.CreatePrimitive(PrimitiveType.Cube);go.transform.SetParent(root.transform);var renderer=go.GetComponent<MeshRenderer>();
  var mesh=UnityEngine.Object.Instantiate(go.GetComponent<MeshFilter>().sharedMesh);mesh.subMeshCount=2;var tr=mesh.triangles; // create two triangle submesh partitions from source
  var primitive=GameObject.CreatePrimitive(PrimitiveType.Cube);var all=primitive.GetComponent<MeshFilter>().sharedMesh.triangles;UnityEngine.Object.DestroyImmediate(primitive);mesh.SetTriangles(all.Take(18).ToArray(),0);mesh.SetTriangles(all.Skip(18).ToArray(),1);Unwrapping.GenerateSecondaryUVSet(mesh);AssetDatabase.CreateAsset(mesh,"Assets/MainTexMesh.asset");go.GetComponent<MeshFilter>().sharedMesh=mesh;
  var red=Tex("MainTexRed",Color.red);var blue=Tex("BaseMapBlue",Color.blue);var green=Tex("MainTexGreen",Color.green);
  var urp=new Material(Shader.Find("Universal Render Pipeline/Lit"));urp.name="URP Both Textures";urp.SetTexture("_BaseMap",blue);urp.SetTexture("_MainTex",red);urp.SetColor("_BaseColor",new Color(.2f,.3f,.4f,1));urp.SetTextureScale("_BaseMap",new Vector2(2,3));urp.SetTextureOffset("_BaseMap",new Vector2(.1f,.2f));urp.SetTextureScale("_MainTex",new Vector2(4,5));urp.SetTextureOffset("_MainTex",new Vector2(.3f,.4f));urp.EnableKeyword("_SMOOTHNESS_TEXTURE_ALBEDO_CHANNEL_A");AssetDatabase.CreateAsset(urp,"Assets/MainTexURP.mat");
  var std=new Material(Shader.Find("Standard"));std.name="Standard Main";std.SetTexture("_MainTex",green);std.color=new Color(.3f,.6f,.2f,1);AssetDatabase.CreateAsset(std,"Assets/MainTexStd.mat");renderer.sharedMaterials=new[]{urp,std};
  EditorSceneManager.SaveScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene(),"Assets/MainTexQA.unity");
  var settings=BridgeSettings.instance;settings.folder=Path.Combine(Environment.GetEnvironmentVariable("ULB_TEST_OUTPUT"),"maintex-exchange");settings.rootIds=new[]{BridgeIO.Id(root)};settings.liveSync=false;settings.autoImport=false;settings.forceMainTexBaseColor=false;settings.Persist();
  urp.SetTexture("_MainTex",red);urp.SetTextureScale("_MainTex",new Vector2(4,5));urp.SetTextureOffset("_MainTex",new Vector2(.3f,.4f));urp.EnableKeyword("_SMOOTHNESS_TEXTURE_ALBEDO_CHANNEL_A");var off=Snap("normal");var offU=off.materials.Single(m=>m.name==urp.name);Check(!offU.directBaseTexture&&offU.tiling.SequenceEqual(new[]{2f,3f,.1f,.2f}),"unchecked URP BaseMap and original mapping retained");
  settings.forceMainTexBaseColor=true;urp.SetTexture("_MainTex",red);urp.SetTextureScale("_MainTex",new Vector2(4,5));urp.SetTextureOffset("_MainTex",new Vector2(.3f,.4f));urp.EnableKeyword("_SMOOTHNESS_TEXTURE_ALBEDO_CHANNEL_A");Debug.Log("BEFORE EXPORT Main="+urp.GetTexture("_MainTex").name+" Base="+urp.GetTexture("_BaseMap").name);var on=Snap("override");Debug.Log("AFTER EXPORT Main="+urp.GetTexture("_MainTex").name);var onU=on.materials.Single(m=>m.name==urp.name);var onS=on.materials.Single(m=>m.name==std.name);
  Check(onU.directBaseTexture&&onS.directBaseTexture,"override applies to both submesh material slots");Check(onU.baseTexture!=offU.baseTexture,"override selects actual _MainTex instead of URP _BaseMap");Check(onU.baseTextureTiling.SequenceEqual(new[]{4f,5f,.3f,.4f})&&onU.tiling.SequenceEqual(offU.tiling),"MainTex mapping independent from normal/PBR maps");Check(onU.smoothnessTexture==offU.baseTexture,"albedo smoothness preserves original BaseMap alpha source");Check(on.sceneHash!=off.sceneHash&&on.revision!=off.revision,"toggle invalidates scene material hash without forced export");Check(Snap("override-repeat").revision==on.revision,"unchanged override uses stable revision");
  settings.forceMainTexBaseColor=false;Check(Snap("normal-again").sceneHash==off.sceneHash,"OFF restores exact original scene content hash");Check(urp.GetTexture("_MainTex")==red&&urp.GetTexture("_BaseMap")==blue&&urp.GetColor("_BaseColor")==new Color(.2f,.3f,.4f,1),"Unity source material not modified");
  settings.forceMainTexBaseColor=true;urp.SetTexture("_MainTex",null);var missing=Snap("missing");Check(!missing.materials.Single(m=>m.name==urp.name).directBaseTexture&&SceneExporter.Warnings.Any(w=>w.Contains("_MainTex 未设置")),"missing MainTex uses normal sync with warning");urp.SetTexture("_MainTex",red);
  var custom=new Material(Shader.Find("QA/MainTexCustom"));custom.name="Custom Base Only";custom.SetTexture("_MainTex",red);custom.color=Color.black;AssetDatabase.CreateAsset(custom,"Assets/MainTexCustom.mat");renderer.sharedMaterials=new[]{custom,std};var customOn=Snap("custom");Check(customOn.materials.Single(m=>m.name==custom.name).directBaseTexture&&SceneExporter.Warnings.Any(w=>w.Contains("自定义")),"custom opaque MainTex exports base-only with explicit warning");
  settings.forceMainTexBaseColor=false;bool rejected=false;try{SceneExporter.Export();}catch(InvalidOperationException){rejected=true;}Check(rejected,"unchecked custom shader still follows original unsupported rule");
  settings.forceMainTexBaseColor=true;custom.renderQueue=3000;rejected=false;try{SceneExporter.Export();}catch(InvalidOperationException){rejected=true;}Check(rejected,"transparent custom fallback rejected");custom.renderQueue=-1;
  urp.SetTexture("_MainTex",red);urp.SetTextureScale("_MainTex",new Vector2(4,5));urp.SetTextureOffset("_MainTex",new Vector2(.3f,.4f));urp.EnableKeyword("_SMOOTHNESS_TEXTURE_ALBEDO_CHANNEL_A");renderer.sharedMaterials=new[]{urp,std};var beforeBinding=Snap("before-binding");var bind=go.AddComponent<LiveBakeBinding>();bind.originalMaterials=new[]{urp,std};bind.applied=true;renderer.sharedMaterials=new[]{new Material(Shader.Find("LiveBakeBridge/UV2 Unlit")),new Material(Shader.Find("LiveBakeBridge/UV2 Unlit"))};Check(Snap("after-bake").sceneHash==beforeBinding.sceneHash,"already baked instance uses saved original MainTex, not baked result");
  var w=EditorWindow.GetWindow<LiveBakeWindow>();w.Repaint();w.Close();settings.Persist();Debug.Log("MAINTEX_UNITY_PASSED");EditorApplication.Exit(0);
 }catch(Exception e){Debug.LogException(e);EditorApplication.Exit(1);}}
}




