using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
public static class AtlasURPProof {
 public static void Run(){try{
  EditorSceneManager.OpenScene("Assets/AtlasQARender.unity");PlayerSettings.colorSpace=ColorSpace.Linear;
  var asset=AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>("Assets/QAPipeline.asset");if(!asset)throw new Exception("Missing QA URP pipeline");GraphicsSettings.renderPipelineAsset=asset;QualitySettings.renderPipeline=asset;
  var renderers=UnityEngine.Object.FindObjectsOfType<MeshRenderer>();if(renderers.Select(r=>r.sharedMaterial.GetTexture("_BakeTex")).Distinct().Count()!=1)throw new Exception("Not a single atlas");
  var go=new GameObject("Atlas URP Camera");var cam=go.AddComponent<Camera>();go.AddComponent<UniversalAdditionalCameraData>().renderPostProcessing=false;cam.transform.position=new Vector3(7,6,-9);cam.transform.LookAt(new Vector3(1,.3f,0));cam.orthographic=true;cam.orthographicSize=3.15f;cam.clearFlags=CameraClearFlags.SolidColor;cam.backgroundColor=new Color(.18f,.22f,.26f);cam.allowHDR=false;
  var rt=new RenderTexture(1000,700,24,RenderTextureFormat.ARGB32,RenderTextureReadWrite.sRGB);rt.Create();cam.targetTexture=rt;cam.Render();RenderPipeline.SubmitRenderRequest(cam,new UniversalRenderPipeline.SingleCameraRequest{destination=rt});
  var prev=RenderTexture.active;RenderTexture.active=rt;var image=new Texture2D(1000,700,TextureFormat.RGB24,false);image.ReadPixels(new Rect(0,0,1000,700),0,0);image.Apply();
  string path=Environment.GetEnvironmentVariable("ULB_TEST_OUTPUT");if(string.IsNullOrEmpty(path))throw new Exception("ULB_TEST_OUTPUT missing");File.WriteAllBytes(Path.Combine(path,"unity-urp-atlas.png"),image.EncodeToPNG());RenderTexture.active=prev;
  var pixels=image.GetPixels32();int red=pixels.Count(c=>c.r>c.b*2&&c.r>c.g*1.5f);if(red<100)throw new Exception("No baked red regions");
  var reference=new Texture2D(2,2);reference.LoadImage(File.ReadAllBytes(Path.Combine(path,"unity-atlas-unlit.png")));var a=reference.GetPixels32();double err=0;for(int i=0;i<a.Length;i++)err+=Math.Abs(a[i].r-pixels[i].r)+Math.Abs(a[i].g-pixels[i].g)+Math.Abs(a[i].b-pixels[i].b);err/=a.Length*3;if(err>8)throw new Exception("URP atlas mismatch MAE="+err);
  Debug.Log("PASS: URP uses one texture with per-instance atlas ST; rendered MAE versus Built-in="+err);Debug.Log("ATLAS_URP_PASSED");EditorApplication.Exit(0);
 }catch(Exception e){Debug.LogException(e);EditorApplication.Exit(1);}}
}
