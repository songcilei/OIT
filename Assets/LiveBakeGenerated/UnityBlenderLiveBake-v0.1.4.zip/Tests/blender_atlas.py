import sys, json, uuid, hashlib, shutil
from pathlib import Path
import bpy
import numpy as np
from mathutils import Vector
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'BlenderAddon'))
from unity_live_bake import receiver,baker,protocol as p,atlas
bpy.ops.wm.read_factory_settings(use_empty=True)
root=R/'Tests/atlas-exchange';manifest=receiver.sync_scene(root)
scene=bpy.context.scene
world=bpy.data.worlds.new('Atlas Test World');world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.15,.19,.25,1);world.node_tree.nodes['Background'].inputs[1].default_value=.3;scene.world=world
lightdata=bpy.data.lights.new('Key','AREA');lightdata.energy=600;lightdata.size=3;light=bpy.data.objects.new('Key',lightdata);scene.collection.objects.link(light);light.location=(-3,-4,7);light.rotation_euler=(Vector((1,0,0))-light.location).to_track_quat('-Z','Y').to_euler()
coll=receiver.collection_for(scene,manifest['projectId'])
mesh_refs={o['ulb_id']:o.data for o in coll.objects};source_uvs={o['ulb_id']:[tuple(x.uv) for x in o.data.uv_layers['UV2'].data] for o in coll.objects}
req=p.load_json(root/'requests/bake.json');p.atomic_json(root/'atlas-request.json',req)
assert req['atlas']
session=baker.BakeSession(root,req)
size=req['resolution'];layout=session.atlas_layout;previous=[]
while True:
 more=session.step()
 if session.atlas_image is not None:
  pixels=np.empty(size*size*4,dtype=np.float32);session.atlas_image.pixels.foreach_get(pixels);pixels=pixels.reshape(size,size,4)
  for rect,saved in previous:
   x,y,right,top=rect
   assert np.allclose(pixels[y:top,x:right,:3],saved,atol=2e-5),'Later object overwrote earlier atlas tile'
  rect=layout[session.index-1]['cell'];x,y,right,top=rect;previous.append((rect,pixels[y:top,x:right,:3].copy()))
 if not more:break
result=p.load_json(root/'results/latest.json');assert result['status']=='complete' and result['atlas'];assert len({i['image'] for i in result['items']})==1
assert len(list((root/'results'/req['id']).glob('*.png')))==1
assert session.atlas_image is None
p.atomic_json(root/'atlas-result.json',result)
img=bpy.data.images.load(str(root/result['items'][0]['image']));arr=np.empty(size*size*4,dtype=np.float32);img.pixels.foreach_get(arr);arr=arr.reshape(size,size,4)
for idx,entry in enumerate(layout):
 x,y,w,h=entry['content'];tile=arr[y:y+h,x:x+w,:3];assert tile.max()>.05 and tile.mean()>.005,'Black/empty tile '+str(idx)
 if idx<len(previous):
  # Compare the final saved image converted back to display-referred linear with the
  # earlier raw buffer only for structural coverage, not AgX color differences.
  pass
 last=result['items'][idx]['scaleOffset'];assert last==entry['scaleOffset']
# Unused fourth cell should be black even after all dilation.
assert arr[size//2+20:-20,size//2+20:-20,:3].max()<1e-4,'Unused atlas cell got overwritten by dilation'
bpy.data.images.remove(img)
for ob in coll.objects:
 assert ob.data==mesh_refs[ob['ulb_id']]
 assert [tuple(x.uv) for x in ob.data.uv_layers['UV2'].data]==source_uvs[ob['ulb_id']]
print('PASS: single atlas PNG, nonempty tiles, unused tile black, earlier tiles not cleared, original UV2 restored',flush=True)
shutil.copyfile(root/result['items'][0]['image'],R/'Tests/atlas-preview.png')
# Legacy/non-atlas path, original request field omitted for backward compatibility.
ind=dict(req);ind.pop('atlas');ind.update(id=uuid.uuid4().hex,resolution=256)
p.atomic_json(root/'individual-request.json',ind)
session=baker.BakeSession(root,ind)
while session.step():pass
separate=p.load_json(root/'results/latest.json');assert not separate['atlas'] and len({i['image'] for i in separate['items']})==3
assert all(i['scaleOffset']==[1,1,0,0] for i in separate['items'])
p.atomic_json(root/'individual-result.json',separate)
print('PASS: unchecked / old request still creates per-instance images with identity ST',flush=True)
# EXR atlas and cancellation / failed batch don't publish partial success.
exr=dict(req);exr.update(id=uuid.uuid4().hex,format='EXR',resolution=256,samples=2,margin=4)
session=baker.BakeSession(root,exr)
while session.step():pass
exr_result=p.load_json(root/'results/latest.json');assert exr_result['atlas'] and len({i['image'] for i in exr_result['items']})==1
im=bpy.data.images.load(str(root/exr_result['items'][0]['image']));assert im.is_float and tuple(im.size)==(256,256);bpy.data.images.remove(im)
print('PASS: one shared scene-linear EXR atlas',flush=True)
cancel=dict(exr);cancel['id']=uuid.uuid4().hex;session=baker.BakeSession(root,cancel);assert session.step();session.cancelled=True
try:session.step()
except RuntimeError:pass
assert session.atlas_image is None
cancel_result=p.load_json(root/'results/latest.json');assert cancel_result['status']=='cancelled' and not cancel_result['items']
assert not list((root/'results'/cancel['id']).glob('*.exr'))
print('PASS: atlas cancellation frees image and publishes no partial map',flush=True)
# Restore atlas result for Unity integration test.
p.atomic_json(root/'results/latest.json',result);p.atomic_json(root/'requests/bake.json',req)
baker.write_status(root,'ready','Atlas QA complete',req['projectId'],req['revision'],req['id'],3,3)
print('ATLAS_BLENDER_TESTS_PASSED',flush=True)
