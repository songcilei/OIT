import sys, json, shutil, uuid
from pathlib import Path
import bpy
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'BlenderAddon'))
import unity_live_bake as addon
from unity_live_bake import receiver,baker,protocol as p
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'Tests/BlenderFixture.blend'))
root=ROOT/'exchange'
manifest=p.load_json(root/'scene.json')
receiver.sync_scene(root)
for rec in manifest['objects']:
 data=p.load_json(root/'meshes'/f"{rec['mesh']}.json")
 ob=next(o for o in bpy.context.scene.objects if o.get('ulb_id')==rec['id'])
 assert len(ob.data.uv_layers['UV2'].data)==len(data['triangles'])
 for loop in ob.data.loops:
  i=loop.vertex_index*2
  assert all(abs(a-b)<1e-6 for a,b in zip(ob.data.uv_layers['UV2'].data[loop.index].uv,data['uv2'][i:i+2]))
 for polygon in ob.data.polygons:
  source_normal=receiver.mapped(data['normals'][polygon.vertices[0]*3:polygon.vertices[0]*3+3])
  assert polygon.normal.dot(source_normal)>.99, 'reflected winding must agree with imported normal'
print('PASS: exact UV2 loop values; reflected winding agrees with source normals',flush=True)
# EXR independent test copy. Original PNG exchange is never overwritten.
exrroot=ROOT/'Tests/exr-exchange'
exrroot.mkdir(exist_ok=True)
for folder in ['meshes','textures']:
 shutil.copytree(root/folder,exrroot/folder,dirs_exist_ok=True)
p.atomic_json(exrroot/'scene.json',manifest)
req=p.load_json(root/'requests/bake.json');req.update(id=uuid.uuid4().hex,revision=manifest['revision'],sceneHash=manifest['sceneHash'],resolution=64,samples=2,format='EXR',includeGlossy=False)
session=baker.BakeSession(exrroot,req)
while session.step():pass
res=p.load_json(exrroot/'results/latest.json');assert res['status']=='complete'
for item in res['items']:
 image=bpy.data.images.load(str(exrroot/item['image']));assert image.is_float and tuple(image.size)==(64,64);bpy.data.images.remove(image)
print('PASS: scene-linear EXR outputs, glossy-disabled pass',flush=True)
# Cancel between objects must never publish a partial success.
req['id']=uuid.uuid4().hex
session=baker.BakeSession(exrroot,req);session.cancelled=True
try:session.step()
except RuntimeError:pass
assert p.load_json(exrroot/'results/latest.json')['status']=='cancelled'
assert p.load_json(exrroot/'results/latest.json')['items']==[]
print('PASS: cancellation has no partial result',flush=True)
# Stale transform snapshot must abort rather than bind stale lighting.
req['id']=uuid.uuid4().hex
session=baker.BakeSession(exrroot,req)
changed=dict(manifest);changed['sceneHash']='f'*64;p.atomic_json(exrroot/'scene.json',changed)
try:session.step()
except RuntimeError:pass
assert p.load_json(exrroot/'results/latest.json')['status']=='failed'
print('PASS: Unity changes during bake abort stale results',flush=True)
p.atomic_json(exrroot/'scene.json',manifest)
# Test actual timer importer, not just direct calls.
addon.register()
bpy.context.scene.ulb_settings.folder=str(exrroot)
addon._RUNNING=True
addon.tick()
assert bpy.context.scene['ulb_revision']==manifest['revision']
assert p.load_json(exrroot/'status.json')['state']=='ready'
addon._RUNNING=False
addon.unregister()
print('BLENDER_EXTENDED_TESTS_PASSED',flush=True)

