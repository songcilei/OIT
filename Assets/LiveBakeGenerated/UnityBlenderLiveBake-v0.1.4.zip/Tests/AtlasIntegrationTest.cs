using System;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEditor;
using UnityEditor.SceneManagement;
using LiveBakeBridge;
using LiveBakeBridge.Editor;
public static class AtlasIntegrationTest {
 static void Check(bool c,string m){if(!c)throw new Exception("FAIL: "+m);Debug.Log("PASS: "+m);}
 static void Reject(Action action,string m){bool rejected=false;try{action();}catch(InvalidOperationException){rejected=true;}Check(rejected,m);}
 static string Dir=>Path.GetFullPath("../atlas-exchange");
 public static void Prepare(){try{
  EditorSceneManager.OpenScene("Assets/Fixture.unity");BakeImporter.RestoreAllLoaded();
  var s=BridgeSettings.instance;s.folder=Dir;s.rootIds=new[]{BridgeIO.Id(GameObject.Find("SyncRoot"))};s.liveSync=false;s.autoImport=false;s.atlas=true;s.atlasResolution=512;s.samples=8;s.margin=8;s.format="PNG";s.Persist();
  var manifest=SceneExporter.Export(true);Check(manifest.objects.Length==3,"three fixture instances ready");
  var status=new BridgeStatus{state="ready",projectId=BridgeIO.ProjectId,revision=manifest.revision,unixTime=BakeProgress.Now};
  BridgeIO.Json(Path.Combine(Dir,"status.json"),status);
  Reject(()=>BridgeService.RequestBake(),"atlas rejected by old Blender capability handshake");
  status.supportsAtlas=true;BridgeIO.Json(Path.Combine(Dir,"status.json"),status);
  var req=BridgeService.RequestBake();Check(req.atlas&&req.resolution==512&&req.objectCount==3,"toggle sends atlas and full texture resolution");
  Reject(()=>AtlasResultValidator.ValidateCapacity(100,256,32),"tiny atlas capacity rejected");
  var single=new BakeResult{atlas=false,items=new[]{new BakeItem()}};AtlasResultValidator.Validate(single);Check(AtlasResultValidator.ScaleOffset(single,single.items[0])==new Vector4(1,1,0,0),"legacy single-image results default identity ST");
  var invalid=new BakeResult{atlas=true,atlasSize=512,items=new[]{new BakeItem{image="a",sha256="hash",scaleOffset=new[]{.5f,.5f,0f,0f}},new BakeItem{image="a",sha256="hash",scaleOffset=new[]{.5f,.5f,.2f,.2f}}}};
  Reject(()=>AtlasResultValidator.Validate(invalid),"overlapping atlas instance ST rejected");invalid.items[1].scaleOffset=new[]{float.NaN,.5f,.5f,0};Reject(()=>AtlasResultValidator.Validate(invalid),"nonfinite ST rejected");invalid.items[1].scaleOffset=new[]{.4f,.4f,.6f,.6f};invalid.items[1].image="b";Reject(()=>AtlasResultValidator.Validate(invalid),"multi-image atlas result rejected");
  Debug.Log("ATLAS_PREPARE_PASSED");EditorApplication.Exit(0);
 }catch(Exception e){Debug.LogException(e);EditorApplication.Exit(1);}}
 static void Render(string filename){
  var go=new GameObject("Atlas Proof Camera");var camera=go.AddComponent<Camera>();camera.transform.position=new Vector3(7,6,-9);camera.transform.LookAt(new Vector3(1,.3f,0));camera.orthographic=true;camera.orthographicSize=3.15f;camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=new Color(.18f,.22f,.26f);camera.allowHDR=false;camera.allowMSAA=false;
  var rt=new RenderTexture(1000,700,24,RenderTextureFormat.ARGB32,RenderTextureReadWrite.sRGB);camera.targetTexture=rt;camera.Render();var old=RenderTexture.active;RenderTexture.active=rt;var cpu=new Texture2D(1000,700,TextureFormat.RGB24,false);cpu.ReadPixels(new Rect(0,0,1000,700),0,0);cpu.Apply();File.WriteAllBytes(Path.GetFullPath("../"+filename),cpu.EncodeToPNG());RenderTexture.active=old;camera.targetTexture=null;rt.Release();UnityEngine.Object.DestroyImmediate(cpu);UnityEngine.Object.DestroyImmediate(rt);UnityEngine.Object.DestroyImmediate(go);
 }
 static void SelectBatch(string mode){File.Copy(Path.Combine(Dir,mode+"-result.json"),Path.Combine(Dir,"results","latest.json"),true);File.Copy(Path.Combine(Dir,mode+"-request.json"),Path.Combine(Dir,"requests","bake.json"),true);}
 public static void Import(){try{
  EditorSceneManager.OpenScene("Assets/Fixture.unity");BakeImporter.RestoreAllLoaded();var s=BridgeSettings.instance;s.folder=Dir;s.rootIds=new[]{BridgeIO.Id(GameObject.Find("SyncRoot"))};s.liveSync=false;s.autoImport=false;s.Persist();
  var renderers=UnityEngine.Object.FindObjectsOfType<MeshRenderer>();var originals=renderers.Select(r=>r.GetComponent<MeshFilter>().sharedMesh).ToArray();var uvs=originals.Select(m=>m.uv2.ToArray()).ToArray();
  SelectBatch("atlas");int n=BakeImporter.ImportLatest();Check(n==3,"atlas imports all three instances");
  var result=BridgeIO.Read<BakeResult>(Path.Combine(Dir,"results","latest.json"));var textures=renderers.Select(r=>r.sharedMaterial.GetTexture("_BakeTex")).Distinct().ToArray();Check(textures.Length==1,"all Unity instances reference ONE texture asset");
  Check(Directory.GetFiles("Assets/LiveBakeGenerated/"+result.id,"*.png").Length==1,"Unity imports exactly one atlas PNG");
  foreach(var item in result.items){var r=(MeshRenderer)BridgeIO.Resolve(item.id);var mat=r.sharedMaterial;var st=item.scaleOffset;Check(mat.GetTextureScale("_BakeTex")==new Vector2(st[0],st[1])&&mat.GetTextureOffset("_BakeTex")==new Vector2(st[2],st[3]),"returned scale/offset assigned: "+r.name);}
  Check(renderers.All(r=>r.GetComponent<LiveBakeBinding>().atlas),"atlas metadata attached to instances");
  var ti=(TextureImporter)AssetImporter.GetAtPath(AssetDatabase.GetAssetPath(textures[0]));Check(!ti.mipmapEnabled&&ti.filterMode==FilterMode.Bilinear,"atlas disables global mipmap cross-tile bleeding");
  Render("unity-atlas-unlit.png");EditorSceneManager.SaveScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene(),"Assets/AtlasQARender.unity",true);
  SelectBatch("individual");BakeImporter.ImportLatest();Check(renderers.Select(r=>r.sharedMaterial.GetTexture("_BakeTex")).Distinct().Count()==3,"unchecked flow still imports three unique textures");
  Check(renderers.All(r=>r.sharedMaterial.GetTextureScale("_BakeTex")==Vector2.one&&r.sharedMaterial.GetTextureOffset("_BakeTex")==Vector2.zero),"switching atlas OFF restores identity ST");
  Check(renderers.All(r=>!r.GetComponent<LiveBakeBinding>().atlas),"individual mode metadata resets");Render("unity-individual-unlit-regression.png");
  SelectBatch("atlas");BakeImporter.ImportLatest();Check(renderers.Select(r=>r.sharedMaterial.GetTexture("_BakeTex")).Distinct().Count()==1,"switching atlas ON again works");
  for(int i=0;i<renderers.Length;i++)Check(renderers[i].GetComponent<MeshFilter>().sharedMesh==originals[i]&&originals[i].uv2.SequenceEqual(uvs[i]),"original mesh and UV2 unchanged: "+renderers[i].name);
  var manifest=SceneExporter.Export(true);Check(manifest.sceneHash==result.sceneHash,"atlas material does not feed back into source export");
  Check(BakeImporter.RestoreAllLoaded()==3&&renderers.All(r=>r.sharedMaterial.shader.name=="Standard"),"restore originals after toggling modes");
  var shader=Shader.Find("LiveBakeBridge/UV2 Unlit");Check(!ShaderUtil.GetShaderMessages(shader).Any(m=>m.severity==UnityEditor.Rendering.ShaderCompilerMessageSeverity.Error),"UV2 ST shader compiles");
  Debug.Log("ATLAS_UNITY_IMPORT_PASSED");EditorApplication.Exit(0);
 }catch(Exception e){Debug.LogException(e);EditorApplication.Exit(1);}}
}

