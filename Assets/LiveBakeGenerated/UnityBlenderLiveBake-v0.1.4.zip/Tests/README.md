# Reproduce the QA tests

`test_protocol.py` uses the Python standard library only. Run with Python 3.8+.

`BridgeIntegrationTest.cs` belongs in a disposable Unity 2022.3 project's `Assets/Editor/`. Install the UnityPackage first. The fixture assumes the project is at `<delivery>/Tests/UnityProject`, using `<delivery>/exchange` for its exchange folder. Do not put this test class in a production project: it creates/replaces QA assets and scenes.

1. Unity batchmode `-executeMethod BridgeIntegrationTest.ExportFixture`.
2. Blender background `--python Tests/blender_roundtrip.py`.
3. Unity batchmode `-executeMethod BridgeIntegrationTest.ImportFixture`.
4. Blender background `--python Tests/blender_extended.py` and `Tests/blender_transforms.py`.

The Blender scripts derive the delivery root from `__file__` and expect the exported exchange fixture. They preserve original PNG exchange results while creating a separate EXR test exchange.

`URPProof.cs` needs a separate disposable project with URP 14.0.11 and copies of the QA scene, Prefab, materials, textures, mesh and baked output assets. Its output directory can be set with the ULB_TEST_OUTPUT environment variable. Do not compile it in a Built-in-only project.

Full raw editor logs are deliberately not bundled, as they may contain host/licensing details. `test-summary.txt` contains only test pass/fail markers.

Atlas v0.1.3 QA:
- `test_atlas.py`: standard-library grid layout/guards tests.
- `AtlasIntegrationTest.Prepare` (Unity QA) writes the atlas request and checks old-receiver rejection.
- `blender_atlas.py` bakes atlas PNG + separate PNG + atlas EXR, checks tile preservation and cancellation.
- `AtlasIntegrationTest.Import` (Unity QA) checks import assets/ST/mode switching and renders proof images.
- `blender_atlas_multimaterial.py` checks multi-submesh color preservation in every tile.
- `AtlasURPProof.Run` runs only in the separate URP test project; needs the copied AtlasQARender scene, its source Prefab/mesh/materials and generated atlas assets, plus ULB_TEST_OUTPUT.
