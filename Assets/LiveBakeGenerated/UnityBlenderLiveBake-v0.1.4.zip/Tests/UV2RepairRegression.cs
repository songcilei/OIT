using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEditor;
using UnityEditor.SceneManagement;
using LiveBakeBridge;
using LiveBakeBridge.Editor;
public static class UV2RepairRegression {
 static void Check(bool test,string why){if(!test)throw new Exception("FAIL: "+why);Debug.Log("PASS: "+why);}
 static string[] Corners(Mesh m){var pos=m.vertices;var uv=m.uv;var ns=m.normals;var ts=m.tangents;var cs=m.colors;var uv3=m.uv3;var r=new List<string>();
  for(int sub=0;sub<m.subMeshCount;sub++)foreach(int i in m.GetTriangles(sub))r.Add(sub+"|"+pos[i].ToString("F6")+"|"+uv[i].ToString("F6")+"|"+ns[i].ToString("F6")+"|"+ts[i].ToString("F6")+"|"+cs[i].ToString("F6")+"|"+uv3[i].ToString("F6"));
  return r.OrderBy(x=>x,StringComparer.Ordinal).ToArray();
 }
 public static void Run(){try{
  EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
  var root=new GameObject("UV2RepairQA");var plane=GameObject.CreatePrimitive(PrimitiveType.Plane);plane.name="BuiltinPlane";plane.transform.SetParent(root.transform);
  var originalPlane=plane.GetComponent<MeshFilter>().sharedMesh;Check(!originalPlane.HasVertexAttribute(VertexAttribute.TexCoord1),"reproduced Unity built-in Plane missing UV2");
  var source=UnityEngine.Object.Instantiate(originalPlane);source.name="NonReadableMultiSubmeshSource";
  var triangles=source.triangles;source.subMeshCount=2;source.SetTriangles(triangles.Take(triangles.Length/2).ToArray(),0);source.SetTriangles(triangles.Skip(triangles.Length/2).ToArray(),1);
  source.colors=Enumerable.Range(0,source.vertexCount).Select(i=>new Color(i/(float)source.vertexCount,.2f,.6f,1)).ToArray();source.uv3=source.uv.Select(x=>x*.3f).ToArray();
  var originalCorners=Corners(source);AssetDatabase.CreateAsset(source,"Assets/UV2RepairQASource.asset");
  var template=new GameObject("MissingUVPrefab");template.AddComponent<MeshFilter>().sharedMesh=source;
  var material=new Material(Shader.Find("Standard"));AssetDatabase.CreateAsset(material,"Assets/UV2RepairQAMat.mat");template.AddComponent<MeshRenderer>().sharedMaterials=new[]{material,material};
  var prefab=PrefabUtility.SaveAsPrefabAsset(template,"Assets/UV2RepairQAPrefab.prefab");UnityEngine.Object.DestroyImmediate(template);
  var a=(GameObject)PrefabUtility.InstantiatePrefab(prefab,root.transform);a.name="A";var z=(GameObject)PrefabUtility.InstantiatePrefab(prefab,root.transform);z.name="B";
  var good=new GameObject("ExistingUV2");good.transform.SetParent(root.transform);var goodMesh=UnityEngine.Object.Instantiate(originalPlane);Unwrapping.GenerateSecondaryUVSet(goodMesh);AssetDatabase.CreateAsset(goodMesh,"Assets/UV2RepairQAGood.asset");var originalUV2=goodMesh.uv2.ToArray();good.AddComponent<MeshFilter>().sharedMesh=goodMesh;good.AddComponent<MeshRenderer>().sharedMaterial=material;
  plane.GetComponent<MeshRenderer>().sharedMaterial=material;
  EditorSceneManager.SaveScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene(),"Assets/UV2RepairQA.unity");
  var settings=BridgeSettings.instance;settings.liveSync=false;settings.autoImport=false;settings.rootIds=new[]{BridgeIO.Id(root)};settings.folder=Path.GetFullPath("../../Tests/uv2-repair-exchange");settings.Persist();
  source.UploadMeshData(true);Check(!source.isReadable,"Read/Write disabled on source mesh");
  Check(UV2Repair.FindMissing().Count==3,"scan reports exactly three missing instances");Check(UV2Repair.MissingDescription().Contains("BuiltinPlane"),"error identifies offending object");
  Check(UV2Repair.GenerateMissing()==3,"repair generates three scene-instance replacements");
  var mfA=a.GetComponent<MeshFilter>();var mfB=z.GetComponent<MeshFilter>();var repairedPlane=plane.GetComponent<MeshFilter>().sharedMesh;
  Check(UV2Repair.FindMissing().Count==0,"all synced objects have UV2 after repair");Check(UV2Repair.GenerateMissing()==0,"repeated repair is a no-op");
  Check(!source.HasVertexAttribute(VertexAttribute.TexCoord1)&&!originalPlane.HasVertexAttribute(VertexAttribute.TexCoord1),"original asset and Unity built-in mesh unchanged");
  Check(prefab.GetComponent<MeshFilter>().sharedMesh==source,"source Prefab unchanged");Check(mfA.sharedMesh==mfB.sharedMesh,"same original mesh shares one generated asset");
  Check(good.GetComponent<MeshFilter>().sharedMesh==goodMesh&&originalUV2.SequenceEqual(goodMesh.uv2),"existing UV2 and mesh reference untouched");
  Check(Corners(mfA.sharedMesh).SequenceEqual(originalCorners),"positions UV0 normals tangents colors UV3 and material submesh triangles preserved");
  Check(plane.GetComponent<MeshCollider>().sharedMesh==originalPlane,"collider stays on original geometry");
  var manifest=SceneExporter.Export(true);Check(manifest.objects.Length==4&&manifest.objects.All(o=>o.hasUV2),"repaired meshes exported with UV2 to Blender");
  string meshPath=AssetDatabase.GetAssetPath(repairedPlane);Check(File.Exists(meshPath),"generated copy persists as mesh asset");
  EditorSceneManager.SaveScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene());
  var id=BridgeIO.Id(plane.GetComponent<MeshFilter>());EditorSceneManager.OpenScene("Assets/UV2RepairQA.unity");
  var saved=(MeshFilter)BridgeIO.Resolve(id);Check(saved.sharedMesh==AssetDatabase.LoadAssetAtPath<Mesh>(meshPath),"generated reference survives scene reload");
  Selection.activeGameObject=saved.gameObject;Check(UV2Repair.RestoreSelected()==1,"restore original selected mesh works");Check(saved.sharedMesh==originalPlane,"original built-in reference restored");
  Check(AssetDatabase.LoadAssetAtPath<Mesh>(meshPath)!=null,"restore keeps generated asset for recovery");
  Debug.Log("UV2_REPAIR_REGRESSION_PASSED");EditorApplication.Exit(0);
 }catch(Exception e){Debug.LogException(e);EditorApplication.Exit(1);}}
}
