"""Per-instance UV2 Combined bake. All outputs become visible only via a final manifest."""
import json
import time
from pathlib import Path
import bpy
from . import protocol as p
from . import receiver, atlas


def write_status(root, state, message, project="", revision="", request="", done=0, total=0):
    p.atomic_json(Path(root)/"status.json", dict(state=state, message=message, projectId=project, revision=revision,
                                               requestId=request, done=done, total=total, unixTime=time.time(), supportsAtlas=True, addonVersion="0.1.4", supportsMainTexOverride=True))


class BakeSession:
    def __init__(self, root, request, scene=None):
        self.root = Path(root)
        self.req = request
        self.scene = scene or bpy.context.scene
        self.items = []
        self.index = 0
        self.cancelled = False
        self.atlas_mode = bool(request.get("atlas", False))
        self.atlas_image = None
        self.atlas_layout = []
        p.validate_request(request)
        self.manifest = p.load_json(self.root/"scene.json")
        p.validate_scene(self.manifest)
        for field in ("projectId", "revision", "sceneHash"):
            if self.manifest[field] != request[field]:
                raise ValueError("Bake request refers to an old scene snapshot: " + field)
        # Reassert Unity geometry/transforms before baking; Blender-authored lights/world survive.
        receiver.sync_scene(root, self.scene)
        records = self.manifest["objects"]
        if not records:
            raise ValueError("No synced objects")
        if self.atlas_mode:
            self.atlas_layout = atlas.layout(len(records), request["resolution"], request["margin"])
        checked = set()
        for rec in records:
            if rec["mesh"] not in checked:
                data = p.load_json(p.contained(root, "meshes/"+rec["mesh"]+".json"))
                try:
                    p.validate_uv2(data)
                except ValueError as e:
                    raise ValueError(rec["name"]+": "+str(e)) from e
                checked.add(rec["mesh"])
        coll = receiver.collection_for(self.scene, request["projectId"])
        self.objects = {o.get("ulb_id"): o for o in coll.objects}
        for rec in records:
            ob = self.objects[rec["id"]]
            if ob.hide_render or ob.hide_get() or not ob.visible_get():
                raise ValueError("Synced object is hidden/excluded: "+ob.name)
        self.signature = self._signature()
        self.old_engine = self.scene.render.engine
        self.old_samples = self.scene.cycles.samples
        self.old_bake = {k: getattr(self.scene.render.bake, k) for k in ("use_selected_to_active", "use_clear", "margin", "target", "use_pass_direct", "use_pass_indirect", "use_pass_color", "use_pass_diffuse", "use_pass_glossy", "use_pass_transmission", "use_pass_emit")}
        self.old_selected = list(bpy.context.selected_objects)
        self.old_active = bpy.context.view_layer.objects.active
        self.old_mode = bpy.context.object.mode if bpy.context.object else "OBJECT"
        if self.old_mode != "OBJECT":
            raise ValueError("Leave Edit/Sculpt mode before baking")
        self.scene.render.engine = "CYCLES"
        self.scene.cycles.samples = request["samples"]
        self.scene.render.bake.use_selected_to_active = False
        self.scene.render.bake.use_clear = True
        self.scene.render.bake.margin = request["margin"]
        self.scene.render.bake.target = "IMAGE_TEXTURES"
        self.finished = False
        write_status(root, "baking", "UV2 validated; starting Cycles", request["projectId"], request["revision"], request["id"], 0, len(records))

    def _signature(self):
        """Catch normal scene edits between bake steps, including lights and world changes."""
        records = []
        for ob in self.scene.objects:
            records.append((ob.name, ob.type, tuple(v for row in ob.matrix_world for v in row), ob.hide_render))
            if ob.type == "LIGHT":
                records.append((ob.data.type, tuple(ob.data.color), ob.data.energy, getattr(ob.data, "size", 0)))
        world = self.scene.world
        if world and world.use_nodes:
            for node in world.node_tree.nodes:
                vals = []
                for inp in node.inputs:
                    if hasattr(inp, "default_value"):
                        v = inp.default_value
                        vals.append(tuple(v) if hasattr(v, "__iter__") and not isinstance(v, str) else str(v))
                records.append((node.name, vals))
        records.append((self.scene.view_settings.view_transform, self.scene.view_settings.look,
                        self.scene.view_settings.exposure, self.scene.view_settings.gamma))
        return repr(records)

    def step(self):
        if self.finished:
            return False
        try:
            if self.cancelled:
                raise RuntimeError("Cancelled between objects; no partial result applied")
            current = p.load_json(self.root/"scene.json")
            if current["sceneHash"] != self.req["sceneHash"]:
                raise RuntimeError("Unity scene changed during bake; stale results were not published")
            if self._signature() != self.signature:
                raise RuntimeError("Blender scene/light/view settings changed during bake; retry after edits")
            rec = self.manifest["objects"][self.index]
            write_status(self.root, "baking", "Baking "+rec["name"], self.req["projectId"], self.req["revision"], self.req["id"], self.index, len(self.manifest["objects"]))
            self.items.append(self._bake_object(self.objects[rec["id"]], rec))
            self.index += 1
            if self.index < len(self.manifest["objects"]):
                return True
            # A transform/material update might arrive while the last blocking bake ran.
            if p.load_json(self.root/"scene.json")["sceneHash"] != self.req["sceneHash"]:
                raise RuntimeError("Unity scene changed during bake; results retained but not applied")
            if self.atlas_mode:
                write_status(self.root, "baking", "Saving shared atlas", self.req["projectId"], self.req["revision"], self.req["id"], self.index, len(self.manifest["objects"]))
                relative, digest = self._save_image(self.atlas_image, "atlas")
                for item in self.items:
                    item.update(image=relative, sha256=digest)
            # Saving a large atlas can take time too; recheck before publishing.
            if p.load_json(self.root/"scene.json")["sceneHash"] != self.req["sceneHash"]:
                raise RuntimeError("Unity scene changed before result publication")
            self._finish("complete", "")
            return False
        except Exception as e:
            self._finish("cancelled" if self.cancelled else "failed", str(e))
            raise

    def _bake_object(self, ob, rec):
        old_mesh = ob.data
        work = old_mesh.copy()
        ob.data = work
        mats = []
        image = None
        try:
            # Separate each instance's bake targets even if source mesh/materials are shared.
            for i, source in enumerate(old_mesh.materials):
                mat = source.copy()
                mats.append(mat)
                work.materials[i] = mat
            if self.atlas_mode:
                if self.atlas_image is None:
                    self.atlas_image = bpy.data.images.new("ULB Shared Atlas", self.req["resolution"], self.req["resolution"], alpha=False, float_buffer=True)
                    self.atlas_image.colorspace_settings.name = "Linear Rec.709"
                image = self.atlas_image
            else:
                image = bpy.data.images.new("ULB "+rec["token"], self.req["resolution"], self.req["resolution"], alpha=False, float_buffer=True)
                image.colorspace_settings.name = "Linear Rec.709"
            st = self.atlas_layout[self.index]["scaleOffset"] if self.atlas_mode else [1., 1., 0., 0.]
            if self.atlas_mode:
                for loop in work.uv_layers["UV2"].data:
                    uv = loop.uv.copy()
                    loop.uv = (uv.x*st[0]+st[2], uv.y*st[1]+st[3])
            for mat in mats:
                for node in mat.node_tree.nodes:
                    node.select = False
                target = mat.node_tree.nodes.new("ShaderNodeTexImage")
                target.name = "ULB_BAKE_TARGET"
                target.image = image
                target.select = True
                mat.node_tree.nodes.active = target
            work.uv_layers.active = work.uv_layers["UV2"]
            work.uv_layers["UV2"].active_render = True
            for selected in list(bpy.context.selected_objects):
                selected.select_set(False)
            ob.select_set(True)
            bpy.context.view_layer.objects.active = ob
            passes = {"COLOR", "DIRECT", "INDIRECT", "DIFFUSE", "EMIT"}
            if self.req.get("includeGlossy", True):
                passes.add("GLOSSY")
            bpy.ops.object.bake(type="COMBINED", pass_filter=passes, use_selected_to_active=False,
                                use_clear=(not self.atlas_mode or self.index == 0), margin=self.req["margin"], uv_layer="UV2")
            if self.atlas_mode:
                return dict(id=rec["id"], token=rec["token"], sourceHash=rec["sourceHash"], scaleOffset=st)
            relative, digest = self._save_image(image, rec["token"])
            return dict(id=rec["id"], token=rec["token"], sourceHash=rec["sourceHash"], image=relative, sha256=digest, scaleOffset=st)
        finally:
            ob.data = old_mesh
            bpy.data.meshes.remove(work)
            for mat in mats:
                if mat.users == 0:
                    bpy.data.materials.remove(mat)
            if image and not self.atlas_mode:
                bpy.data.images.remove(image)

    def _save_image(self, image, token):
        ext = ".png" if self.req["format"] == "PNG" else ".exr"
        relative = "results/"+self.req["id"]+"/"+token+ext
        path = p.contained(self.root, relative)
        path.parent.mkdir(parents=True, exist_ok=True)
        if self.req["format"] == "PNG":
            settings = self.scene.render.image_settings
            old = (settings.file_format, settings.color_mode, settings.color_depth)
            try:
                settings.file_format = "PNG"
                settings.color_mode = "RGB"
                settings.color_depth = "8"
                image.save_render(str(path), scene=self.scene)
            finally:
                settings.file_format, settings.color_mode, settings.color_depth = old
        else:
            image.file_format = "OPEN_EXR"
            image.filepath_raw = str(path)
            image.save()
        return relative, p.sha256_file(path)

    def _finish(self, status, error):
        if self.finished:
            return
        self.finished = True
        if self.atlas_image is not None:
            bpy.data.images.remove(self.atlas_image)
            self.atlas_image = None
        self.scene.render.engine = self.old_engine
        self.scene.cycles.samples = self.old_samples
        for key, value in self.old_bake.items():
            setattr(self.scene.render.bake, key, value)
        for ob in list(bpy.context.selected_objects):
            ob.select_set(False)
        for ob in self.old_selected:
            if ob.name in bpy.context.view_layer.objects:
                ob.select_set(True)
        if self.old_active and self.old_active.name in bpy.context.view_layer.objects:
            bpy.context.view_layer.objects.active = self.old_active
        result = dict(schema=1, projectId=self.req["projectId"], id=self.req["id"], revision=self.req["revision"],
                      sceneHash=self.req["sceneHash"], status=status, error=error, format=self.req["format"],
                      items=self.items if status == "complete" else [], atlas=self.atlas_mode, atlasSize=self.req["resolution"] if self.atlas_mode else 0)
        p.atomic_json(self.root/"results"/self.req["id"]/"result.json", result)
        p.atomic_json(self.root/"results"/"latest.json", result)
        write_status(self.root, "ready" if status == "complete" else status, error or "Bake complete; Unity can import", self.req["projectId"], self.req["revision"], self.req["id"], self.index, len(self.manifest["objects"]))

