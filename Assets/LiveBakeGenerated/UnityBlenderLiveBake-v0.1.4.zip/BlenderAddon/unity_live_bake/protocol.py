"""Versioned, dependency-free bridge protocol and deterministic UV validation."""
import hashlib
import json
import math
import os
from pathlib import Path
import uuid

SCHEMA = 1


def load_json(path):
    with open(path, encoding="utf-8-sig") as f:
        return json.load(f)


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(".ulb-" + uuid.uuid4().hex + ".tmp")
    try:
        with open(temp, "w", encoding="utf-8") as f:
            json.dump(value, f, ensure_ascii=False, allow_nan=False, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp, path)
    finally:
        if temp.exists():
            temp.unlink()


def contained(root, relative):
    root = Path(root).resolve()
    if not isinstance(relative, str) or not relative or Path(relative).is_absolute() or ":" in relative:
        raise ValueError("Invalid relative exchange path")
    result = (root / relative).resolve()
    if result == root or root not in result.parents:
        raise ValueError("Exchange path escapes the bridge directory")
    return result


def hex_id(value, length=64):
    if not isinstance(value, str) or len(value) != length or any(c not in "0123456789abcdef" for c in value):
        raise ValueError("Invalid content identifier")
    return value


def finite(values):
    return all(isinstance(x, (int, float)) and math.isfinite(x) for x in values)


def validate_mesh(m):
    if m.get("schema") != SCHEMA:
        raise ValueError("Unsupported mesh schema")
    v = m.get("vertices") or []
    t = m.get("triangles") or []
    if not v or len(v) % 3 or not finite(v) or not t or len(t) % 3:
        raise ValueError("Malformed vertex/triangle arrays")
    n = len(v) // 3
    if any(type(i) is not int or i < 0 or i >= n for i in t):
        raise ValueError("Triangle index outside vertex array")
    if len(m.get("faceMaterials") or []) != len(t) // 3:
        raise ValueError("Material/face count mismatch")
    for name, size in (("normals", 3), ("uv0", 2), ("uv2", 2)):
        data = m.get(name) or []
        if data and (len(data) != n * size or not finite(data)):
            raise ValueError("Malformed " + name)


def validate_scene(scene):
    if scene.get("schema") != SCHEMA:
        raise ValueError("Unsupported scene schema")
    hex_id(scene.get("projectId"), 24)
    hex_id(scene.get("revision"), 32)
    hex_id(scene.get("sceneHash"))
    ids = set()
    mat_ids = {m["id"] for m in scene.get("materials", [])}
    for o in scene.get("objects", []):
        if not o.get("id") or o["id"] in ids:
            raise ValueError("Duplicate or empty instance id")
        ids.add(o["id"])
        hex_id(o["token"], 24)
        hex_id(o["mesh"])
        hex_id(o["sourceHash"])
        if len(o.get("matrix", [])) != 16 or not finite(o["matrix"]):
            raise ValueError("Invalid transform")
        if any(x not in mat_ids for x in o.get("materials", [])):
            raise ValueError("Missing material record")


def validate_request(req):
    if req.get("schema") != SCHEMA:
        raise ValueError("Unsupported request schema")
    hex_id(req.get("id"), 32)
    hex_id(req.get("projectId"), 24)
    hex_id(req.get("revision"), 32)
    hex_id(req.get("sceneHash"))
    if "atlas" in req and type(req["atlas"]) is not bool:
        raise ValueError("atlas must be boolean")
    if req.get("resolution") not in (64, 128, 256, 512, 1024, 2048, 4096):
        raise ValueError("Unsupported bake resolution")
    if not 1 <= req.get("samples", 0) <= 512 or not 0 <= req.get("margin", -1) <= 64:
        raise ValueError("Invalid samples or margin")
    if req.get("format") not in ("PNG", "EXR"):
        raise ValueError("Unsupported bake format")


def _cross(a, b, c):
    return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])


def _area(poly):
    if len(poly) < 3:
        return 0.0
    return abs(sum(poly[i][0] * poly[(i+1) % len(poly)][1] - poly[(i+1) % len(poly)][0] * poly[i][1] for i in range(len(poly)))) * .5


def intersection_area(a, b):
    """Convex triangle clipping. Shared edges/vertices have zero area, not overlap."""
    polygon = list(a)
    clip = list(b) if _cross(*b) > 0 else list(reversed(b))
    for i in range(3):
        p, q = clip[i], clip[(i+1) % 3]
        source, polygon = polygon, []
        if not source:
            break
        prev = source[-1]
        dprev = _cross(p, q, prev)
        for cur in source:
            dcur = _cross(p, q, cur)
            if (dcur >= 0) != (dprev >= 0):
                t = dprev / (dprev - dcur)
                polygon.append((prev[0] + t*(cur[0]-prev[0]), prev[1] + t*(cur[1]-prev[1])))
            if dcur >= 0:
                polygon.append(cur)
            prev, dprev = cur, dcur
    return _area(polygon)


def validate_uv2(m):
    validate_mesh(m)
    uv = m.get("uv2") or []
    if not m.get("hasUV2") or not uv:
        raise ValueError("Missing UV2; generate/author the second UV in Unity first")
    if any(x < -1e-6 or x > 1+1e-6 for x in uv):
        raise ValueError("UV2 must be entirely inside 0..1; tiling lightmap UV is not supported")
    triangles = []
    grid = {}
    for k in range(0, len(m["triangles"]), 3):
        tri = tuple((uv[i*2], uv[i*2+1]) for i in m["triangles"][k:k+3])
        if _area(tri) < 1e-12:
            raise ValueError("UV2 has a degenerate triangle at face " + str(k//3))
        lo = [max(0, min(31, int(min(p[j] for p in tri)*32))) for j in range(2)]
        hi = [max(0, min(31, int(max(p[j] for p in tri)*32))) for j in range(2)]
        cells = [(x, y) for x in range(lo[0], hi[0]+1) for y in range(lo[1], hi[1]+1)]
        candidates = set()
        for cell in cells:
            candidates.update(grid.get(cell, []))
        for other in candidates:
            if intersection_area(tri, triangles[other]) > 1e-10:
                raise ValueError("UV2 overlaps: faces %d and %d. Existing UVs were not changed." % (other, k//3))
        for cell in cells:
            grid.setdefault(cell, []).append(len(triangles))
        triangles.append(tri)
    return len(triangles)


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1024*1024), b""):
            h.update(block)
    return h.hexdigest()

