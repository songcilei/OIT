# Bridge protocol v1

Local-only, shared filesystem. UTF-8 JSON; readers accept a BOM. Blender and Unity execute scene operations on their editor/main threads.

- `scene.json`: schema, projectId, revision, sceneHash, objects, materials. Atomic replacement is the commit point.
- `meshes/<sha>.json`: vertices/normals/uv0/uv2, triangle indices, per-face submesh material slots. Unity local coordinates; no index truncation.
- `textures/<sha>.png`: base/emission sRGB, decoded normal and metallic/smoothness linear data.
- `requests/bake.json`: unique id, matching project/revision/sceneHash, resolution/samples/margin, PNG/EXR, glossy option.
- `requests/handled.json`: persisted claim. Never replay an old claimed request automatically.
- `status.json`: state, message, projectId, revision, requestId, progress, Unix heartbeat.
- `results/<requestId>/<instanceToken>.png|exr`: immutable successful object images.
- `results/<requestId>/result.json`: batch outcome.
- `results/latest.json`: atomic final result publication. A complete result contains all instances, source hashes, image paths and SHA-256.

Object identity: scene GlobalObjectId of the MeshRenderer. Filename token is SHA-256(id) prefix. Scene hash excludes revision, includes every exported transform and material/mesh content identifier. After Unlit application, export uses the saved original materials to avoid feedback/double-baking.

Axes: Unity (x,y,z) -> Blender (x,z,y). C has determinant -1. Vertices/normals use C, triangle winding reverses, matrix becomes C*M*C^-1. Nonrepresentable inherited shear is evaluated into a private Blender mesh including inverse-transpose custom normals; regular instances stay shared.

UV indices: Unity Mesh.uv0 -> UV0 / TEXCOORD0; Unity Mesh.uv2 -> UV2 / TEXCOORD1. Source texture nodes explicitly use UV0; the active bake target is UV2. Unity renderer lightmap scale/offset is NOT used, as output is an individual whole-mesh atlas, not a Unity global Lightmap.

Limits: one Unity writer and one Blender receiver per exchange directory. This version does not implement distributed locks, remote authentication, atlasing, automatic orphan-asset disk cleanup or crash-resume of partially baked images. Use a trusted local directory. Runtime has only the restoration metadata component and UV2 unlit shader; editor bridge is in an Editor-only assembly.

v0.1.3 optional request `atlas: true` uses the request's `resolution` as the total square atlas size. Omitting/false preserves legacy per-instance output. Receiver heartbeat advertises `supportsAtlas: true`, `addonVersion: 0.1.3`. Unity refuses atlas requests without that capability.

Successful atlas result: `atlas:true`, `atlasSize:N`; all items share identical `image` and `sha256`, each has `scaleOffset:[sx,sy,ox,oy]`. Atlas importer validates finite positive rectangles, 0..1 bounds, pairwise non-overlap, one common file/hash, and actual imported dimensions. Non-atlas results use identity ST, including old results without an ST field. Mipmaps disabled for atlas only.

Packing is deterministic grid, not area-optimized. Cells are integer-pixel rectangles, gutter=margin+2, UV2 endpoints map to inset texel centers. Source meshes remain shared/immutable; temporary Blender meshes use transformed UV2 only while baking. A single float Image is used for the whole batch; clear only on first instance, save only on full success, free on completion/failure/cancel.
