# 实测报告 — 2026-11-12

## 环境与方式

Windows / Unity 2022.3.62f3 / Blender 5.0.1。独立 Unity QA 项目 + Blender 后台进程，不在用户现有项目中试验。

## 已通过

### 协议单元测试（12 项）

- UV 相邻三角形共享边不误判重叠。
- 重复三角形、反向重复 UV 拒绝。
- 缺失、退化、越界 UV2 拒绝。
- 非有限浮点、非法顶点索引拒绝。
- 交换路径越界拦截。
- JSON 原子覆盖与 UTF-8。
- 三角形交集面积。
- 非法请求 schema 拒绝。

### Unity 导出与往返

- 实际两个 Prefab 场景实例 + 一个地面，三实例导出。
- 普通实例复用同一网格数据。
- 无变化不重写 revision；移动改变 revision，不新增网格文件。
- 禁用实例会从同步清单移除。
- 关闭 mesh Read/Write 仍可导出。
- 两个自定义桥接 Shader 在 Unity 编译成功。
- 设置与同步根节点可跨 Unity 编辑器重启保存。
- Blender 三个不同位置实例分别得到不同烘焙贴图。
- 导回三个实例、生成三份独立烘焙材质。
- 原 Prefab 资产依然引用 Standard 材质，未被覆盖。
- 应用后再次导出仍使用原材质，源场景 hash 保持一致。
- 对象移动后拒绝应用旧结果。
- 恢复原材质成功，再次应用成功。
- Unity Built-in 中实际相机渲染出 UV2 Unlit 烘焙图。

### Blender

- UV2 的每个 loop 值与 Unity 导出值一致，没有重展开。
- 坐标转换、绕序与法线方向一致。
- 正/负行列式的父级 shear 变换保持世界顶点位置及法线。
- 重同步不删除用户灯光/World。
- Combined bake 写入每实例 UV2，烘焙后源网格、源材质和烘焙设置恢复。
- PNG 显示变换输出。
- EXR 线性浮点输出与关闭 glossy 的路径。
- 对象之间取消不会发布部分成功结果。
- 烘焙中 Unity 快照改变会失败，不自动应用旧结果。
- 接收器 timer 路径也执行了同步/状态发布测试。

### URP

Unity 2022.3 + URP 14.0.11 独立 QA 项目：
- UV2 Unlit 实际相机输出通过，非仅检查 Shader 名称。
- URP/Lit 源材质参数导出通过。

## 图像证据

- `blender-source.png`：Blender 原始 Cycles 光照场景。
- `blender-baked-unlit.png`：同一场景以烘焙贴图 + Emission 显示，关闭第二次显示变换。
- `unity-baked-unlit.png`：真正 Unity Built-in 相机输出，场景中没有额外灯光也保留原阴影。
- `unity-urp-baked-unlit.png`：真正 URP 相机输出（较早 128px/实例的小尺寸测试批次）。

最终主往返测试使用 512px/实例、16 samples；这是功能验证场景，不代表生产烘焙质量或复杂场景性能。初始背景不同属于 Blender World 与 Unity 相机纯色背景差异；比较的是物体表面及阴影。

## 尚未覆盖

- Unity 6、HDRP、其他操作系统。
- 大规模（数千实例）性能及显存压力。
- 所有材质贴图组合的像素级匹配；Standard/URP 与 Cycles 不同 BRDF 不可能自动完全等价。
- 所有第三方编辑器扩展、脚本修改底层数据、动态网格、程序化纹理。
- 所有中断点/断电故障注入。
- 正式项目打包平台的贴图压缩、shader stripping 和运行时性能。

结论：核心链路在上述环境实测可用，定位 v0.1 首版；先在项目副本的小范围中试用。

## v0.1.1 UV2 修复回归

实测：Unity 2022.3.62f3 + Blender 5.0.1。

- 复现内置 Plane 原始 Mesh 缺 UV2。
- 一次扫描精确找出三个缺 UV2 的场景实例。
- Read/Write 关闭的多子网格源 Mesh 成功复制/展 UV2。
- 原内置 Mesh、原源资产、原 Prefab 不变，已有 UV2 和原 Mesh 引用不变。
- 同源实例共用生成的 Mesh 副本；再次修复为 no-op。
- 按三角形角点比较：位置、UV0、法线、切线、颜色、UV3、子网格归属保持。
- MeshCollider 保持原引用。
- 生成资产及实例引用在保存/重开场景后仍有效。
- 恢复所选物体原网格成功，生成资产保留以便恢复。
- Unity 生成的 UV2 实际通过 Blender 正面积重叠检查，4 个测试实例完成 Cycles 烘焙。

OIT 项目实际排查：`Assets/BakeTest/BakeTest.unity` 同步 6 个物体，其中只有内置 Plane 缺 UV2。

## v0.1.2 进度反馈回归

Unity 2022.3.62f3 测试通过：14 个状态/窗口检查、6 个实际异步导入错误路径检查。

- 2/6 = 33% 显示真实数量并提取当前物体 Plane。
- 阻塞 bake 的旧心跳不推进百分比、不伪造失败。
- 已提交时间/旧文件时间回退；成功、失败后的计时固定。
- 旧批次状态/结果、外站点项目被忽略。
- 已完成结果优先于旧 baking 状态；等待导入、导入中、导入失败、完成、取消分别呈现。
- 面板可实例化，所有变更脚本编译通过。
- 真正经过延迟回调进入导入；故意使用过期 sceneHash，验证导入失败状态持久化、Busy 正确释放、不自动重复导入、后续新批次不受旧失败阻挡。

未声称逐采样进度或所有同步导入阶段都能平滑刷新。实际 OIT 工程只更新引用包，不自动启动烘焙、不改场景。

## v0.1.3 单图集模式回归

Unity 2022.3.62f3、Blender 5.0.1、URP 14.0.11 隔离 QA 环境：

- 图集布局 4 组单元测试：1/2/3/6/9/10/50 实例分区、边距、边界 texel center、确定性、容量不足和非法参数。
- Unity 提交：toggle 发送 atlas/整图尺寸，旧 Blender capability 被拒绝，容量不足被拒绝。
- Unity 结果验证：重叠/非有限 ST、多文件“单图集”被拒绝；旧独立图结果默认 identity ST。
- Blender 3 实例直接写入一个 float Image，依次 bake；前两个已写入 tile 不被后续 bake 清空，所有 tile 有实际像素，未使用格子为黑色。
- 最终批次仅一张 PNG；单张浮点 EXR 也通过。
- 不带 atlas 字段的旧请求仍输出每实例独立图片和 identity ST。
- 图集中途取消释放临时 Image，不发布部分图集。
- 多材质子网格实测：每个 tile 包含两个材质的烘焙颜色，不仅保留最后一个材质槽。
- Unity 导入：3 个实例引用同一个 Texture 资产，磁盘只有一个 Atlas.png，各实例 ST 与结果一致。
- 开关 ON → OFF → ON 后贴图引用和 ST 正确；原网格/UV2 不变，原材质恢复正常；不会把 Atlas 材质二次反馈导出。
- Unity Built-in 相机输出 `unity-atlas-unlit.png` 已检查；独立模式输出 `unity-individual-unlit-regression.png` 已检查。
- URP 独立测试项目实际渲染 `unity-urp-atlas.png`，与 Built-in 图像的 RGB 平均绝对误差为 0（本测试相机/场景配置下）。
- 原进度反馈的 14 项回归继续通过。

第一版分配方式为等分网格，不声称按面积优化或自动合批。Atlas 无 mipmap 防跨格串色，远处采样质量/性能仍需根据正式场景实测。没有在用户 OIT 场景自动提交收费/耗时烘焙。

## v0.1.4 _MainTex 覆盖回归

Unity 2022.3.62f3 + URP 14 测试项目，Blender 5.0.1：

- 14 项 Unity 回归：标准模式保持，URP _BaseMap 与 _MainTex 使用不同图片时实际取 _MainTex，多材质槽均处理，映射与其他 PBR 参数分离，原 Albedo alpha smoothness 保留。
- 开/关材质哈希变化、重复开启稳定、关闭恢复原 hash；源材质不修改。
- 缺失 _MainTex 回退提示、自定义不透明 base-only、自定义关闭仍拒绝、透明自定义拒绝。
- 已应用烘焙的实例取原材质，不反馈烘焙图。
- Blender 5 组快照实际节点检查：普通、覆盖、缺失、自定义、恢复普通；覆盖时实际 Image Color 直接连接 Base Color、贴图文件和 Tiling/Offset 符合记录。
- 实际 Cycles UV2 烘焙成功。

测试中确认 URP 材质导入可能自动镜像 _BaseMap 到隐藏 _MainTex；测试在导入完成后设置两者不同，再验证导出。工具不篡改这个 Unity 行为。
