# Unity ↔ Blender Live Bake v0.1.4

把 Unity 中摆放的 Prefab **场景实例**同步到 Blender，在 Blender 中布光，使用原网格的第二套 UV 烘焙 **颜色 + 灯光 + 阴影**，然后将结果绑定回 Unity 原实例，用 UV2 Unlit 显示。

这是可测试的第一版，不是 Unity 原生 Lightmap，也不是只把 FBX 来回导出。没有外部付费服务、账号或联网生成。

## 已验证环境

- Windows；Unity **2022.3.62f3**。
- Built-in / Standard，以及 **URP 14.0.11** 的 Unlit 渲染与 Lit 源材质导出。
- Blender **5.0.1**；插件声明最低 4.2，其他版本未实机验证。
- Unity 6、HDRP、Mac/Linux 尚未完成实机验证。

## 安装（不需要先修改项目代码）

1. 将本交付包解压到较短、固定的本地目录，例如 `D:\Tools\UnityBlenderLiveBake`。避免 Windows 路径过长。
2. Unity → **Window → Package Manager → + → Add package from disk**，选择 `UnityPackage/package.json`。
   - 也可选 **Add package from tarball**，安装 `dist/com.local.unity-blender-live-bake-0.1.4.tgz`。
   - 二选一，不要同时安装两份。
3. Blender → **Edit → Preferences → Add-ons → Install from Disk**，选择 `dist/unity_live_bake-0.1.4.zip`，启用 **Unity Live Bake Bridge**。
4. Blender 3D 视图按 **N**，打开 **Unity Bake** 面板。

## 第一次使用

### 1. Unity 选择同步范围

- 保存 Unity 场景。
- 在 Hierarchy 中选中要同步的一个或多个场景根节点。可以是包含许多 Prefab 的父物体。
- 打开 **Tools → Unity ↔ Blender Live Bake**。
- 点击 **Use Selected GameObjects as Sync Roots**。
- 点击 **Sync Now / Refresh Assets**。勾选 **Live sync** 后，移动/旋转/缩放、新增、复制、删除会按间隔增量更新，默认 0.5 秒。
- 点击 **Copy path**。默认交换目录是当前 Unity 项目的 `Library/UnityBlenderLiveBake`。
- 刚复制实例后建议保存场景；实例身份使用场景中的 GlobalObjectId，不是名称或数组顺序。

### 2. Blender 接收

- 推荐打开一个新的 Blender 文件，删除不需要参与烘焙的默认 Cube。插件不会擅自删除你原来的物体。
- 将上一步路径粘贴到 **Exchange folder**，点击 **Start Live Receiver**。
- Unity 内容出现在 `UNITY LIVE | 项目标识` 集合中。
- Unity 拥有该集合内的模型、变换、UV 和基础材质。不要在 Blender 手改这些内容后期待它们回传；下一次同步/烘焙前会恢复 Unity 的源状态。
- **灯光、World、相机、你自己的集合不会被同步覆盖。** 你在 Blender 布光；可点击 **Add Starter Lighting** 添加初始面光源，也可以完全自己布光。
- 交换目录只允许一个 Unity 项目和一个 Blender 接收器使用；不要开两个 Blender 同时接收同一目录。

### 3. 检查 UV2

- Unity `Mesh.uv2` → Blender `UV2` → Unlit Shader `TEXCOORD1`，始终是第二套 UV。
- 原材质贴图使用 `UV0`；烘焙写入 `UV2`，不会用 UV2 去重新采样原材质。
- 没有 UV2：在模型 Import Settings → Model 中打开 **Generate Lightmap UVs**，Apply，回工具窗口刷新；或在建模工具中做好第二套 UV。
- UV2 必须在 0..1 内、没有正面积重叠、没有退化 UV 三角形。
- UV2 岛间距应足够容纳所选分辨率下的扩边和 mipmap。检查能发现重叠，但不自动保证每个 UV 岛的 texel density / padding 合理。
- 工具**不自动重展开**、不覆盖现有 UV，不修改原模型文件。v0.1.1 提供显式「Generate Missing UV2 (Copies)」按钮，只为没有 UV2 的场景实例生成独立网格资产。

### 4. 一键烘焙并回传

在 Unity 窗口选择：
- **Per-instance resolution**：每个 MeshRenderer 独立贴图，默认 1024，可选 256–4096。
- **Cycles samples**：默认 64。
- **UV padding**：默认 16 像素。
- **Include glossy**：是否把镜面/高光也固定烘进去。
- **Output**：默认 PNG（包含 Blender 当前显示变换）；也可选 EXR 线性 HDR。
- **Auto-apply results**：默认开启。

点击 **Bake in Blender → Apply in Unity**。

Blender 依次烘焙每个场景实例。整个批次成功后才发布结果清单；Unity 检查项目、场景快照、实例身份、源数据哈希和图像校验值，导入贴图与材质，将其赋给原来的 MeshRenderer。

默认结果目录：`Assets/LiveBakeGenerated/<本次批次ID>/`。

相同 Prefab 的不同实例使用不同的图。**不修改 Prefab 资产，不覆盖原材质资产。** 即使源网格和源材质相同，也不会因为共用同一贴图把两个位置的光照混在一起。

### 5. 恢复

- **Restore Original Materials**：恢复所有已加载场景中由本工具烘焙绑定的实例原材质、投影设置和原 lightmap 绑定。
- 应用/恢复支持 Undo。
- 烘焙贴图和材质资产会保留，不会自动删除。确认不需要旧批次后可自行整理。
- 应用后同步仍读取保留的原材质，不会把已烘焙颜色再送回 Blender 烘第二遍。
- 不要将 `LiveBakeBinding` 的原材质备份随意删除或 Apply 到 Prefab；若要清理，先 Restore。

## 两种输出及颜色匹配

### PNG：推荐用于“直接显示 Blender 的感觉”

- Cycles 的 Combined 结果经过 Blender 当前 View Transform / Look / Exposure，保存到 8-bit sRGB PNG。
- Unity 按 sRGB 贴图导入，用 UV2 Unlit 采样。
- **关闭 Unity 相机的 Tonemapping、Color Adjustments 等二次调色**，否则会再处理一次。
- 同样曝光/色彩配置下目标表面应接近 Blender；背景、抗锯齿、屏幕采样差异仍可能存在。
- Blender 的合成器、Glare/Bloom、景深、运动模糊、体积和相机屏幕效果不是表面 UV 烘焙，不会进入贴图。

### EXR：线性 HDR

- 不烘入 AgX/Filmic 显示变换和曝光，Unity 以线性纹理导入。
- 如需 Unity 和 Blender 显示一样，必须另行匹配两边的色彩管理/色调映射；不能默认认为 Unity ACES 与 Blender AgX 相同。

### 镜面与动态限制

高光/反射是固定到表面的颜色，不会随着 Unity 相机改变；Unlit 不再接受实时光照。适用于静态场景、风格化环境和固定外观道具，不适合需要真实动态镜面反射的产品展示。角色/道具移动后阴影仍留在贴图原位置，需重新烘焙。

## 第一版支持范围

| 功能 | 状态 |
|---|---|
| 场景 Prefab 实例/普通 GameObject | 支持静态 MeshRenderer + MeshFilter |
| 同步新增、删除、移动、旋转、缩放 | 支持，0.2–3 秒轮询可调 |
| 非均匀缩放、负缩放、父级引入的 shear | 支持；shear 在 Blender 使用私有求值网格保留 |
| 网格/纹理去重 | 内容哈希；普通实例复用网格，变换修改不重传纹理 |
| Unity 禁用 Read/Write 的模型和贴图 | 使用编辑器 MeshData 读取和 GPU 贴图导出 |
| 多子网格/多材质 | 支持；每实例合成一张 UV2 图，所有子网格用同一烘焙图 |
| Standard Metallic / URP Lit Metallic | 支持基础颜色、基础色图、法线、金属/光滑度、自发光、公共 UV0 Tiling/Offset |
| Repeat / Clamp、Point / Bilinear | 支持，Trilinear 在 Blender 对应 Linear |
| 原 AO 图 | 不乘进基础色，避免与 Cycles 几何遮蔽重复变暗；有提示，非 shader-identical |
| LODGroup | 仅 LOD0；其他 LOD 不参与烘焙 |
| SkinnedMesh、Terrain、粒子 | 不支持；跳过并提示 |
| 自定义 Shader、Shader Graph、HDRP、Specular workflow | 不支持，会阻止导出以免静默变错 |
| 透明、Alpha Clip、Detail/Parallax、MaterialPropertyBlock | 不支持，会提示处理后再导出 |
| 混合 U/V wrapping、Mirror wrapping | 不支持 |
| Unity 灯光同步 | 不包含；在 Blender 中布光 |
| 合并单图集 | v0.1.3 可选，按实例均匀网格分区，回传 Tiling/Offset |
| 自动 LOD 烘焙 / 按面积优化图集 / UV 重排 | 不包含 |
| 动画或实时烘焙 | 不包含；实时的是场景同步，烘焙是显式离线任务 |

Standard / URP 的 BRDF 与 Cycles Principled 并不完全一样。本工具用于把 Blender 做好的最终外观回传，不保证源 Unity 光照与 Blender 光照像素相同。

## 防错机制与注意事项

- 原子写入 `scene.json`，网格和纹理使用不可变内容哈希文件名，避免 Blender 读到半文件。
- 场景变化时不发布/不应用过期烘焙；结果保留，必须恢复场景或重新烘焙。
- 完整批次成功后才应用，不把失败一半的结果塞回场景。
- 每实例纹理 SHA-256、项目和实例映射检查。
- 接收器重启不会自动重复执行已认领的旧请求；中断后请显式重新烘焙。
- 烘焙期间不要编辑 Unity 或 Blender 场景。常见变换、灯光和显示设置变化会被检测，但不声称能发现所有第三方脚本对底层数据的修改。
- Blender 每个对象的 Cycles bake 是阻塞调用。界面可能暂时无响应；**取消在对象之间生效，不能承诺中途立即打断一个对象的采样**。
- 若 Unity 按钮提示已有排队请求，先让 Blender 接收。确认接收器停止且旧请求不需要时，可删除交换目录 `requests/bake.json` 后重新提交；不要在正在烘焙时这样操作。
- 交换目录是受信任的本机目录，不是对公网暴露的接口。不要选不可信共享目录或符号链接。
- 单实例独立 1K RGBA 未压缩约 4 MB（mipmap 会增加）；大量实例请降低分辨率。可用 v0.1.3 单图集模式控制总贴图尺寸；每实例仍有独立材质，不能等同于自动合批/减少 DrawCall。

## 测试与交付边界

`Docs/TEST_REPORT.md` 记录实际测试内容；`Tests/` 提供测试脚本与对照渲染。测试使用隔离项目，不改动你已打开的 Unity 项目，也没有对你当前 Blender 文件进行安装/覆盖。

这是第一版工具，建议先在场景副本与少量 Prefab 上试用。正式项目的自定义 Shader、海量场景和特殊 Prefab 数据需要额外适配和验证。

同步根节点所在场景未加载、或根节点本身被删除时，接收端保留上次快照，并提示重新加载/选择根节点；不会把“场景暂时未加载”当作删光所有物体。根节点内部子物体的删除仍会正常同步。

## v0.1.1：内置 Plane / 缺失 UV2 修复

`Missing UV2` 表示同步范围中至少一个网格没有第二套 UV，不是 Blender 版本问题。

- 新版窗口的 **UV2 Check / 第二套 UV** 列出缺失 UV2 的物体，点击 **定位** 选中对应场景物体。
- Unity 内置 Plane 没有 ModelImporter，因此不能按 FBX 的方式勾选 Generate Lightmap UVs。
- 点击 **Generate Missing UV2 (Copies) / 生成缺失 UV2 副本**：只处理当前同步范围内缺失 UV2 的静态网格。
- 新 Mesh 资产保存到 `Assets/LiveBakeGenerated/UV2Meshes/`；场景实例的 MeshFilter 指向副本。原 FBX/内置网格/Prefab 资产不变；已有 UV2 的物体不处理。
- 同源网格的多个实例共用一个 UV2 网格副本，但烘焙仍然每实例独立。
- 原 UV0、法线、切线、颜色、其他 UV 流、子网格保留；Unity 展 UV 可能为接缝拆分顶点，位置和渲染三角形保持。
- MeshCollider 不更换，因为几何表面不变。
- `LiveBakeUV2Binding` 在实例上保留原 Mesh 引用，支持 Undo。点击 **Restore Selected Original Meshes** 可恢复所选物体（含子物体）；已经应用烘焙材质时先 Restore Original Materials。
- 修复不自动保存场景、不自动提交烘焙。修复并同步后，在窗口再点击 Bake。
- 按钮只解决「缺失」，不擅自重排已经存在但重叠的 UV2。已有 UV2 的重叠仍会由 Blender 阻止。
- 原模型重新导入后，修复副本不会自动跟随原模型几何改变；需要先恢复原网格，再重新生成副本。

## v0.1.2：Unity 面板烘焙进度

窗口顶部新增 **烘焙进度 / Bake Progress**，与普通实时同步提示独立：

- 排队 / 等待 Blender 接收。
- Blender 烘焙：已完成物体数 / 总数、百分比、当前物体名称和运行耗时。
- 烘焙完成、等待导入（包括关闭 Auto-apply 的情况）。
- 正在导入并绑定：单独显示导入阶段状态。
- 完成、已应用到 Unity，耗时停止计时。
- 失败 / 取消；导入失败保留具体原因和烘焙文件，可手动 Apply Latest Result 重试。

百分比是 **已完成物体数量占比**，不是采样进度、预计剩余时间或按模型复杂度加权。一个复杂物体烘焙期间会停留在当前百分比，耗时仍更新。Blender 阻塞 bake 时没有新 heartbeat，面板说明距上次状态更新多久，但不会据此伪造失败。

Unity AssetDatabase 导入是同步操作；已在执行前安排一次面板刷新，阶段数据按真实进度更新，但耗时很长的同步资源导入期间界面仍可能暂时无法刷新。不是逐采样实时进度。

兼容旧 Blender 插件，无需重装 Blender。旧任务缺提交时间时，以本地请求文件时间作耗时起点。面板根据批次 ID 匹配，不让上一个批次的完成结果覆盖新任务进度。导入失败/中断不自动反复重试。

## v0.1.3：可选单图集 + 每实例 UV2 Tiling / Offset

在 Unity 面板 Bake 区域勾选 **合并烘焙图集 / Bake All to One Atlas**。

- **默认不勾选**：继续原流程，每个实例单独一张图，分辨率是每实例分辨率。
- **勾选**：所有同步范围内实际参与烘焙的 MeshRenderer 写入 **同一个 Blender Image**，整个批次完成后只保存一张 `atlas.png` / `atlas.exr`，Unity 只导入一个 `Atlas.png` / `Atlas.exr` 贴图资产。
- **Atlas resolution / 整图尺寸** 是整张图分辨率，默认 2048，支持 512/1024/2048/4096。独立模式的分辨率单独保留。
- 使用确定性的均匀网格分区，不旋转、不重新展开原 UV2。每实例单元内按原 UV2 加 padding 和半像素对齐。
- Unity 用 `uv2 * _BakeTex_ST.xy + _BakeTex_ST.zw` 采样。结果 JSON 每个 item 的 `scaleOffset=[tileX,tileY,offsetX,offsetY]`。
- Tiling/Offset 存在各实例烘焙材质的 `_BakeTex` 属性中，`LiveBakeBinding.bakeScaleOffset` 同时记录；**多个材质共用同一个贴图资产**。这版不是所有物体共用一个材质，也不承诺自动合批或减少 DrawCall。
- 原模型 Mesh/UV2 与源材质不修改；只在 Blender 临时工作网格上缩放 UV2，结束即恢复。相同 Prefab 的两个实例拥有不同图集单元与光照。
- 同时支持多材质子网格、PNG（显示变换）与 EXR（线性 HDR）。
- 每个单元外沿留出大于 bake margin 的安全间隔；Unity 图集纹理默认 **Clamp + Bilinear + 无 mipmap + 不压缩**，避免全局 mipmap 在远处把不同单元混色。代价是远处可能更容易闪烁/锯齿；后续如需 mipmap，必须做 tile-aware mip 生成而非直接打开。
- 单元扣掉边距后不足 16px，会拒绝提交/烘焙，请加大整图或减少同步实例/边距。
- 物体越多，单实例分辨率越低；网格是均匀分配，不按实际面积自动分配 texel density。未用完的格子为黑底。
- 批次中途失败/取消不发布部分图集；所有物体均成功后才保存并回传。已完成格子不会在下一物体烘焙时被清空。
- 开关切换后需重新烘焙。把图集结果切回独立图时，材质的 ST 自动恢复 `(1,1,0,0)`，不会沿用上次图集偏移。

### 升级注意

此功能需要 **Unity 和 Blender 两端都是 0.1.3**。旧 Blender 插件仍支持未勾选的独立图流程；勾选时 Unity 检查 Blender heartbeat 的 `supportsAtlas`，旧接收器会被明确拦住，不会静默忽略你的开关。

在已经运行的 Blender 中仅替换磁盘插件文件不代表已加载新代码。保存当前 .blend，退出并重新打开 Blender，然后在面板标题确认 **Unity Live Bake 0.1.3**，再点 Start Live Receiver。Unity Assets → Refresh 后重开工具窗口。升级不修改场景、不自动提交新烘焙。

## v0.1.4：可选 _MainTex → Blender Base Color

Unity 窗口同步设置中新增 **强制 _MainTex → Base Color / Use _MainTex Base Color**，默认关闭。

- 不勾选：原有 Standard / URP Lit 同步不变（URP 用 _BaseMap，Standard 用 _MainTex，乘原材质颜色）。
- 勾选：对同步范围内每个 MeshRenderer 的每个材质槽，直接取 `Material.GetTexture("_MainTex")` 的 Texture2D，连到 Blender Principled 的 Base Color。不经 _Color/_BaseColor 乘色，目的是使用原图颜色。
- 使用该 _MainTex 的 Tiling / Offset、Repeat/Clamp、Point/Linear 和 UV0。UV2 与图集 Tiling/Offset 不受影响。
- 标准材质其他已支持的 PBR 参数继续同步，保持其原映射。若 Smoothness 来源是原 Albedo alpha，保留原 _BaseMap/_MainTex alpha 来源，不误改成覆盖贴图 alpha。
- 标准材质没有 _MainTex 或明确为 null：保留正常同步并提示。不擅自替换为空白。Shader 默认白图若实际返回 Texture，则视为有效贴图。
- 自定义不透明 Shader 若有 _MainTex：允许简化导出为基础色贴图（Metallic=0、Roughness=0.5、无自发光），明确提示其他 Shader 效果/颜色/顶点变形不被复制。透明/Cutout、非 Texture2D、MaterialPropertyBlock 等限制仍保留。
- 若该自定义 Shader 没有有效 _MainTex，不伪造还原，仍报原来的 unsupported shader。关闭开关也恢复原来的支持限制。
- URP Inspector/导入器有时会把兼容用的隐藏 _MainTex 自动同步成 _BaseMap；工具读取的是 Unity 当时实际返回的 _MainTex，不修改它。如果两者本来一致，贴图不会变，但乘色连接方式会变。
- 已经应用烘焙材质的实例仍读取保存的原材质，不会把烘焙图再反馈烘焙。
- 开关改变会产生新的材质/场景哈希，避免旧缓存；Live sync 开启时自动同步，否则点击 Sync Now。已有烘焙不自动替换，需重新烘焙。
- 需 Blender 插件 0.1.4；保存 .blend 后退出并重开，确认标题 **Unity Live Bake 0.1.4**，Start Live Receiver。旧接收器不支持时有明确提示。
